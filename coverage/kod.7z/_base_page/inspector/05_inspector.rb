# require_relative '.'
# require_all '.'
Dir[File.dirname(__FILE__)+"/*.rb"].each { |f| require f }
module Inspector
  include Assembler # assembles data from EXP files and initializes a lot of instance variables
  include Checker #
  include StepMethods
  include TSA

  def verdict this = 'this validation', no_mute=false
    if @error_sum.empty?
      p "         --------------- ..No Errors on #{this}! #{hehes} ----------------", :g if !no_mute or @bulk_validating #and verbose_mode
    else
      $hsh["errors"][@page_name] << @error_sum
      # @failed = true
      @errored_fields_list = []
      if force_override_validations or @force_override_for_bulk_validation
        p "\n >>>>>>>>>>>>     force_overriding_failures in #{this}     <<<<<<<<<<<<<", :br unless @force_override_for_bulk_validation
      else
        @error_sum.each { |errors| errors.each { |k, v| p k, :m; p v, :r } } if no_mute
        @error_sum = []
        raise(ValidationError, "Are the errors in this page \n \n")
      end
      @error_sum = []
    end
  end

  def check_this thing
    @errored_fields_list = []
    @bulk_validating = true
    thing = keyize thing
    tic
    begin
      case thing
        when /ELEMENTS/
          check_elements @exp_elements
        when /TEXTS/
          check_texts @exp_texts
        when /HELP/
          check_help_texts @exp_help
        when /LABELS/
          check_texts @exp_labels
        when /LISTS/
          check_lists @exp_lists
        when /LINK/
          check_links @exp_links
        when /INFO_CENTER/
          check_info_center @exp_infocenter
        when /DISCOUNTS/
          check_discounts @exp_discounts
        when /ALL_COVERAGES/
          check_coverages @exp_coverages, "including help"
        when /COVERAGES/
          check_coverages @exp_coverages
        else
          # raise BadInputDataError, "\nUnknown Validation Data type -> '#{thing}'\n"
          @error_sum << {"#{thing}_Errors".to_sym => "There is no such thing as #{thing} validation!\n"}
          verdict thing
          return
      end
    rescue BadInputDataError
      p "Empty values for #{thing}..\nHope that is fine..",:br
    end

    @error_sum << {"#{thing}_Errors".to_sym => "These #{thing} that are missing or incorrectly displayed: \n #{@errored_fields_list.join("\n")}\n"} unless @errored_fields_list.empty?
    p "took to validate #{thing} = #{toc}s" if profiling_mode
    verdict thing
    @bulk_validating = nil
  end
end