# module DBRider # hmm.. shall we inject this into eve or have it has a separate obj.. i'm for the latter
require 'erb'
require 'yaml'
require 'dbi'
require 'rexml/document'

class DBRider
  # include YamlRider #todo: for erb_eval
  def initialize app_stuff_loc
    @db_file     = Dir[app_stuff_loc+"/*db*.yml"][0]
    @db_cred_hsh = YAML.load_file(@db_file)
    raise BadInputDataError, "empty hash in #{@db_cred_hsh.inspect}" if @db_cred_hsh.empty?
  end

  def close_connection
    @@dbi_conn.disconnect rescue p 'No connections to close..', :gy
  end

  def start_connection(schema_name) #todo think about passing in the connection hash too..
    conn_hsh = @db_cred_hsh[schema_name]
    raise MissingDataError, "No Scheme data for DB connection detected for #{schema_name.inspect}
    \nWarning : Contact a Dev guy/gal immediately, coz am unable to find the credentials for #{schema_name} DB in me!
          also, DB checks will fail..\n\n" unless conn_hsh
    require 'dbi'
    begin
      p "DB_INFO - Adapter : #{conn_hsh['ADAPTER']||'OCI8'}, Host : #{conn_hsh['HOSTNAME']}, Schema : #{schema_name}", :cy
      @@dbi_conn = DBI.connect("DBI:#{conn_hsh['ADAPTER']||'OCI8'}:#{conn_hsh['HOSTNAME']}", conn_hsh['USERNAME'], conn_hsh['PASSWORD'])
    rescue DBI::DatabaseError
      raise NotVPNed, "\nMake sure you are VPN-ed in\n and have the TNS.ora set properly\n  and all that jazz\n"
    end
  end

  def get_val query
    raise BadInputDataError, "Query : '#{query}'\n" unless query
    run_query query # populates @res_list
    @res_list[-1]
  end

  def check_this_query query, exp_res, partial_match = nil
    raise BadInputDataError, "Query : '#{query}'\nValue : '#{exp_res}'\n" unless query and exp_res
    run_query query # populates @res_list
    got_res = @res_list[-1] || 'nil' rescue 'Nothing!!'
    got_res = (@xml = ""; got_res.read) if got_res.is_a? OCI8::CLOB
    # Handle
    handle exp_res, got_res, query, partial_match
  end

  protected
  def run_query query, wanna_commit = nil
    tic 'db'
    @res_list = nil # resets this for the next query
    begin
      wanna_commit ? set_res(query) : @res_list = get_res(query)
    rescue Exception => e
      p "DB Error\n when trying to #{wanna_commit ? 's' : 'g'}et from\n Query: '#{query}'", :cy
      raise e
    ensure
      p "DB eval time - #{toc 'db'}" #if profiling_mode
    end
  end

  private
  def handle exp_res, got_res, query, partial_match
    if got_res =~ (partial_match ? /#{exp_res}/ : /^#{exp_res}$/)
      p "Query : #{query}", :m
      pr " gave - '", :m; pr exp_res, :g; p "' as expected", :m #if verbose_mode
    else
      if exp_res
        # todo : display proper tag content info.. see if you really need to parse out the info or just pass it from above!
        # else
      end
      # REXML::Document.new(got_res).write(@xml,1) rescue @xml = got_res
      @xml = got_res
      raise DBValidationError, "DB value mismatch\nQUERY : #{query}\n  EXP : '#{exp_res}'\n  GOT : '#{@xml}'\n"
    end
  end

  def erb_this str
    # ERB.new(str).result
    ERB.new(str).result(binding) #todo: binding if needed.. right now there is no scoping issue
  end

  # Depreciated.. (not depricated)

  def verify_key key_itms
    raise FormatMismatchError, "No 'QUERY' key in your DB_validation File\n#{@db_val_file}\n" unless key_itms['QUERY']
    raise FormatMismatchError, "No 'VALUE' key in your DB_validation File\n#{@db_val_file}\n" unless key_itms['VALUE']
  end

  def make_query query_hsh
    fields  = query_hsh[:fields] || '*' # X_ATTRIB_28
    table   = query_hsh[:table] # S_ASSET_X
    locator = query_hsh[:locator] # PAR_ROW_ID = 'GJQDGK58'
    "SELECT #{fields} FROM #{table}#{" WHERE #{locator}" if locator}"
  end

  def get_res query, rows_num = nil
    res_list = []
    if rows_num
      i   =0
      res = @@dbi_conn.execute(query)
      res.fetch_hash do |row|
        next if row.nil? or row.empty?
        res_list << row
        break if (i+=1)>=rows_num
      end
      res.finish
      res_list
    else
      @@dbi_conn.select_one query
    end
  end

  def set_res query
    @@dbi_conn.do query
    @@dbi_conn.commit
  end

end


if __FILE__ == $0
  require 'dbi'
  conn_hsh ={'HOSTNAME' => "AGIN01RACT", 'USERNAME' => "", 'PASSWORD' => ""}
  query    ="SELECT * FROM S_ASSET_X WHERE ROWNUM <= 15 and X_ATTRIB_28 is not null"
  dbi_conn = DBI.connect("DBI:#{conn_hsh['ADAPTER']||'OCI8'}:#{conn_hsh['HOSTNAME']}", conn_hsh['USERNAME'], conn_hsh['PASSWORD'])

  res_list = dbi_conn.select_one(query)
  print res_list


end