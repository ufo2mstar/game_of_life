# Ruby Error Hierarchy!
# Exception
#  NoMemoryError
#  ScriptError
#    LoadError
#    NotImplementedError
#    SyntaxError
#  SignalException
#    Interrupt
#  StandardError
#    ArgumentError
#    IOError
#      EOFError
#    IndexError
#    LocalJumpError
#    NameError
#      NoMethodError
#    RangeError
#      FloatDomainError
#    RegexpError
#    RuntimeError
#    SecurityError
#    SystemCallError
#    SystemStackError
#    ThreadError
#    TypeError
#    ZeroDivisionError
#  SystemExit
#  fatal
# ---- Broad level -----
ActualAppError             = Class.new(StandardError)
AutomationError            = Class.new(StandardError)
UserError                  = Class.new(StandardError)

# AppError            = Class.new(StandardError)
# ---- More specific level -----
# UserError
YouShouldNeverGetHereError = Class.new(UserError)
StupidError                = Class.new(UserError)
ToDoError                  = Class.new(UserError)
DBflagDisabled             = Class.new(UserError)
DBConnectionFailed         = Class.new(UserError)
NotVPNed                   = Class.new(UserError)
WrongDataEntered           = Class.new(UserError)
SetupError                 = Class.new(UserError)
ProdRunError               = Class.new(UserError)
BrowserClosed              = Class.new(UserError)

# AutomationError
FormatMismatchError        = Class.new(AutomationError)
TypeMismatchError          = Class.new(AutomationError)

YamlLoadError = Class.new(AutomationError)

MissingDataError       = Class.new(AutomationError)
MissingClaimsDataError = Class.new(AutomationError)
MissingKeyError        = Class.new(AutomationError)
MissingFileError       = Class.new(AutomationError)

MultipleDataError = Class.new(AutomationError)
EmptyDataError    = Class.new(AutomationError)

BadInputDataError = Class.new(AutomationError)
BadGherkinError   = Class.new(AutomationError)
NoNavPaths        = Class.new(AutomationError)

EffectiveDateError     = Class.new(AutomationError)
BrowserError           = Class.new(AutomationError)
FillTryError           = Class.new(AutomationError)
BadLOBError            = Class.new(AutomationError)

# ActualAppError
# FieldMissingError  = Class.new(ActualAppError)
PremiumError           = Class.new(ActualAppError)
ValidationError        = Class.new(ActualAppError) # can also be automation error
DiscountError          = Class.new(ActualAppError) # can also be automation error
EndValidationError     = Class.new(ActualAppError) # can also be automation error
DBValidationError      = Class.new(ActualAppError) # can also be automation error
NavigationError        = Class.new(ActualAppError)
WrongAppError          = Class.new(ActualAppError)
# sub class errors
AppLoadingError        = Class.new(NavigationError)
UnexpectedSoftfall     = Class.new(NavigationError) # todo: rethink and remove
UnexpectedHardfall     = Class.new(NavigationError)
RandomGISHardfall      = Class.new(NavigationError)
UnexpectedPageError    = Class.new(NavigationError)
UnexpectedPaymentIssue = Class.new(NavigationError)
RateRevisionDetected   = Class.new(NavigationError)

PageFillError         = Class.new(NavigationError)
OneBrowserWindowError = Class.new(NavigationError)
CodePush              = Class.new(NavigationError)

module SoftFall
  # REast
  # RF301 - GIS is Down
  # RF013 - Payment System unavailable
  # RF054 - Rating System Unavailable(SA)
  # RF304 - HP Extreme Down
  # RF002 - Unable to order CBR
  # RF003 - Unable to order PLH
  # RF009 - Rating System unavailable/SRM down
  # RF017 - Policy Number system is unavailable
  # HOEast
  # age<18"                 => "RF009",
  # flat roof"              => "RF006",
  # <50K"                   => "RF500", # RF002 has been changed in 9.0-14 to RF500 per SC 428115
  # =>750K"                 => "RF001",
  # ineligible ppc"         => "RF004",
  # roll type"              => "RF014",
  # construction type"      => "RF007",
  # ineligible zip code"    => "RF008",
  # no continuous coverage" => "RF501", # RF013 has been changed in 9.0-14 to RF501 per SC 428115
  # not eligible agent"     => "RF010",
  # windstorm details"      => "RF016",
  # over 500 rc"            => "RF502", # RF017 has been changed in 9.0-14 to RF502 per SC 428115
  # claim selected"         => "RF_CLAIMS_FIRE",
  # current customer"       => "RF225"} # RF225 was introduced in 8.0-14 per SC 405582
  # module Down
  IneligiblePPC        = Class.new(NavigationError)
  HomeDayCare          = Class.new(NavigationError)
  BindSuspensionActive = Class.new(NavigationError)
  CoastalAddress       = Class.new(NavigationError)
  DogBreed             = Class.new(NavigationError)
  module ServiceDown
    PaymentSys                 = Class.new(NavigationError)
    PaymentPlansSys            = Class.new(NavigationError)
    SysError                   = Class.new(NavigationError)
    # PaymentSys      = Class.new(NavigationError)
    RatingSys                  = Class.new(NavigationError)
    HPExtreme                  = Class.new(NavigationError)
    CBR                        = Class.new(NavigationError)
    PLH                        = Class.new(NavigationError)
    SRS_SRM                    = Class.new(NavigationError)
    PolicyNum                  = Class.new(NavigationError)
    UnknownRFcode              = Class.new(NavigationError)
    NoDBConnectionToGetRFcode  = Class.new(NavigationError)
    ErroredWhileCheckingRFcode = Class.new(NavigationError)
    NoRFcode                   = Class.new(NavigationError)
    DefaultSoftfall            = Class.new(NavigationError)
    DefaultHardfall            = Class.new(NavigationError)
  end
end

module Hardfall
  GIS = Class.new(NavigationError)
end

include SoftFall::ServiceDown
include SoftFall
include Hardfall

if __FILE__ == $0
  # include Falls
  # p [Falls::Down::GIS , 'kod']
  # raise(GIS, 'kod')
  fail(GIS, 'kod')
end

# if __FILE__ == $0

# todo.. something like this
# class StandardError
#   # def new msg=nil
#   #   self.message = "\nkk\n#{msg}"
#   # end
#
#   # def backtrace
#   #   # [__callee__,__FILE__]
#   #   # [["KOD"]]
#   # end
#   # def set_backtrace(array)
#   #   # [__callee__]
#   #   ["KOD"]
#   # end
# end
#
#   module AllErrs
#     def check(condition)
# # hmm.. i'm making a call to say that each error should be\
#       expected in its rightful place and not an Rspec Thing!
#       raise AppError, "\nkod\n Exp: #{exp}\n Got: #{got}\n"
#     end
#
#     def expectation_err *stuff
#       puts stuff
#     end
#   end
#
#   TypeError
#   include AllErrs
#   World AllErrs
#
#   expectation_err([1, 2, 3], ["a"])
#
#
#   class ExpectationError < StandardError
#     def initialize(message = nil, backtrace = [])
#       super(message)
#       filter = BacktraceFilter.new "kk"
#       set_backtrace(filter.filtered(backtrace))
#     end
#   end
#
#   begin
#     raise "Hi! I am a random runtime error"
#   rescue => e
#     p e.message
#     puts e.backtrace.to_yaml
#   end
#
#   class CustomError < StandardError
#     attr_reader :object
#
#     def initialize(object)
#       @object = object
#     end
#   end
#
#   begin
#     raise CustomError.new("an object"), "a message"
#   rescue CustomError => e
#     puts e.message # => "a message"
#     puts e.object # => "an object"
#   end
# end


=begin
# todo: sort through this mess and make necessary error classes!

RF000	"SOFTFALL ,Shell Message <Renters>"
RF201	"HARDFALL, Shell Message <Renters>"
RF301	"GIS is Down (HARDFALL) "
RF202	"Invalid Address Location (Ineligible protection Class)(SOFTFALL)"
RF302	"Invalid Address Location (HARDFALL)"
RF203	"Ineligible Home Day Care = YES (SF)(SOFTFALL)"
RF204	"Ineligible Fire Claims  (HARDFALL)"
RF205	"Ineligible Insurance Claims = Theft/Burglary (SOFTFALL)"
RF206	"Ineligible Insurance Claims = 2 NON-weather related (SOFTFALL)"
RF207	"Ineligible Insurance Claims = 3 or more insurance claims - irrespective of weather relatedness (SOFTFALL)"
RF208	"Ineligible for Foreclosure  (BMSG1142)(SOFTFALL-FALL)"
RF209	"Non-Renewal or Cancelled for Other Than non-payment of premium in past 5 years(SOFTFALL)"
RF210	"Animal indicated - DOG w/ Purebred or Mix = YES w/ AKC indicated(SOFTFALL)"
RF211	"Animal indicated - DOG w/ Purebred or Mix = NO  w/ AKC indicated(HARDFALL)"
RF212	"Indicated Dog BITE history (HARDFALL)"
RF213	"Animal indicated - Wild or Non-Domestic (ex. Antelope, Ostrich, Raccoon) (HARDFALL)"
RF214	"Animal indicated -Non-Domestic Cat (ex. Bobcat, Tiger)(HARDFALL)"
RF215	"Animal indicated -Poisonous Snake or Reptile (ex. Rattlesnake, Viper, Alligator)(HARDFALL)"
RF216	"Swimming pool no-latching gate (swimming pool) (SOFTFALL)"
RF217	"In ground swimming pool no-latching gate  (SOFTFALL)"
RF218	"Trampoline (fencing) (SOFTFALL)"
RF219	"Trampoline (no tie down) (SOFTFALL)"
RF220	"Residence indicated as Mobile Home (HARDFALL)"
RF221	"Commercial Business on premises (SOFTFALL)"
RF222	"Thermostat HARDFALLfall missing(HARDFALL)"
RF016	"Bind Product suspension  (SOFTFALL)"
RF223	"Felony Conviction indicated (HARDFALL)"
RF013	"Payment System unavailable(SOFTFALL)"
RF053	"Unspecified Error while processing billing account /Technical exceptions(SOFTFALL)"
RF054	"Rating system unavailable (SA rating issue)(SOFTFALL)"
# NEW
RF224 "( Renter is   not using this code at this point of time. We will fire 010 and 012. This code can be used in future if we add any other severity besides 40 & 50.)"	"Information obtained from reports (i.e. PLH)  (SOFTFALL)"
RF225	"Current Nationwide policyholder (SOFTFALL)"
RF226	"If construction type is Log (SOFTFALL)"
RF227	"If Fireplace type is 'Insert' (SOFTFALL)"
RF228	"Supplemental heating is anything other than 'Solar' / 'Fireplace' (SOFTFALL)"
RF229	"Wildfire very high risk ( HARDFALL)"
RF230	"Wildfire high risk ( Softfall)"
RF231	"Poor quality address (SOFTFALL)"
RF303	"Routing number of attempts exceeded  (SOFTFALL)"
RF304	"HP extreme down"
RF002	"Unable to order CBR"
RF003	"Unable to order PLH"
RF009	"Rating System unavailable/SRM down"
RF010 "SRM Eligibility rule w/severity 40"
RF012	"SRS Eligibility rule w/severity 50"
RF017	"Policy Number system is unavailable"
RF005	"Abend-Rating system unavailable"
RF099	"If ZZZ is used in the first or the last name(softfall)"
RF008	"Ineligible county (coastal)"
RF060	"Ineligible Address Location (Managed Growth Zone) - SOFTFALL"
RF244	"Ineligible more than ONE water claim (SOFTFALL)"
RF245	"Animal indicated - Exotic, wild or non-domesticated animals capable of causing harm(HARDFALL)"
RF246	"Animal indicated - Venomous spider, lizard or large reptile(HARDFALL)"
=end