require 'yaml'
if __FILE__ == $0

# TIMING (to help Profiling)
# Thanks MatLab! :)
  def tic
    $tic=Time.now
    #print "TIC initiated -->\n" if verbose_messages
  end

  def toc
    $toc=Time.now
    #print "Elapsed time : #{$toc-$tic}\n" if verbose_messages
    p $toc-$tic #watch out
  end

  def yp(obj)
    print obj.to_yaml
  end

# ----------------------------------------------------------------------------

class NonLinSearch
  def initialize(file)
    # file can either be a File.something or Dir containing "/nav_paths.yml" and "/page_ids.yml"!!
    @file = file
    @file += "/nav_paths.yml" unless file[/\.(\w+)$/, 1]
    @nav_doc =YAML.load_file(@file)
    raise "empty hash in #{@file.inspect}" if @nav_doc.empty?
    @nav_doc.update(@nav_doc) { |k, v| parse_to_a v if v }
  end

  def show(doc=@nav_doc)
    doc.each { |k, v| print "#{k} => #{v}\n" }; print "\n"
  end

  def parse_to_a(ary)
    ary.split(',').map(&:strip)
  end

  def val_debug(str, val)
    print " #{str} -> #{val}\n" if $loud
    # yp " #{str} -> #{val}\n"
  end

  def warn(str)
    print "\n#{'-'*50}\n#{str}\n" if $loud
    # yp " #{str} -> #{val}\n"
  end

  def get_next_level_list(item)
    nxt_list =[]
    list     = @nav_doc
    if list[item] && !list[item].empty?
      # print("#{item} is good\n")
      nxt_list= list[item]
    else
      # print("hmm, #{item} is an end!\n")
    end
    val_debug "next from #{item}", nxt_list # good debug place
    nxt_list
  end

  def build_path_from(hsh, prev_list)
    paths = []
    val_debug "  ==  prev list ", prev_list
    prev_list.each { |path|
      if hsh[path.last]
        hsh[path.last].each { |nxt|
          if @done_list.include?(nxt)
            # print("repeating #{path.last}")
            # uncomment below for stupid deep cyclic loops
            # paths << [path, nxt].flatten # << warn SENSITIVE
            # paths << path # comment if above is uncomment.. else.. KABOOM!!
            paths << ($deep ? [path, nxt].flatten : path) # $go_deep override
          else
            paths << [path, nxt].flatten
          end }
      else
        paths << path
      end
    }
    paths
  end

  def paths(start="from", dest="to")
    from_list = [start]
    @done_list = next_list
    next_list = next_itms from_list
  end
  def all_paths(start="from", dest="to")
    (warn "Hey.. thats cheating.. i won't map from and to #{start.inspect}!!"; return) if start == dest
    (warn "No #{start.inspect} found in #{@file.inspect}'s Hash'"; return) unless @nav_doc[start]
    (warn "No #{dest.inspect} found in #{@file.inspect}'s Hash'"; return) unless @nav_doc.flatten.flatten.include? dest # hmm, do we need the key!
    i              = 0
    from           =[start]
    master_hash    = {}
    master_hash[0] = @done_list =[from]
    loop do
      interim    ={}; i+=1
      @done_list = @done_list.flatten.uniq
      val_debug "@done_list ",@done_list
      from.each { |itm| interim[itm] = get_next_level_list itm }
      interim.delete_if { |k, v| (v and v.empty?) } #todo questionable..
      val_debug "  ==  interim ", interim
      master_hash[i] = build_path_from interim, master_hash[i-1]
      # val_debug "master_hash",master_hash
      from           = interim.values.uniq[0]

      # Last steps ....
      @done_list << from
      # val_debug "-- from",from
      # val_debug "done_list",@done_list.flatten
      # todo: enable this for non deep search
      # break if master_hash[i].flatten.include? dest # << Fails for loop around
      # break if i==5 # << SENSITIVE

      warn "found" if master_hash[i].index { |a| a.last == dest } # means atleast one result is the found!
      warn "search size reached" if i > @nav_doc.size # << SENSITIVE
      warn "eqbm reached" if master_hash[i] == master_hash[i-1] # << SENSITIVE # means equilibrium reached!

      break if master_hash[i].index { |a| a.last == dest } # means atleast one result is the found!
      break if i > @nav_doc.size # << SENSITIVE
      break if master_hash[i] == master_hash[i-1] # << SENSITIVE # means equilibrium reached!
    end
    # print "\ntook #{i} runs\n"
    warn("Man! no possible routes found at all!\n #{from} to #{dest}\n") unless master_hash[i]
    master_hash[i]
  end

  private :get_next_level_list, :build_path_from, :all_paths

  # cosmetics ..............
  def show_possible_paths(from="from", dest="to")
    all_path_list   = all_paths(from, dest)
    potential_route = []
    all_path_list.each { |path|
      # potential_route << path if path.include?(from) and path.include?(dest)
      potential_route << path if path.include?(from) and path.include?(dest)
    } if all_path_list
    warn("Man! no possible routes found!\n #{from} to #{dest}\n") if potential_route.empty?
    potential_route.uniq
  end

# purely for testing
#   and just aesthetics
  def draw_path(start="from", dest="to")
    all_list = show_possible_paths start, dest
    (warn "No paths to Draw! \n #{start} to #{dest}\n"; return) if !all_list or all_list.empty?
    print "\nPaths: #{start} -> #{dest}\n"
    all_list.each_with_index { |path, i| print "#{i+1} : "+path.join(" - "); print "\n" }
  end

  if __FILE__ == $0
    def take_me(from_to_via, obj=nil)
     # print from_to_via.class
      via_list = case from_to_via[:via].class.to_s
                   when /Array/ then
                     from_to_via[:via]
                   when /String/ then
                     from_to_via[:via].split(',').map(&:strip)
                   else
                     []
                 end
      via_list.insert(0, from_to_via[:from])
      via_list.insert(-1, from_to_via[:to])
      paths = {}
      n     =via_list.size-1
      n.times { |i| paths[i] = show_possible_paths(via_list[i], via_list[i+1]) }
      yp paths
    end
  end
end

if __FILE__ == $0
  $loud = true
  tic
  # a=NonLinSearch.new('test.yml')
  # a=NonLinSearch.new(File.dirname(__FILE__))
  # # a.all_paths("a","f")
  # # p a.show_possible_paths
  # # p a.show_possible_paths("a", "f")
  #
  # yp a.all_paths("a", "c")
  # yp a.show_possible_paths("a", "e")
  # yp a.draw_path("a", "e")
  #
  # a.draw_path("a", "g")
  # a.draw_path("g", "e")
  # a.draw_path("e", "f")
  # a.draw_path("a", "f")
  # a.draw_path("m", "o")
  # # a.draw_path("PniPage", "o")
  #
  # # a.draw_path("a", "a") #known issue.. but i'm not looking for this!
  # # a.draw_path("o", "o") #i mean no issue.. coz i'm handling this on step level!!! also, this is stupid!
  #
  # # yp a.all_paths("o", "m")
  # # yp a.show_possible_paths("m", "o")
  # # yp a.show_possible_paths("a", "e")
  #
  # a=NonLinSearch.new('serv.yml')
  # a.draw_path("IAM", "ReviewAndSubmit")
  # a.draw_path("IAM", "Drivers")
  # a.draw_path("IAM", "RemoveDriver")
  #
  # a.draw_path("QuoteStartPage", "QuotePage")
  # # a.draw_path("QuotePage", "QuoteStartPage") # interesting!
  # a.draw_path("QuotePage", "PniPage")
  # a.draw_path("PniPage", "SoftfallPage")

  # ho_east_test
  # $deep = true
  a=NonLinSearch.new('nav_paths.yml')
  # a.take_me({from: "PniPage", to: "QuotePage"})
  a.take_me({from: "QuotePage", to: "QuoteStartPage"})
  # a.take_me({from: "QuotePage", to: "PniPage", via: "SoftfallPage"})
  # a.take_me({from: "PniPage", to: "QuotePage", via: "GeneralInformationPage"})
  # a.take_me({from: "PniPage", to: "QuotePage", via: "VerifyInformationPage,PropertyInformationPage"})
  # a.take_me({from: "PniPage", to: "QuotePage", via: %w"VerifyInformationPage PropertyInformationPage"})

  #note to ahmad... THERE IS NO PAGE GOING TO ITSELF HERE PLEASE!!
  # $deep = true
  # auto_test
  # a=NonLinSearch.new('auto.yml')
  #works
  # a.take_me({from: "PNIPage", to: "VerifyInformationPage"})
  # a.take_me({from: "PNIPage", to: "QuoteCoveragesPage"})
  # a.take_me({from: "PNIPage", to: "AdditionalVehicleInformationPage"})
  # a.draw_path("PNIPage", "PaymentPlansPage") #cool!
  # a.draw_path("PNIPage", "PaymentPlansPage") #cool!
  # a.take_me({from: "PNIPage", to: "PaymentPlansPage"}) #cool!
  # needs work :( deep cycles only working!!
  # a.take_me({from: "QuoteCoveragesPage", to: "PaymentConfirmationPage"})
  # a.take_me({from: "PNIPage", to: "PaymentConfirmationPage"})
  # a.take_me({from: "PNIPage", to: "ESignPage"})
  # a.take_me({from: "PNIPage", to: "PolicySummaryPage"})
  # a.draw_path("PNIPage", "PolicySummaryPage") #cool!

  # auto_bak_test
  # a     =NonLinSearch.new('auto_bak.yml')
  # a.take_me({from: "PNIPage", to: "QuoteCoveragesPage"})
  # a.take_me({from: "AddDriverPage", to: "PNIPage"})
  # a.take_me({from: "QuoteCoveragesPage", to: "PNIPage"}) # todo see proper search lines
  # a.take_me({from: "PolicySummaryPage", to: "PNIPage"})

  toc
end
end