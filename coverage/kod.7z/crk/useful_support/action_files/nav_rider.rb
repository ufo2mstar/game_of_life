require_relative 'non_lin_search/non_lin_algo'
require_relative 'yaml_rider'

class NavRider < NonLinSearch
include YamlRider
  def initialize app_stuff_dir, browser
    dir            = app_stuff_dir
    nav_paths_file = "#{dir}/nav_paths/#{lob.downcase}.yml" # assumption on file names
    super nav_paths_file
    @ids_file = dir + "/page_ids.yml"
    @ids_doc  = erb_eval(@ids_file)
    raise BadInputDataError, "empty hash in #{@ids_file.inspect}" if @ids_doc.empty?
    @browser = browser
  end

  def take_me(from_to, obj)
    # paths = show_possible_paths(from_to[:from], from_to[:to])
    raise CodePush, "CodePush goin on at #{Time.now} in '#{app_env}'\n" if from_to[:from] =~ /CodePushPage/
    paths = all_paths(from_to[:from], from_to[:to])
    path  = paths.first
    p "Voyager_path : \n#{ path.join(' -> ')}\n", :c #if verbose_mode
    raise NoNavPaths, "\nNo way Jose! \nno path #{from_to}\n" if path.empty?
    path[1..-1].each { |to_page| travel_to to_page, obj }
  end

  def travel_to to_page, obj
    loop do
      last_page = what_page_am_i_on @browser
      (to_page, new_target = new_target, nil) if new_target
      p "Next to -> #{to_page}", :m
      obj.instance_variable_get(:@current_page).go_to to_page
      # obj.instance_variable_get(:@current_page).wait_for_it "from traveller"
      got_to_page = what_page_am_i_on @browser
      got_to_page == to_page ? obj.on_page(to_page) : new_target = navigation_handle(got_to_page, to_page, last_page, obj)
      # app_specific_handle obj,@page_text if defined? app_specific_handle
      new_target ? (got_to_page = what_page_am_i_on @browser; obj.on_page(got_to_page) unless last_page == got_to_page) : break
    end
  end

  def navigation_handle(got_to_page=nil, to_page=nil, from_page=nil, obj=nil)
    raise SetupError, "\nPlease Define this method [navigation_handle] for your app!\nUsually under your feature/support"
  end

  alias_method :conditional_exception, :navigation_handle

  def what_page_am_i_on browser=@browser
    @page_text = browser.text.squash rescue(sleep(1); browser.text.squash)# some wierd handle!..goto test it sometime
    page_order = @ids_doc.keys
    search_ary = []
    # page_order.each { |a| search_ary << "(#{Regexp.escape(@ids_doc[a.to_s])})" }
    page_order.each { |a| search_ary << "(#{(@ids_doc[a.to_s])})" }
    search_str = /#{search_ary.join '|'}/
    res        = @page_text.match(search_str).to_a[1..-1]
    raise SetupError, "No Matched found\nFor : '#{search_str}'\n In : '#{@page_text}'" unless res
    l_res = res.index { |a| a != nil }
    r_res = res.rindex { |a| a != nil }
    conditional_exception unless l_res
    raise StupidError, "matching more than one!! \nbadly done naren :(\n #{res.to_yaml}" unless l_res == r_res
    page_order[r_res].to_s
  end

end

if __FILE__ == $0 # warn: hmm.. are these gonna be out unit test suites?
  file_loc      = File.dirname(__FILE__)
  @browser      = Watir::Browser.new :chrome
  @navigator    = NavRider.new(Dir[file_loc+"/../../pages/**/*east/app_stuff"].first, @browser)
  now_at        = "QuoteStartPage"
  intended_page = "QuotePage"
  @navigator.take_me(from: now_at, to: intended_page)
end
