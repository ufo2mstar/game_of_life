require 'yaml'
state_abbr_keys = YAML.load_file('your_configs/state_abbrs.yml')
STATE_EXPN      = state_abbr_keys
STATE_ABBR      = STATE_EXPN.invert

BROWSERS = %w{chrome firefox safari ie phantomjs remote}
VIEWS    = %w{desktop tablet mobile}
# ---------------------------------------------------------------------------------------------

# How this works is Working:
# ENV["this"]
# => val
#
# envize
# ENV_this
# => "val"
# todo : remove this please! just write your ENV['x']s
def envize env = ENV
  env.each { |k, v| eval "ENV_#{k} = ENV['#{k}'].to_s.empty?? nil:'#{v.to_s}'"; dp "ENV[#{k}] == ENV_#{k}" => "#{eval "ENV_#{k}"}" if $verbose_mode }
  "ENV-ized!"
end

# ---------------------------------------------------------------------------------------------

require_relative 'rake_methods.rb'
Dir[File.dirname(__FILE__)+"/../**/formatting_files/*.rb"].each { |f| require f }

# ENV['i_am'] ||= 'sivasn1' # BatMan / IronMan!
# raise "\nWho are you dude? \nput it in ENV['i_am'] = your_nw_short_name not BatMan / IronMan! please\n\n" unless ENV['i_am']

def init_envs env = {}, make_no_output = nil
  kod          ={
      # non - optional
      'lob'             => "",
      'and_tags'        => "",
      'app_env'         => "",
      'states'          => "",
      'browser_types'   => "",
      'browser_size'    => "desktop",
      'output_folder'   => nil,
      # semi - optional
      'splunk_it'       => nil,
      'flash_fill'      => nil,
      # 'fill_your_email' => "gctest42+app_env@gmail.com",
      'doing'           => "",
      'or_tags'         => "",
      # 'color'           => "do for non-hudson outputs",
      'color'           => nil, #this for non local jobs
      'verbose'         => nil,
      # optional
      'ansicon'         => "ComeOn!",
      'LANG'            => "en_US.UTF-8",
      'LC_ALL'          => "en_US.UTF-8",
      'NLS_LANG'        => 'AMERICAN_AMERICA.UTF8',
      'CUCUMBER_COLORS' => "undefined=yellow:pending=yellow,bold:pending_param=green:failed=red:failed_param=cyan:passed=green:passed_param=cyan,bold:skipped=magenta:skipped_param=cyan:comment=grey:tag=blue"
  }
  # env.each { |k, v| (ENV[k]=v.to_s; envize({k => v.to_s})) unless ENV[k] or !v }

  name         = "#{(ENV['user']||ENV['USER']||ENV['User']|| ENV['username']).downcase}_envs.yml"
  kod          =kod.merge(YAML.load_file(name)) if File.exists?(name) rescue puts "Is your #{name} alrite?"
  override_env = {}; kod.keys.each { |key| override_env[key]=ENV[key] if ENV[key] }
  kod                    =kod.merge(override_env).merge(env)
  kod['fill_your_email'] = kod['fill_your_email'].gsub('+app_env', "+#{kod["app_env"]}") if kod['fill_your_email']

  p "Pre - Envizing", :m if $verbose_mode
  # todo: ok.. i'm beginnin to repent this 'envize' thing now... hmmmm....
  # kod.each { |k, v| (ENV[k]=v.to_s; envize({k => v.to_s})) if v }
  kod.each { |k, v| (ENV[k]=v.to_s if (ENV[k].to_s.empty?); envize({k => v.to_s})) if v } # making ENV[k] higher priority.. waiting for when its gonna backfire!
  p "\nPost - Envizing", :m if $verbose_mode
  dp kod if $verbose_mode # for debug

  # todo.. the below are done internally in init_envs
  $state_array  = parse_and_verify(:states, ENV_states)
  $browser_array= parse_and_verify(:browsers, ENV_browser_types)
  $views = parse_and_verify(:views, ENV_browser_size)
  $app_env = ENV_app_env

  require_relative 'output_folder' # create output folder
  create_output_directories unless make_no_output
end

