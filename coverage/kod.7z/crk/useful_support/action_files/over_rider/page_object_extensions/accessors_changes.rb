module PageObject

  module Accessors

    #
    # adding 'name_selected?' method to label.
    # This is to check the value of the radio button under the label
    # as we are identifying radios as labels in the new ui.
    # This method will .parent of the label (which will be the div containing both the label and the radio)
    # and then do a .radio which will get the radio element and then checks to see if the radio is set
    #

    def label(name, identifier=nil, &block)
      define_method(name) do
        return platform.label_text_for identifier.clone unless block_given?
        self.send("#{name}_element").text
      end
      define_method("#{name}_selected?") do
        return call_block(&block) if block_given?
        self.send("#{name}_element").parent.element.radio.set?
      end
      define_method("#{name}_element") do
        return call_block(&block) if block_given?
        platform.label_for(identifier.clone)
      end
      define_method("#{name}?") do
        return call_block(&block).exists? if block_given?
        platform.label_for(identifier.clone).exists?
      end
      alias_method "#{name}_label".to_sym, "#{name}_element".to_sym
    end


    #
    # adds two methods - one to retrieve the text from a legend,
    # another to return the legend element
    #
    # @example
    #   legend(:name, :id => 'legend_for_name')
    #   # will generate 'name' and 'name_element' methods
    #
    # @param name [String] the name used for the generated methods
    # @param [Hash] identifier how we find a div.  You can use a multiple paramaters
    #   by combining of any of the following except xpath.
    #   Only tested using the identifier key :id
    # @yield optional block to be invoked when element method is called
    #
    def legend(name, identifier=nil, &block)
      define_method(name) do
        return platform.legend_text_for identifier.clone unless block_given?
        self.send("#{name}_element").text
      end
      define_method("#{name}_element") do
        return call_block(&block) if block_given?
        platform.legend_for(identifier.clone)
      end
      alias_method "#{name}_legend".to_sym, "#{name}_element".to_sym
      end

    #
    # adds one method - to return the input element
    #
    # @example
    #   input(:name, :id => 'input_for_name')
    #   # will generate 'name' and 'name_element' methods
    #
    # @param name [String] the name used for the generated methods
    # @param [Hash] identifier how we find a div.  You can use a multiple paramaters
    #   by combining of any of the following except xpath.
    #   Only tested using the identifier key :id
    # @yield optional block to be invoked when element method is called
    #
    def input(name, identifier=nil, &block)
      define_method("#{name}_element") do
        return call_block(&block) if block_given?
        platform.input_for(identifier.clone)
      end
      alias_method "#{name}_input".to_sym, "#{name}_element".to_sym
    end

  end
end