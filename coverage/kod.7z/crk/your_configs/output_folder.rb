if __FILE__ == $0
  ENV["output_folder"] = 'C:/All_my_tests'
  require '../useful_support/formatting_files/cosmetics'
  ENV["color"] = 'grr'
  require 'fileutils'
  ENV['verbose'] = 'true'
end

# Lets have this as the only method we make all the directories with!
# coz when we use Dir::mkdir(name) unless File.exists?(name);
# wierdly MAC and Linux had some issues with '/' on parent directories
def make_dir(name)
  FileUtils::mkdir_p(name) unless File.exists?(name)
end

# Variables setup --------------------------------------------------------------------------------
$timestamp  = Time.now.strftime "%Y-%m-%d_%H-%M-%S_"
date_string = Time.now.strftime("%m-%d-%Y")

$output_folder = (ENV["output_folder"] || "features/output") + "/#{date_string}/"
p "output_folder => #{$output_folder}" if ENV['verbose']
# ENV["output_folder"] = $output_folder[0..-2]

# Output Directories -----------------------------------------------------------------------------
def create_output_directories
# this is the Main output directory!
  make_dir($output_folder)

# Make other support directories.. (for future use maybe...
# comment this out and they won't even be created anymore!)
  $make_other_reports = nil || "yes,please"

  if $make_other_reports
    make_dir("#{$output_folder}_other_reports/")
    $output_folder_usage="#{$output_folder}_other_reports/usage/"; make_dir($output_folder_usage)
    $output_folder_progress="#{$output_folder}_other_reports/progress/"; make_dir($output_folder_progress)
    # todo: woow.. dat screenshot size doh!
    # $output_folder_jason="#{$output_folder}_other_reports/jason/"; make_dir($output_folder_jason)
  end
end

# Cleanup stuff --------------------------------------------------------------------------
def verbose_mode #todo.. think of integrating variables.rb more gracefully
  ENV['verbose']
end

def flush_output
  p "\nFlushing da output folder ->", :gy
  now_time   = Time.now.strftime "_%H-%M-%S"
  old_output = $output_folder.gsub(/\/$/, '')
  new_output = $output_folder.gsub(/\/$/, now_time)
  if File.exists?(old_output)
    p "No. of Htmls / Runs : #{htmls =Dir.glob("#{old_output}/*.html").size}", :m
    yp Dir.glob("#{old_output}/*.htm*"), :bl
    FileUtils::mv(old_output, new_output)
    p "Changed\n#{old_output}\nto\n#{new_output}", :g
  else
    p "No such Dir #{$output_folder}\nLife was Just Made a lil easy! ;)", :cy
  end
end

def wipe_htmls
  verbose_mode = true # comment this line for proper verbose_moding
  p "\nDumping empty/incomplete htmls ->", :gy if verbose_mode
  if File.exists?($output_folder.gsub(/\/$/, ''))
    this_out = $output_folder
    dump_out = this_out+'html_dump'; make_dir dump_out
    html_files = Dir.glob(this_out+'_*.html') # Careful.. you need the _file_name.html for clarity
    p "#{html_files.size} - Found", :m if verbose_mode
    mv =-> _html, html { FileUtils.mv(_html, html) rescue pr 'errored - ', :r }
    html_files.each do |_html|
      html_content = File.readlines(_html)
      if html_content.empty? or !html_content[-1][/<\/html>$/]
        dump_html = _html.sub(this_out, dump_out+'/')
        mv[_html, dump_html]
        p "Dumping #{dump_html}", :br if verbose_mode
        # elsif html_content[-1][/<\/html>$/]
      else
        html = _html.sub(/#{this_out}_/, this_out)
        mv[_html, html]
        p "Keeping #{html}", :bl if verbose_mode
      end
    end
  else
    p "No #{$output_folder} found!.. interesting.....", :cy
  end
end


def delete_cache
  p "Removing cache from #{ENV['TEMP']} ->", :gy if verbose_mode
  temp       = ENV['TEMP'].gsub('\\', '/')
  crap_files = Dir.glob(temp+'/*scoped*')+Dir.glob(temp+'/*etil*')
  crap_files.each do |tmp_crap|
    FileUtils.rm_r(tmp_crap) rescue ((p " !!  unable to rm TEMP folder: #{tmp_crap}", :br; next) if verbose_mode)
    p " **  removed TEMP folder: #{tmp_crap}" if verbose_mode
  end
end

if __FILE__ == $0
  ENV_verbose = true
  wipe_htmls
  delete_cache
end