module OutputFiler
  def initialize (browser, scenario, obj)
    @scenario               = scenario
    @browser                = browser
    # @screenshot_folder_name = Time.now.strftime("%Y-%m-%d_%H-%M-%S")+'_'+state_abbr.gsub(" ", "_").upcase + '_' + @scenario.name.gsub('|', '=').gsub('"', '\'').gsub(/[,#():\/\\ <>\n\r\t\?]+/, "_")[0..90]
    @screenshot_folder_name = Time.now.strftime("%H-%M-%S")+'_'+state_abbr.gsub(" ", "_").upcase + '_' + @scenario.name.gsub('|', '=').gsub('"', '\'').gsub(/[,#():\/\\ <>\n\r\t\?]+/, "_")[0..90]
    @output_folder          = $output_folder
    @scenario_folder        = $output_folder + @screenshot_folder_name+'/'
    make_dir(@scenario_folder) if screenshots_on or profiling_mode # to not needlessly make Blank folders!
    $scenario_folder = @scenario_folder
    @screenshot_num  = 0
    @obj             = obj
  end
end

class OutputRider
  include OutputFiler

  def save_screenshot(current_page, custom_name=nil, wanna_embed=false)
    curr_page_name = current_page.class.to_s
    if screenshots_on and curr_page_name !~ /NilClass/
      screenshot_file = (Time.now.strftime "%Y-%m-%d_%H-%M-%S" + '_' + browser_type + '_' + (custom_name||curr_page_name))[0..90]+ ".png"
      @png_full_link  =@scenario_folder+screenshot_file; @png_loc_link='./'+@screenshot_folder_name+'/'+screenshot_file
      p "Snapping #{@png_full_link}", :m #if verbose_mode
      case OS
        when "windows", "macosx"
          begin
            # @browser.driver.save_screenshot(@png_full_link) # also can do this.. just fyi
            @browser.screenshot.save (@png_full_link)
            put_screenshots_in_html @obj, current_page, nil, wanna_embed
            # put_text_in_html @obj
          rescue Exception => e
            p "\nNo Screenshot for you\ncoz\n#{e.message.squish}", :r
          ensure
            @screenshot_num += 1
          end
        else
          puts "\n Screenshot functionality has not been evaluated for #{@os}\n" if verbose_mode
      end
    end
  end

  def put_screenshots_in_html(page_steps_obj, current_page, take_screenshot=nil, wanna_embed=false)
    # return if 1
    begin
      save_screenshot(current_page) if take_screenshot
      text_to_link = current_page.class == String ? current_page : current_page.class.to_s
      # image with . source link >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      # page_steps_obj.embed("#{@png_loc_link}", "image/png", text_to_link)
      # image with fill source link >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      page_steps_obj.embed("#{@png_full_link}", "image/png", text_to_link)
      # embedded image >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if wanna_embed
        @encoded_img = @browser.driver.screenshot_as(:base64) # transferred to 'save_screenshot'
        # $encoded_img = @encoded_img
        page_steps_obj.embed("data:image/png;base64,#{@encoded_img}", 'image/png', text_to_link)
      end
    rescue Errno::ENOENT
      warn "\nAm getting some 'Errno::ENOENT' error in the screenshoting step.. take a look in 'OutputRider'\n"
      #todo: i donno if i should work on fixin this
    end
  end

  # def put_text_in_html(obj)
  #   $txt.each {|line| obj.puts "#{line}"}
  #   $txt = [] # flush $txt
  # end

  def put_link_in_html(page_steps_obj, current_page, link_location)
    text_to_link = current_page.class == String ? current_page : current_page.class.to_s
    text_to_link += "_link"
    page_steps_obj.embed("#{link_location}", "text/plain", text_to_link)
  end

  def get_links(browser)
    head_url=browser.url.gsub(/(.*)\/.*\?/, "\1/InterfaceViewer.jsp?quoteID=#{$quoteid}&quote=Search+by+Quote+ID")
  end

  def store_link_in_html(obj, browser)
    iv_url=self.get_links(browser)
    obj.puts "<a target='_blank' href=\"#{iv_url}\">to View The Interface</a>"
  end

  def store_link_as_a_file(scenario=@scenario, browser=@browser)
    if scenario.failed? and head_url=browser.url[/(.*)\/.*\?/, 1] and show_n_store_iv_stuff #and verbose_messages
      iv_url        =self.get_links(browser)
      link_file_name="#{$scenario_folder || "features/output/"}#{$timestamp}-#{abbreviated_state}-#{$quoteid||"SessID"}-IV.url"
      #todo: feed this into the html too.. not to mention the DBs
      gaud          ='-'*(link_file_name.size+4)
      print "\n#{'~'*140}\nWanna open InterfaceViewer for '#{$quoteid ? $quoteid : $sessionid}' ?\n"
      print "open #{link_file_name} \n or \n#{iv_url}\n#{'~'*140}\n"
      #print "#{" "*14}#{gaud}\nclick here>>>>| #{link_file_name} |<<<< click here\n#{" "*14}#{gaud}\n" #TODO : one day...
      File.open(link_file_name, 'a') { |file| file.write("[InternetShortcut]\nURL=#{iv_url}") }
    else
      warn "\nSorry.. No IVy for you.." if scenario.failed? and not show_n_store_iv_stuff
    end
  end

  def store_policy_details()
    txt         = Time.now.strftime "%D - %H:%M %Ss => Policy #: #{$policyno} Policy Premium: $#{$payment} <- ( Quote ID: #{$quoteid} )"
    payment     = $payment.gsub(',', ''); installment = $installment.gsub(',', '')
    script_name = @scenario.name.gsub(',', '-')
    # todo: think about adding title row if file does not exist
    bill_title  = "Date,Time,State,Quote ID,Payment Option,Payment method,Premium Total,Installment Premium,,Scenario"
    bill_txt    = Time.now.strftime "%D,%H:%M %Ss,#{app_env},#{env_state},#{$policyno},#{$policyno_out_of_bounds_flag},#{$payment_plan},#{$payment_method},$#{payment},#{installment},#{$quoteid},#{script_name}"
    File.open("#{@output_folder}#{Time.now.strftime "%F"}-PolicyDetails-#{env_state}.txt", 'a') { |file| file.puts(txt) }
    # File.open("#{@output_folder}#{Time.now.strftime "%F"}-PolicyDetails-#{env_state}.csv", 'a') { |file| file.puts(txt) }
    file_name = "#{@output_folder}#{Time.now.strftime "%F"}-BillingDetails.csv"
    File.open(file_name, 'a') { |file| file.puts(bill_title) } unless File.exists? file_name
    File.open(file_name, 'a') { |file| file.puts(bill_txt) }
  end

  def store_quote_details()
    txt         = Time.now.strftime "%D - %H:%M %Ss => Policy #: #{$policyno} Policy Premium: $#{$payment} <- ( Quote ID: #{$quoteid} )"
    estimate     = $estimate.gsub(',', '') rescue 'not_rated'
    script_name = @scenario.name.gsub(',', '-')
    # todo: think about adding title row if file does not exist
    quote_title  = "Date,Time,State,QuoteID,PolicyPremium,script_name,Entered Data"
    quote_txt    = "#{ Time.now.strftime "%D,%H:%M %Ss"},#{env_state},#{$quoteid},#{estimate},#{script_name}#{$entered_info}"
    file_name = "#{@output_folder}#{Time.now.strftime "%F"}-QuoteDetails.csv"
    File.open(file_name, 'a') { |file| file.puts(quote_title) } unless File.exists? file_name
    File.open(file_name, 'a') { |file| file.puts(quote_txt) }
  end

  # todo: consolidate file generation things
  def store_prot_dev_details()
    prot_dev_info = $prot_device_info.gsub('|',',') rescue 'DoNotHave'
    script_name  = @scenario.name.gsub(',', '-')
    feature_name = @scenario.test_steps[0].source[0].name
    example_row  = @scenario.test_steps[0].source[3].instance_variable_get(:@data).to_s.gsub(',', '-')
    prot_dev_title = "Date,Time,App_Env,State,QuoteID,feature_name,Scenario,example_row,prot_dev_info"
    prot_dev_txt   = Time.now.strftime "%D,%H:%M %Ss,#{app_env},#{env_state},#{$quoteid},#{feature_name},#{script_name},#{example_row},#{prot_dev_info}"
    file_name = "#{@output_folder}#{Time.now.strftime "%F"}-ProtDevDetails-#{env_state}.csv"
    File.open(file_name, 'a') { |file| file.puts(prot_dev_title) } unless File.exists? file_name
    File.open(file_name, 'a') { |file| file.puts(prot_dev_txt) }
  end

  def store_claims_details()
    claims_info = $claim_info.join('_') rescue 'DoNotHave - PLH data used probably'
    srs_info = $srs_rules_info.join('_') rescue 'DoNotHave - No SRS response probably'

    script_name  = @scenario.name.gsub(',', '-')
    feature_name = @scenario.test_steps[0].source[0].name
    example_row  = @scenario.test_steps[0].source[3].instance_variable_get(:@data).to_s.gsub(',', '-')
    claims_title = "Date,Time,App_Env,State,QuoteID,feature_name,Scenario,example_row,Claims,SRS"
    claims_txt   = Time.now.strftime "%D,%H:%M %Ss,#{app_env},#{env_state},#{$quoteid},#{feature_name},#{script_name},#{example_row},#{claims_info},#{srs_info}"
    file_name = "#{@output_folder}#{Time.now.strftime "%F"}-ClaimsDetails-#{env_state}.csv"
    File.open(file_name, 'a') { |file| file.puts(claims_title) } unless File.exists? file_name
    File.open(file_name, 'a') { |file| file.puts(claims_txt) }
  end

  # Courtesy: Sebas the Thimming! :)
  # Gets the current html loaded in the browser window including input state.
  # Be wary of relative paths in src references of the html document.
  # TODO: make this work!
  def get_page_html (browser = @browser)
    html = nil
    begin
      begin
        html = browser.execute_script('return document.documentElement.outerHTML')
      rescue
        html ||= browser.wd.page_source
      end
      relative_base = browser.url[/^.*\//]
      html          = html.gsub(/(src|href)=("|')[^'"]*?resources\//, '\1=\2' + relative_base + 'resources/')
    rescue;
    end
    print html
    return html || ''
  end

  def send_the_email from_to_hsh ={}

    # @encoded_img = 'iVBORw0KGgoAAAANSUhEUgAABjIAAAMICAYAAABig3ykAAAgAElEQVR4nOzd+3uV5Z34++/fsiDGLAKEhJMctNAoYimCIUo4CvHUjli1B3dbau3BQXcpeKjFfqtcOiqz7djtfL+OPew4ZURti2Nba4fWjna0ztaNVSyHhFCG6Wf/kIM5PM/KWoEkd8jrvq7XVTAr63nWs1bKdd3vPPf9PwqFQgAAAAAAAKTof4z1CQAAAAAAAOQRMgAAAAAAgGQJGQAAAAAAQLKEDAAAAAAAIFlCBgAAAAAAkCwhAwAAAAAASJaQAQAAAAAAJEvIAAAAAAAAkiVkAAAAAAAAyRIyAAAAAACAZAkZAAAAAABAsoQMAAAAAAAgWUIGAAAAAACQLCEDAAAAAABIlpABAAAAAAAkS8gAAAAAAACSJWQAAAAAAADJEjIAAAAAAIBkCRkAAAAAAECyhAwAAAAAACBZQgYAAAAAAJAsIQMAAAAAAEiWkAEAAAAAACRLyAAAAAAAAJIlZAAAAAAAAMkSMgAAAAAAgGQJGQAAAAAAQLKEDAAAAAAAIFlCBgAAAAAAkCwhAwAAAAAASJaQAQAAAAAAJEvIAAAAAAAAkiVkAAAAAAAAyRIyAAAAAACAZAkZAAAAAABAsoQMAAAAAAAgWUIGAAAAAACQLCEDAAAAAABIlpABAAAAAAAkS8gAAAAAAACSJWQAAAAAAADJEjIAAAAAAIBkCRkAAAAAAECyhAwAAAAAACBZQgYAAAAAAJAsIQMAAAAAAEiWkAEAAAAAACRLyAAAAAAAAJIlZAAAAAAAAMkSMgAAAAAAgGQJGQAAAAAAQLKEDAAAAAAAIFlCBgAAAAAAkCwhAwAAAAAASJaQAQAAAAAAJEvIAAAAAAAAkiVkAAAAAAAAyRIyAAAAAACAZAkZAAAAAABAsoQMAAAAAAAgWUIGAAAAAACQLCEDAAAAAABIlpABAAAAAAAkS8gAAAAAAACSJWQAAAAAAADJEjIAAAAAAIBkCRkAAAAAAECyhAwAAAAAACBZQgYAAAAAAJAsIQMAAAAAAEiWkAEAAAAAACRLyAAAAAAAAJIlZAAAAAAAAMkSMgAAAAAAgGQJGQAAAAAAQLKEDAAAAAAAIFlCBgAAAAAAkCwhAwAAAAAASJaQAQAAAAAAJEvIAAAAAAAAkiVkAAAAAAAAyRIyAAAAAACAZAkZAAAAAABAsoQMAAAAAAAgWUIGAAAAAACQLCEDAAAAAABIlpABAAAAAAAkS8gAAAAAAACSJWQAAAAAAADJEjIAAAAAAIBkCRkAAAAAAECyhAwAAAAAACBZQgYAAAAAAJAsIQMAAAAAAEiWkAEAAAAAACRLyAAAAAAAAJIlZAAAAAAAAMkSMgAAAAAAgGQJGQAAAAAAQLKEDAAAAAAAIFlCBgAAAAAAkCwhAwAAAAAASJaQAQAAAAAAJEvIAAAAAAAAkiVkAAAAAAAAyRIyAAAAAACAZAkZAAAAAABAsoQMAAAAAAAgWUIGAAAAAACQLCEDAAAAAABIlpABAAAAAAAkS8gAAAAAAACSJWQAAAAAAADJEjIAAAAAAIBkCRkAAAAAAECyhAwAAAAAACBZQgYAAAAAAJAsIQMAAAAAAEiWkAEAAAAAACRLyAAAAAAAAJIlZAAAAAAAAMkSMgAAAAAAgGQJGQAAAAAAQLKEDAAAAAAAIFlCBgAAAAAAkCwhAwAAAAAASJaQAQAAAAAAJEvIAAAAAAAAkiVkAAAAAAAAyRIyAAAAAACAZAkZAAAAAABAsoQMAAAAAAAgWUIGAAAAAACQLCEDAAAAAABIlpABAAAAAAAkS8gAAAAAAACSJWQAAAAAAADJEjIAAAAAAIBkCRkAAAAAAECyhAwAAAAAACBZQgYAAAAAAJAsIQMAAAAAAEiWkAEAAAAAACRLyAAAAAAAAJIlZAAAAAAAAMkSMgAAAAAAgGQJGQAAAAAAQLKEDAAAAAAAIFlCBgAAAAAAkCwhAwAAAAAASJaQAQAAAAAAJEvIAAAAAAAAkiVkAAAAAAAAyRIyAAAAAACAZAkZAAAAAABAsoQMAAAAAAAgWUIGAAAAAACQLCEDAAAAAABIlpABAAAAAAAkS8gAAAAAAACSJWQAAAAAAADJEjIAAAAAAIBkCRkAAAAAAECyhAwAAAAAACBZQgYAAAAAAJAsIQMAAAAAAEiWkAEAAAAAACRLyAAAAAAAAJIlZAAAAAAAAMkSMgAAAAAAgGQJGQAAAAAAQLKEDAAAAAAAIFlCBgAAAAAAkCwhAwAAAAAASJaQAQAAAAAAJEvIAAAAAAAAkiVkAAAAAAAAyRIyAAAAAACAZAkZAAAAAABAsoQMAAAAAAAgWUIGAAAAAACQLCEDAAAAAABIlpABAAAAAAAkS8gAAAAAAACSJWQAAAAAAADJEjIAAAAAAIBkCRkAAAAAAECyhAwAAAAAACBZQgYAAAAAAJAsIQMAAAAAAEiWkAEAAAAAACRLyAAAAAAAAJIlZAAAAAAAAMkSMgAAAAAAgGQJGQAAAAAAQLKEDAAAAAAAIFlCBgAAAAAAkCwhAwAAAAAASJaQAQAAAAAAJEvIAAAAAAAAkiVkAAAAAAAAyRIyAAAAAACAZAkZAAAAAABAsoQMAAAAAAAgWUIGAAAAAACQLCEDAAAAAABIlpABAAAAAAAkS8gAAAAAAACSJWQAAAAAAADJEjIAAAAAAIBkCRkAAAAAAECyhAwAAAAAACBZQgYAAAAAAJAsIQMAAAAAAEiWkAEAAAAAACRLyAAAAAAAAJIlZAAAAAAAAMkSMgAAAAAAgGQJGQAAAAAAQLKEDAAAAAAAIFlCBgAAAAAAkCwhAwAAAAAASJaQAQAAAAAAJEvIAAAAAAAAkiVkAAAAAAAAyRIyAAAAAACAZAkZAAAAAABAsoQMAAAAAAAgWUIGAAAAAACQLCEDAAAAAABIlpABAAAAAAAkS8gAAAAAAACSJWQAAAAAAADJEjIAAAAAAIBkCRkAAAAAAECyhAwAAAAAACBZQgYAAAAAAJAsIQMAAAAAAEiWkAEAAAAAACRLyAAAAAAAAJIlZAAAAAAAAMkSMgAAAAAAgGQJGQAAAAAAQLKEDAAAAAAAIFlCBgAAAAAAkCwhAwAAAAAASJaQAQAAAAAAJEvIAAAAAAAAkiVkAAAAAAAAyRIyAAAAAACAZAkZAAAAAABAsoQMAAAAAAAgWUIGAAAAAACQLCEDAAAAAABIlpABAAAAAAAkS8gAAAAAAACSJWQAAAAAAADJEjIAAAAAAIBkCRkAACPkmrZ3I28c2DX25zcW6heviBUrslwS84pjf34AAACkR8gAABghQsZguw7kXZF3o+2asT8/AAAA0iNkAACMECFjMCEDAACASgkZAAAjRMgYTMiAUdJSGyu31fV3azGmj/V5AQDAMAgZAAAjRMgYTMiAUfLJurh6z5z+7p8as8b6vAAAYBiEDACAESJkDCZkjGNXT4+ND87qZ/nVCZwX2YQMAADOIkIGAMAIETIGG+2QUbVqSiy/dUosvrE2LvlcTdQmcA3GrYyJ8aZPJnBelP1+CRkAAIxXQgYAwAgRMgYb3ZBxTjTeUozzbpwaF3++Nj6yakpcuGXymF+DcUvIGF+EDAAAziJCBgDACBEyBhvdkFGMiz9fHbM+PT1Wbp8WH5leHYu2VI/5NRi3hIzxZcm5sfiGYn/XVEdxrM8LAACGQcgAABghQsZgoxsyJscFn6+N8zeeG9MvPjcWbKmNC1eP/TUYt4QMAABgjAgZAAAjRMgYbNQ3+66pirmfqo2P3VobH73CslKnRcgAAADGiJABADBChIzBRj1kcOYIGQAAwBgRMgCAcaM47xNx51P74rV3DsfRzlPdE+CnovPo4Tj8zmuxv+3xuPMT8zLXgG/+0u7YvTvDzr+JBf0eW4x5n7gv2va/Fu8cPhq9h4mT0XH4vXjrt/vi8S+uivoyzreSkLHgb3Zmn9/unfE3C8q9Rs3xpczn2B27v9Rc/jUZdMxizPvEnfHUvoHXJOJkx+F4762Xo+2+T8S84tDneHohoxjX/+hAHHjqzlhVX871OCdmXjppzD+3hUIhqi86NxZvnR5N98yMjQ/O+tB36qPpttq4YP05UV3Jz0JTzYD9D2pi9pw+j6mZHPXrp8SybTNiTd/jPTgzVm+fFktaq6NYM9RxJsfsa/oc46sNg0JGy1eLg/dh6HVuzCjn2syvjoW3TMu+Nl+fGosrvDZZe0PMWzL4cVWzz4l5N0yN5dvrY92Ds2Ljg/Vx0ccrfZ5JUbd+Siz9el2s/k72da6dXuHnJeO45zdl3E00fXLMaa3t9x4vv7r/53/ewPdkwznlnUPvc/d/XWt21sXK7s/r0J+f0qpmd73vK3c25L7vp3sMAADOHkIGAJC+4rK4e//BfhPopcbJw69F2539Y0PuBPq7bXFN92OKax6IX713sqxjnDryh2j7+rKSG+dWEjLyH1vJnQq7IrcTHNg16PHlRIXimgfiVwc7o5xLf+rIH6LttsaS53g6IaNx14Ho6D1YZxw88FTcuaq+xPcUo2nPnNh497S4YIyCRvWlU2L5t2ZF64AAkKV1d0Ms33JOVJXxvLO2zhzw/TNj6WWFKBQmxfRrp8fah4c+3tWPzIyVN5SKBNWx9P4ynidXXXyk5LUpxrIdZV6bhxuGONc+hrpzZPo5sXjbzIzj9lzDcp5nUkzfNDWu2F3GdXh0VrR8bUrMLDdoZBx33dY+m9TXVMWCrfWx8dHBx+p/h0zX57/fY75RLH3smqpYsHVGbHiknNc1OzbcMz0WN00u6zPbo2pxTSwdifcdAICzmpABAKSteH20HSyzYPQdHS/Ftj53CJQOGcVY9sArcaTiw5yKQy9tj8accx/fIaMYy+5+KQ5VfE064sCu/Jgx3JBRvL4tsj8Gp6Lj5ftiTub39Z/IHd2gMTnmb62PTcMIABu3T4n6IX4TPTtkTI6Ft2dN0Je2aUfe8UYqZEyKubdkT8QPea5318bcoYJAiQBRu3FarMmdpC8zZNRUxfnDuM5XPzIzll9bNfSkf4mQUfWxKbGqRDw5rZBRUx0X3zd7WO9163fqYvGQP1uTov7GGcN631vvmxbzy74zDQCAs5GQAQAkbEHc+0pH1uz1h9PYnUf7LDP14WT6K/cu6PdcpULGbX1/038Yo+PArsyYMX5Dxvvx8guvDf+anDoYP8o552GFjMZdcSDnZE4d/EncnLvMVMZE7qgEjcnxkTvK+43z3InbXVNjdomYMThkzIq19w3/mJu+UYzaQccZiZAxvNgy8NqUjBk5AaL2qumxvuQkehkhY0t1XHT3rNO4JrPiis9Wl44ZOSGjatXUEhHmdEPGOXHRvafzXs+Jqx+dEYtzfxYnx/yvNJze+/7d6bFQzAAAmLCEDAAgXZ/eF3/OmfbueLMtvr6sz6Rc/eL41H374rXDJ6Pzdw8MCgu5E+idHdHRd8+H934VT935qbhkXtdz1y9eEZ+6b1/8oeTtGqfi4I+uGXT+4zdkDHx5nXH0vbfity+/HC+//Fq8c3TopaZOvfbwgL1HhjpmzutsvC1eyLkj59Shl2J7Y6nrkR0yeoxM0JgUC76WHRRaH26I5ttqY3FrddRdWBUN64vRuLUuWnJ+wz47LnQZHDKyjjczVm+vi2W3FKNx6/RYub0+NpRYcuryGwfuw3CmQ8akmL01ZzL7kZmZ12b1A9l3CLTunJJ7bTIDxC21sXrIOwGGDhmbHsqKGLNjwz11sXzrlFh8Q/e13tkQm3Kjw6xo+mTGnhcljrvua1Oj6aGhr/lwQ0bxUzMy3peu17X05g/32FhyW1003zc78z1c/dm8/TdKve+zYvXXKnjfhwh8AACcvYQMACBZX3jhSM4s+YHYlbuxdH3UZ/xW8NCT9qfi4Au35S4TVSiuicdeK3GPwqm34skr+n/P+A8ZHfFmW/bG2vWbH4pXSq479Xo8lvHb0xWFjFLLinUciF0lI0YhCoVJUXfV1GjOmRTtnazdceaCRvHauozlpGbHmi/XxPTcCdiupZaylqEaHBe6lAwZJfe+mBQzb6jLvjPhgWkxt9TrG2rviSFUbZ6e+RrX31762sz8dPZyRLkT5xnn2Zr1eh+ZFau3TY3G686Nhgurou7Cqv6bS2c8z8D3dd22KTFrds5np8ReFlc/2hAXX5bzmss9/0dnx9qd02LJDTUxp/v8+28sXm7IqBp8N8ajDfHxjfmxpWp2dVywtS7W9cSa+/MDQ9WqqbEu632/o9S+Ifmf07Wfr849LwAAzl5CBgCQrHI26D7t5+qdF89eHqqf4hfihbxbRCKi85fb+23+Pb5DRmf87oHSG3cXGh+L13Nbxql45d5K3oeBr7MxduWtJ9VxIB5YNsSmxf1MirqraqPpOyMcNGpq4tKM35pfu3WIpYS61X4yI4I8ND0WZEwQ54aMh2bERz829GuoXj0tY3J5dly6ucT3nVbIODeWPXCGr83DdfGROeWdZ1ZYqhvGXhvlTvT3v9ZTY23GhHzrjin9/v+i/PMfKgL0KDdkDH7c5r+tKW8D7+nnxOJtM+KStXmfuey7etZ+6dyyNvDOfN8fnREfzXrfAQA4qwkZAECy8ie9346nrjhTzxURp16Px4b87f4uC3YdiM7c5+l/p8i4DhlvPxVXlHHM3LtmIuLdtsHLbZUXMopxfdvB7OWrTr4dP7q+kojR16SY3jIlVo5Q0MhanqfU8lCDTY5F2wefW/OnBk+YZ4eMWbHy2vIm1wuFSbHg9sHLJG38yrn533MaISPr2mzeXtm1ueCOwefbckvGXRklQ8CsaNpSxobbpZ7n0YZYuqqyz0fmhPyembFsdQXH7T7/IffY6DX8kNGzufjpqrpqemweGHDurY0ZFfzMnveVwZ/1DV8u8TkFAOCsJGQAAMkqNUk+9P4I/ZWatB94J0VpX4j80zoVB3Z9OFE4nkPGW09eWt4xt72UG3aGGzIa8zZfP3Uw2oYdMfrqDhq7stf6H17QOCeW3Jfxm+OVbk58cW20DDyXnYN/cz8zZNxXyQRxIQprp8XGMo7Va9ghY3J8dOfA69sQSy4+A9cm6zWXCAH5+ziU93qv3jMn1n2p3JDQ/zO38G8HR6rMcFTi/Cs79vBDRqmloso3OT66o8x4U8qcKdE88I6WoZZBAwDgrCNkAADpKrHZd0REdLwWj2+uL+u58ifQO+OlbZWd17aXcu/JiCMvfKH3ceM3ZByJF75Q5jGvaYu8M+98aVsFx+x6ncXr2yJzW4xTB+OF24ZY6qpik6LYNCWWfyt7c+6KgkZjbawe+Jvn3ygOY8I7I4jsqYtFAyaVs0LG2s9XMElfKEShUIyVAyeI758as/IeP9yQMWdKXF5JMMmVFUQylhnKCQGV3QmQ8zyns6xRVoj5ztSYXc5xuyfvz6soLpQbMrKXf2rdPSMamyYP4zPcraYYTQM/X5XGtkIhCoVJ8ZFvDDy/+riogpANAMD4J2QAAAkrsU9C7wT3kXj1sTVDTormT6Bnb0pdyqVPvpV/Pr97oPdcxm/IqOCYJUJGpfHkt/+8P94+mfGlU0filV1nOmL0V31peUFj4ZKc58iYfM7bqHsos780MFLMjEtW9X9MVsioZOPtLhkT2CMRMjYPXl5o9WerhnVtGj7fMOh9GbSvR2YImB0rrqpwubCsTbeHFadKXO8KQkzWEmOllRsyCjHjloHXtc9rfqA+Vm4txpz5FV6/jDt+hrtkVfHGGWfg8w4AwHgmZAAAaVuwLfYfyt1RumemOw698kCsKeY/T+4EeudLsa3Scyq1JlOfjciFjEo3GM8eb/3fy0bt81Z9aTGW7cgPGnmTp4PDwuxYt6MuVm4bhnsG7wUx8LiDjzczll5W6esdnZAx/bP1g75vwz1n7toMCkZZIeDBaXFepZ+HMxinelxwx8DPVMb7dsbuBCk/ZBRqqmPprryI1ydqPNQQzbfVxsIy7tSo2jL4dZzJ9/1M7eMBAMD4IGQAAOlrvC32Zf6qfv9x6tBLcfey7Im63An0PuGhbELGh85YyDgVp/J6VceB2DXKy8hUX1QTF981dFDoMfguijNr4B0M4ylkZG9MfuYMmtDOOM/Nt9dU/jk4jc3NK7kWg54zK2TcWxvTKz5eBSGjUIjC9HNjyd2DP/O5UeOB+lh+wzlRncr7DgDAWU3IAADGh+KyuPulQzHUvRnR8WY8mbEhtJCResh4N37yQM7+GBHR+bsHonGUPmtVi8+Nxm0NsXng+v4lJrIHr+E/spO2QkZlIaPy/UOG/3orvRblhIzMTcGHVGHIKBSiUJgUM2+oi7UPl3/9W++bFgsWD152SsgAAOBMEjIAgHGkGMvu3h/vDXVzxsm340cDYsaohYyDP4qN3Y8TMio9ZjGubzuYE6tOxcG264exQXT5ugLGzBL7ZFSytNSZ5Y6M0wsZwwoQoxIyytvjY3iT9sMJGT0mRd36KbF0W31sKCdqPFQXHxmw19Dg/UyEDAAAhk/IAADGneKyu2P/UDXjzy/EF/rsmXEm98gotdn3qVfu7X2ckDGcYzbGY6/nrjEVB0Zg0++qxTWx5BulA0brd+piyVX5y+hkbUJ92Q1VUXfhmVE7vf/xxlPIyNorYdXNI3dtRjJkDOvOjj4G37lT3h4Zox8y+poUxUvOjcVb62L1d2fn/py03lsbM4Z4Hc2fOeeMve/TZle4+TgAAOOakAEAjE/FZfHAK0dKLDV1Kt584tLex+dPoL8ejy2o7NjbXurMPepbT354zFEPGQsei9fzDzjo8WmGjEIUGnfFgY6ch506GG0ZS4cNR/VFpx8wem2eHptH8TfGx1PIKKydFhsHfN/wlkoq0wiGjKt3TjmNu4LOjY8/OOD5Hq2LC8o47tiGjP6qL6qJpXfPyvi5mRnLVvd57MenxtoBjxnWXiUAAFAQMgCAca0xduXOePefSM+fQO+MX26vZHLvmsjvE/0DwJkJGafilXvLPLfrfxLvl3Ethr4mYxwyCoVo3HUgct/Z09z8u+yAsakqqsp93ppiNA3cU+OBaTF3hD774ypkFGri0oHLE43gtRnRkLGnIZZcPLzzqrpqcOzK3MQ78ZDRZVLM3tow6Geo/xJoGeHm4emxsGaE3ncAAM5qQgYAML41Ph5v5M6Nf7j/RaltLTp/ub3837L+9L74cxnHKxQqCxkbf3Qw97F97/Io5Yqn3s5/keMsZBQKxdj2Un6kOnWwLa4vlnmO3aovLcayHVm/SX4aAaPX5PjojoHPNzuatkwe3ud6+qSSd4GMr5AxKRb+7exB33v5jSNzbUY2ZMyJzduLUVvxeZ8TF907+LkG7n2Sd9z0QkahK94NcZ5zvzx4f5TVnx3m8lzTJ0dRBAEAmLCEDABgnCuxL0SZISNOvRVPXlHOsRbErgN5y0qditcf679/QyUho+QG4m8/FVcMdW7FbVFi3n8choxCFIrXx09yn7z8zb/LDRiNLcMJGB+q2jw9Ng187oxNkId8nsXFaHpoTmy8oxjTcyZukwkZW8rcp2D1tNgw8No82hBLV1W4z8GCmrj0u3Ni044pUZ83qT3CIePqPXNi7ZfOHXq5sV7Zdy9c/XBdfGROeccd6ZBR+8m6aLmjmH9Ns5QRMgoX10bLGXnfz42P75oTm+6ujdliBgDAhCRkAADJKl7/ZOx/6uaoL/W4EvtC9N14u2TIiPJ+w7/kckcDNhcvFCoMGaWWhRpqk+visnig1BJbXQcc9H3Jh4xCIYrXt8XB3I1Qhtr8uzouzFzL/8wGjA9Njo/uzDjOQzPiox8rZ+J2UkzfNDWueOjD782buB2TkHFt3aBrufkbxTLvZpocF9wx6zSuTSGqV9f2uzat902NuQM3+i4URiVkXL1nTqy/vSY3NPV93fO/nBExSsWJ0Q4ZC4rR1L30V+vu+lha5h1JtVvqBi2VtfLawZ/pBbdnve/1sWR1me/7pVNi1e4+7/uuaTG/wjgIAMD4J2QAAIm6Ip58q2sGu+PNtvj6sqzfJK6Pm5/N31vitYcX9D52qJDRdZyn4ub67PNpvO2FkhPqr9y7YND3VBQyCp+OfblrVnUd4822O6NlXrHf61/1xcfjV++dHPrFjdOQUSgU4oon38rf1L3k5t8ZE7k9E/C7zmTA6KPPpHD/30KfFVdsrYn62VmTt5Oi2FSMZTnRZeNXB2+MPSYho7E2Vg86v9mx5sv9X1f1/OpYeEtdrL13wHMt6LrTJPPafLkYs0pcm6U5e5q0fqMYNQO/Z5RCRtfEf0Msv6E6agcGlZrJUX9VbTR9Z/CSWl2T8VPz7ywY1ZCRveRV63fqYukN50ZdVigqTIqZN9TF+oF7wjw6Iz6adYfJnGKsHM77fkn+XjatO6bE1DP9swsAQNKEDAAgSY2Pvd5/8vpUZxx8bV88tXt37N69O3Y/3hYv/79H8ie4B9whkTuB3tkRHX2f5OTheOvltni85zi7n4r9bx2O/FSQv8RRZSFjiD0u+h6x82gcPto5+LWfOpV/PcZxyCgUGuOB3+Ut6RUlNv8ePJE7YgGjj9qrpg+e5O17DrtnxZqddbFyW12s/s6s2PRIiYnynAnvMQkZhXNiyX2lJ/aHeq6qVVNjbQXX5sqsKDTUb+aPYMhYtyv77oqec9/44KzYuHt2ybuAhlxubDRDxvppsaHE+9H7uu6bESu31UXzffmf1w1fOTf356qS9735viHe9+9Oj4XuyAAAmHCEDAAgPbO+Gb8aYqWkkiPjt/RzJ9DfbYvbSi0ZVfpAceil7dGY8zoqDRlD7nNRapx8O9pufih/v5BxHTIKUWjcFaVWz8peGuzDidzRCBh91W6cVnLithyl9gMYm5CRsw9IBSGjUChE9eqpsaZEvCn32mQuK1UojGjIaPrk5Jj/lfyYMZTW3XWxaPEQSyqN8tJS1atr44rdw3s9va+r1B0mPZ+dVf2XBhvWce6zrBQAwEQlZAAASUNSaMIAACAASURBVKrf/FB5SyYNHB1vxlM31w96vlIh45pCIRq3vxSHcm9nyJo5PxKvPram5P4AFYeMQte+IG9WGDNOHXk1HltTjJIbn4/3kFEoxIJ7X8kOTqc64+CBtvj2VbMGfE8xLt1VF4ubJo9awOiranFNLM9ZWqikR2fFFbeU3kx6rEJGoTApZn++zIn8Es9Vtbgmlg6xf0nutdl6btSWOscRDRld16B+S12sqyjGzI5126bEzLz4MsRxR3qz70JNVSy4pdLX1GVjJRtwLzj3NN73cvYkAQDgbCVkAAAJq4/ND+2Ptw6XETROHo7X9t0Xm3P2uBgqZBQKhSgu+3q0/aHEclU9k+a/ejw+l7lnR3/DCRmFQiEK9TfH9w68V2I5qz6vue3rsaz3ToSzO2QUCsW4/ic9RzsZh9/aH0/d+YmYN8Qm7WNrUtRdVRtNu4ZYbmjPnGh9eGas/lp5k91jFzK6XtP0Tfn7P1y9Z05s/u6MWHbtOUMEpEkxvWVKLL+njIntR2bF6q9NydlPYYARDxndpp8Ti79WHxtKTf4/OjvWfmNqXHBpeRtb5x13xENGj5rJMesTU2PlPTNj81BLTu2qiyVlbgx+uu/73KHuYgEA4KwnZAAA40Ax5l3yqbhz9+PRtv/lePnlHvuj7fHdceenFkf9EM9RTsjoUb/qi3Hv422x/+UPj7W/7fG494stozppXpzXEl+8d+BrHptzSUZxTXzt3i/GqpxglbKq2VUxp7UYi2+ZFiu3de0HsHzrlFh8Q03MWTQ2d42crur53a/phm6t1TGtnNgw0PTJ0bC+GItvnhrLu6/Nyttqx/balB1EJkXt8nPjghuK0bh1eqz8+tRovKEYCy+viuK4voNgUtReeE7Mu67P+3tDMS5Yf87w3uNK3/cLJ5e8KwkAgIlFyAAAJoRKQgbAGbuzAwAAOG1CBgAwIQgZQEWEDAAASIaQAQBMCEIGUBEhAwAAkiFkAAATgpABVETIAACAZAgZAMCEIGQAFREyAAAgGUIGADAhCBlARYQMAABIhpABAEwIQgZQkZbaWLmtrp8LWxI4LwAAmICEDABgQhAyAAAAYHwSMgCACUHIAAAAgPFJyAAAJgQhAwAAAMYnIQMAmBCEDAAAABifhAwAYEL45v7Dcfhwhjf+MTYmcH4AAABANiEDAAAAAABIlpABAAAAAAAkS8gAAAAAAACSJWQAAAAAAADJEjIAAAAAAIBkCRkAAAAAAECyhAwAAAAAACBZQgYAAAAAAJAsIQMAAAAAAEiWkAEAAAAAACRLyAAAAAAAAJIlZAAAAAAAAMkSMgAAAAAAgGQJGQAAAAAAQLKEDAAAAAAAIFlCBgAAAAAAkCwhAwAAAAAASJaQAQAAAAAAJEvIAAAAAAAAkiVkAAAAAAAAyRIyAAAAAACAZAkZAAAAAABAsoQMAAAAAAAgWUIGAAAAAACQLCEDAEjO0qVLo62tLZ577rnYu3cvANBt37598YMf/CCWLFky5v9eAwCMFiEDAEjK0qVL47nnnovXXnst3n///Thy5Ahw5EgcPnw49u7dG4cPHx7zc4HU9Px8/Pd///dZr6OjI95444147rnn4sorrxzzf7cBAEaDkAEAJKWtrS1ef/316OjoiL/85S9x8uRJ4OTJ6OzsjL1790ZnZ+eYnwukpufn48SJE2e9nn8b/+M//iP2798/5v9uAwCMBiEDAEjKs88+G0eOHIn/+q//ir/+9a9hGEbXOHnyZOzduzdOnjw51qdiGMmNnp+Pzs7OCaO9vT2ef/75Mf93GwBgNAgZAEBS9u7dG3/5y19EDMMYMIQMw8gfEzFknDhxIvbu3Tvm/24DAIwGIQMASIqJWsPIHkKGYeSPiRgyOjs7hQwAYMIQMgCApJioNYzsIWQYRv4QMgAAzm5CBgCQFBO1hpE9hAzDyB89Px/Hjx+fUIQMAGCiEDIAgKSYqDWM7CFkGEb+EDIAAM5uQgYAkBQTtYaRPYQMw8gfQgYAwNlNyAAAkmKi1jCyh5BhGPmj5+ejo6NjQhEyAICJQsgAAJJiotYwsoeQYRj5Q8gAADi7CRkAQFJM1BpG9hAyDCN/CBkAAGc3IQMASIqJWsPIHkKGYeQPIQMA4OwmZAAASTFRaxjZQ8gwjPzR8/PR3t4+oQgZAMBEIWQAAEkxUWsY2UPIMIz8IWQAAJzdhAwAICnDmqj99YOxZcuD8euRmR/LHifej9+/8Hjcdct18c0fjeaBjYk6hAzDyB/DDhmHfhtP3ro6Fs1viIaGhpi/aHXc8ve/jEPt7dGxf0dcdtmO2N/RcdrBoaOjI753U0Pc9L3Tfy4hAwCYiIQMACAp42ai9unbo7m5OZqbm+P2p8f6ZIyJMIQMw8gfww0Zv/72mpjbvD3+5e0jceLEiXj/t4/ElgsuiTv2HY+Ojo44frzrf89EyDhTzyVkAAATkZABACSl5ETtO8/EXTeuj5bm5mhZf2Pc9cw7Xf+9946Mn8a3rro27n+x5xveiD2f2xDbnzkRceJ38b+/cWOsb2mO5pb1ceNdz8Q7vU97V9y4viWam1ti/Y13Rc/TPn17c3z1738cd12/Npqb18Y1t+6JX57of0pP3y5kGKMzhAzDyB89Px/Hjh2ryPduaojNu/8jOjs7e2NDT3DouSPj5+3tcezY+/HC/dfG0vkN0TB/adx499djfffXfr7jsrj0jsfi/qsujLkNc2Phqlvjf73e3u847e3t8b2bGuLG77VHe/vPY8dll8Ydj90fV104NxrmLoxVt/6veK3Ccz927JiQAQBMGEIGAJCUUhO1P9mxIa69Z18ci4hj/3p/bGm5PZ4+Ef2Wlvrpt66KLQ92LzL1/hPxpQ3b45kTEW/s+Vy0fO7v4t+ORcSxfXHPtS1xx48iIn4SOzZcG/fsOxYRx+Jf798SLbc/HSeiK1K03Pjd+Nn7J3q/5/an+5cMIcMYrVFeyPjP+P5nmrvvFvpMfP8/z7avGUb2GG7I+MOj18X8RZtj5z/9Ot461N4bHdp7l5ba2bW01Mv3xZq5zbH9ufei8/Dv48dfaYqGpq6v7d9xWTQsuin2HOj62u5r58ZlO1+M9vYPY0ZHR0f8Q/fSUh0d+2NnU0MsumlPHHivMw7/fndcO/ey2PHzdiEDACCHkAEAJGXIkLH9h/H6sQFf6LtHxk+/FVd1//n9J74UG7Y/EycGP1U8fXtzd/DoChnbf/h6DHzaDx+T/fee/yZkGKMxygkZP7+nuXfJsy73xM/Poq8ZRt4Ybsjo6Pggfv/jXXFjy6KYP3dhfGzDrfH3vzjU9bX9O6Kp6a7Y39ERv7i7ORq2PB6HOzvj+PHj0fnizmhquitePH48Xtx5WTTc/ER0dn/txZ1N0XDTE9HR0dEvZDxxc0Pc9A/H4/jxF+Oupoa46Ynu5+p8MXY2dUUOIQMAIJuQAQAkpeRE7bF/i3+865a4bv3aWH/drfHgv7zZFSn6bfb9Ytx/7afjkX8/EU/ffmXXslIREe/siwdvva5raanuCdKeKHHs3/4x7rrluli/dn1cd+uD8S9vdn2PkGGkNIYOGT+Pe5oHRoCeOxrOhq8ZRv4YbsjoiQzHjx+PzsNvx/7dn4hFcz8Rj7zVHscHxIqmnS/2xomBX2u4+Yk4fvx4tLe39/59yJDxD12P7/27kAEAkEvIAACSUt4eACfi/Z/dH1uaPxd73ogBISPixfuvjc89siduv7JrWamIriWnNnz1+713c2RFiTjxfvzs/i3R/Lk98UbGY4QMYyzH0CGj75JMA+9mOBu+Zhj5o+fn4+jRo8PSs6RUR8f+2HlZ9xJQ+3dEU5/lo+Z+9slob2+Po0ePRvvP+3+t4aYner828O9Hjx6N9vb2eGLA0lI3fq/r6wP/XgkhAwCYKIQMACAp+RO1v44Ht2yIr36/awmoY68/Gl/ICRnx4v1x7YYNcW2fZaV+smNDXHXXv8SxOBHvv/x4fPnK7ijx6wdjy4avxvdf79oj4/VHvyBkGEmOsvbI+M/vx2f6RIB7fn6Wfc0wcsbwQsYP4tZF58c13/lp/PH9Y3H06Hvxx3/+P6N57pr49ivHu++66IoVHc9ui0vOvz4e/s27cfS9A/HDr1zWf48MIQMAYEQJGQBAUkpN1J745Z649br10dLcHC3rr4tb9/wyY2mpiK7lpTZ8uKxUz/deszaam9fGNbfuiUe2b+iOEifil3tujevWt0Rzc0usv+7W2PNLS0sZ6Y3yNvs2jIk5hntHxqFf/H3cuuFjsXBuQzQ0NMT8pRti2z++Gn8+3j9ktLcfip/9z6vjwrkN0TB3YTRfvSEu6t4/Q8gAABh5QgYAkBQTtYaRPYQMw8gfww0Z/fbI6Ozs3bC7vb29e/+Krj/3PK7nMSd+sDUu6A4ZfR/XEy36/n3gfyvn8UIGAEB/QgYAkBQTtYaRPYQMw8gfPT8fR44cqVhP0Ohx9OjR3v/e48iRP8XzT//veOXgsWg/9Nv4v25aFIu+/P8Mig+Dv+/IoP9WzuPLJWQAABOFkAEAJMVErWFkDyHDMPLH6YSM8mLHv8UTX1gdi+Y3REPD/Fh63bdj35864tixYyN2TCEDAOBDQgYAkBQTtYaRPYQMw8gfIx8yupaA6lmGqqOjo9/dG0IGAMDIEjIAgKSYqDWM7CFkGEb+6Pn5OHz48IgYGDPa29vjyJEjI3a8cgkZAMBEIWQAAEkxUWsY2UPIMIz8MdIhI1VCBgAwUQgZAEBSTNQaRvYQMgwjfwgZAABnNyEDAEiKiVrDyB5ChmHkDyEDAODsJmQAAEkxUWsY2UPIMIz80fPz8ec//3lCETIAgIlCyAAAkmKi1jCyh5BhGPlDyAAAOLsJGQBAUkzUGkb2EDIMI38IGQAAZzchAwBIyrPPPhvt7e1jPSdmGMkNIcMw8sdEDBl/+tOf4vnnnx/zf7cBAEaDkAEAJOWZZ56JN954I/7617+O9byYYSQ1hAzDyB89Px8ffPDBhPHqq6/Gz372szH/dxsAYDQIGQBAUpYvXx779u2LN954Izo7O8d6bswwkhlChmHkj4kUMt5999149dVXY9++fXHNNdeM+b/bAACjQcgAAJKzfPnyeOaZZ+K5556LvXv3AgDd9u3bFz/84Q9j5cqVY/7vNQDAaBEyAAAAAACAZAkZAAAAAABAsoQMAAAAAAAgWUIGAAAAAACQLCEDAAAAAABIlpABAAAAAAAkS8gAAAAAAACSJWQAAAAAAADJEjIAAAAAAIBkCRkAAAAAAECyhAwAAAAAACBZQgYAAAAAAJAsIQMAAAAAAEiWkAEAAAAAACRLyAAAAAAAAJIlZAAAAAAAAMkSMgAAAAAAgGQJGQAAAAAAQLKEDAAAAAAAIFlCBgAAAAAAkCwhAwAAAAAASJaQAQBMEFVx0dSpcVHVWJ8HAAAAUAkhAwBIy/kr4vCK80fguWfGsy0t8ezMgX8e6Pz4TWve1zh7zYxnW1rjN+eP9XkAAAAwkJABAKRlVEJGKULGxCRkAAAApErIAADS0jdknL8iDq9sjL9btiYOtbbGoXVN8eNZVVEozI2fr18XP53d833T4seXb4xfLaiKQtWM+IflLfH+ptY4vOnK+OOyBbGqUIhSd2TMmNUYv1+/KQ63boq3li2Pf88KGQMDy/kr4nDLkthaKEShalb8uGldHGptjcOb1sWrjbNiRvfj5s2+MF5d1/Xc719+Sdxb23P89fHyJcvjnU1dk+d7VrTGgcaF8a9ruh77TlNjfKV7GaxV5y3pfo6+16D7HC5bGm3dxz60bnnsaTgvfnr5lfFB66Y4uOrD5yhUz+593AdXXh4/Pa824/rXxr1LmuKdnmu3/IK4oSr7fPt+354VrfHvy5b0XsN3ViyKa7u/NmPGBfFyy5XxQWtrfHBlS/zrgp7jVsVXGruPNfD1LlgWf7yy+5q1LIvdtYUo1CyK329aEXu6H7N1SUt8sOL87us8K55fsyaen1UY8P6vi1eXnNfn/R/wGmoX9F7vg6s+HgfWCBkAAAApEjIAgLQMDBmbVsfzc2piRqE67l22rnfy+puXrI8/LpnZ9biaRfH7jctjd1UhNjVeHh9cfmH8H9WFKFSfFy+u2xS/XliI/JAxO366blP84cKGmFeoivUXrIh3KwwZmxovjw+aFsf6qkLMmPqROLCx+/trzo/fbNwQv7lgasyomhoPL18X7y47L3p++//tZefFvO7n27OiNT5YfXF8s6aq97x/c35VFArz4xcb18WvFk6NGYWqWL+4KT5YfVF8pvf6XB7/3FAdhaqp8U9Nm+LQlau6/l49O15o2RS/W1QThUJN7FmxMd5dcUGsr6qK9QuXx9sblsW3B1z7pYsuiw/WLY+Hp1ZFobohfti0Md6+ZHbm+fbVc+7bqgsxY+rC+NW6nuNOix9f3nNtCzHvvGXx9qZL4+8KhShMa4w/bGqKf5paFYWqqfH9lRu738+u1/viedVRKFTHtqU9waIrVv1ifiEKhbpou2JjvLfu4/E/e55rY9eft12yrvf9nzF1XrzYew0GvoaaePKyTfH28oWxvqoQ82ZfHG9mRBoAAADGnpABAKRlYMjoueth4N/nXhL/X/efly5qiveWL+i9C6KvPStauyfIc0JG/UXxZp/f9M9dWmqokHH5hfHlmqrB33PFhfHJnr/Pujj+s2VJbM1YxujD88z+e6+ZS+KPrStiT8b12bqkJQ6vvKD3Onzl4jXdz3F+/Kb1imir63meWfH8msGvcc+K1vhD47T/v727+W1svQ87/r8ccGSONJrRu6hXSqI0JEciRfHlZqa+946FWXiXVZYBCq+68qqLAEVgoJtsigDJqgiCojCQGkEdICkcI/biFr4tbBex78X9D35dkJIoktKM5tq9P08/iw8wI1LkOYdHm+fL53luflZ5Eb/+N4343luWXZo81svjj+5YHmzs2j49js8uP4r/svZ44nMbhZv9Z1PR5Pp8nh7HZy/r8cOLT+LvK0Us73fii85+LBdr8cNXV7FjqHnYG12TyXPYi/9xOX4NLC0FAACQlZABAOTyriGj2IgfffxH8bdLj+IvOp8Ol5UqiiiebMUPe98eLi30ZujekLFWj8/H3+M9QkbxaDH+7OQifvH6Mr54/TL+6WA4A+FP66+uj+Hag0PGo/jjajt+8fpy7HXuCRljx/in9VfD11irx+eTxzF1jjMG8q+jycNCxvhx9bfq8bNvD5eWuv2+j+KT7ZP455ev44vL1/GL9sFwFk1RxPbqQfx48O347eV34pe9evzZ4uiz3WnFb3qH8d3DXvz6RSUujz+Kz+tr8f0Xn8TPDx/P/uyuj2XyHPbjJ1fX8a7zBwAAIAUhAwDI5Z1DxnAZoc9OjuMnnw6XlSqK4ZJTv7k4jO+OBsXfOiNjrR6fj5YlGh7DPSHjo+O4vONYrmw/O4yfvh7OCliuXsRXvcNoTp3nA0LG48P4+ZtX8d82RzMX3jYjY1bIeFSNn77pxV8/vv/a/65mZDQPe6PzrsTff/I6fnp4Nbvijmv7rWfxVxev4zetnds/f/Q4vt98dXPdH+3HTy7P45/OPx3Ounh6HJ999CJ+9NHL+K8rV9f1XWdk7MdP3nwUf/P07s8EAACAHIQMACCXB4SMYuNF/PL16/jV2LJS/6H1On59th3bxaN4vnYU//LpW0JGsRE/+vh1/PRgtAfFXXtkrNXj89cX8ZeLj6L41rP4y86no2N5FH/RuYzPm5vx/FERy4934h8+GQ2mPz6Mf7l8Ff99ezGWiyK2n+3Ef6zc7NfwTiHj6XF89qYf/3n0vn/+4mV8+dCQMdoP4vOz7fjkUTF8nb3KVGBpHnbjy1dnwxkQM/bIuC9k3OxLshF/9/Iy/ufJUgyXifok/mH7W1E8ehz/9qh7fW2X9zvx5avmcE+QR4/jz88+GYaM0XX+q2fDPTK+e9IfC0iP4697l/Hl9VJga/HDV5fx5ccv4vujY/l3Lz6O3/SO79wj4+YcRtekuTHcv8MeGQAAAGkJGQBALg8JGaMIcb2sVFHE8vpx/Ozjy/jqzWX8qnccf9t+/ZaQUUSz0ojPvjP8nf91dnqzWfetY3sSPzh7Fb+9fBNffuej+Lujs9F+F0UUT3bjxy9fxxdv3sRXl6/jF2e70R/9Xn+rPjqeN/HF65fx490n8aCQcet9X8WPjxrx2YNDRjFacuvjmcc4fo7/vt6LX12+ia8uvxOft6vxx9fB4P6Q8b8vWvHzT26u+/ceFVEUj+J7x1ev93H87Pgk/vH62j6JH5y9jH+9fBNfvbmMf315Fj94cvM7vxx9Hr/9di/+Zv3m8/2T5y+vN3wvitEMnPGZHI+W4z+1h9frq8uP42f1rdF5zjiHpcP459G98n/6L+If/+jq8dv3BwAAAN8sIQMAgK/lzo3JAQAA4HdAyAAA4GsRMgAAAPh9EjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAuNi+eAAAEEBJREFUAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAAAAAIC0hAwAAAAAACAtIQMAAAAAAEhLyAAAAAAAANISMgAAAAAAgLSEDAAAAAAAIC0hAwAAAAAASEvIAAAAAAAA0hIyAAAAAACAtIQMAAAAAAAgLSEDAAAAAABIS8gAAAAAAADSEjIAAP6/UIrywkKUS9/0cXwD5h7Hk8dz3/xxJDX3+Ek8nvvmjwMAAOAuQgYAkM/cSuzWz6LbG8Rg0I/eeTOq6wtRmvXc0nLsNc+j1x/EYNCLTnMvlq8H6+dj7fB0+Fi/F63aRsxf/d78Whye9qI/GES/14raxvzNa1bqMRgMxrSjujT53qVY3mvGea8fg8Egep1m7C2Xrh97ulOPTm/WMZWivLgau7XTOD/evP2aS9Vo33rfQdQr0+c8t7IfzfPhsQ/6vThvVmNt/m3XdSmq7Vnn8QCVegza1Vi693mVqA/qUfl93BelhdisXd0Xg+h1z+Jk6+ns+2LyuOuVr/HelajPvAem74mnWyfR6vWH921zJ57MeM7d9824+VirNkf3UD96rVpszPqM3+kzmVap39xb4/+evmdmPfaWc5hfi2qzE73BIAa9ThytT5/bVqN767jn16rR7PRiMPH3uFRtT/wtTvw9vvW9AACAD4GQAQDkUt6Mk04nGnursThXRFGUorxUidpZJxrbi1PPX6q2o9vYGT63tBDbjW50DleiKIoobZxEt3MSmwulKOZW4qDVi8Z2OYqiFBsn3eicbMZCqYi5lYNo9RqxXR57zeP1+49zqRrtbiN2FueiKEqxsN2IbucwVooiisX9OOufxv6zuShKC7FVvzmm4aD4aEB2cnC9Uo/B6d6Mwe8xpY046Xajvr0Yc0URRakcq4ft6De2o3zvtf3DDxmL+2fRbx3Eank4aD63uBONbicOV97huP8fhIzy5vPoduuxvTgXRTEXj2fNArnvvhm3fnxz7xZzsXLYjn69Mh1t3jNkjHtwyLj3HJai2upF62A1yqUiSuXHU7OASuvHcdHvjx33ehx3O3GyOYyVcyuH0e7XozJj9lBp9SjOW9VRGHz7ewEAAB8GIQMASGXlsBWNrfkorx7Eaa8/nElxtB7l0nIctG5iw53GBq1XjzrRri5dP1beaY4eW42jzvjAdDl2mjcDtqtHnWhVnz3w2G8G8G/eZ/TY6lF0JgebZwyul3ea0X++ef/7LFWjfVGLtZmPL0W13YmTg1q0e8PZGqcHq6PAMR4yJmPD2ED9UjXa7cPY3mvGRX9itsr4oHlpPY673ahX5u+8DsN/N2J3c3Q8vU4095avB+PnN2o3sxfO75qZcKNSH8SL3cn3G7ueL2pRbV5EfzCIXqce24vT13qp2r51TyxV26PHhtfncHsvmhf9iRk84yGjFOvH3ejWKzeze8buoeZO+b3vm7fe17OCRaUeg3Yjjq/P+yQq8zfXazxCVOqD63O/c0bG/EbU2r0YDPpx0TyOxswZGfecw+pRdDpHsXrXc0vDv72Dg8Y9AeaOcFRajaPz1s3P3/ZeAADAB0PIAAASWYpq8yhWiyexd9qOw5W5KEprUes0Y6c8HOi/f1C1FGu1zvXsh/GB26IoxgaDpwdKJwd522ejJakmBt/vUlqrRWf0rfSbwfHR40vVaE8OVs8IGUvVdnRap8PlhCaXwrpSWo3D816cP9+O5alv/A+/Qd+tbw1nmjzbj9P+1YyFB4SMwdWMj1Is7DajfzXgfH39SrF61IluY2v6+KZCRv/6G/Nza7XoXH3Tvrwdjf7oM776Vv9bZqPMbzei130R1Y3F6W/eV+ox6LfiYGU4C2bzpHMzS+WdQ8YguvXtWJwrorSwG83++PUa/ru0ehSdbiO2ppZ5Wopq+zyeH14tLdWL9qzP75775u7nDWdkdGszZgmNn/fVzI3ReT88ZJRju9G/PVOp//aQcescKvUYnNbiYLTcU//idqBaqrbi/Gg1SvfMJJlbOYx2txbrEz9f3Dsd/u74ud/zXgAAwIdDyAAAEqlEvV2NpWIpqu0Z31Kv1G+HiQnzlXp0u8exPhrkfr+QMRfrR61o7F4tc3MQrf5Z7C/ec9zzlah3u3G8PhxEfd+Q8WynGadHazFXFFFa2Ip6txsnGzMGZueexXbtNM57/eh1z6K+vzYaMJ9eCmj9uDs6r4eEjLHHxv9/df2WqtGaOZg/+dqT13ksCGw1YtDcectyWJNKsbC+H/WzbvT6vTg/rcXW09LEZzt67pO9OB0/7ncMGTfXbvz/V8e9FNVWNxpbs2aFLEW13Y/W0XoslIoolVfjsN0fLWX2bvfNLJX6aBmy81qsz5qNdM95PzxkbMbz/vjnddceGfecQ6Ueg24jdp8Nw8rizviSa3txejH6+5wVMq73pjmP2vrkdVuJw87E3+F97wUAAHxQhAwAIJH3n5FRWq5Gq9eK6tg3st93RsZtpdhqDJcMuh5UHt+Eu7Q8XKe/ejNr431DxqTlg3Z0jlbvfc7c4kYctfqjWSjTA8+TSyd97ZAxOv+L2vods1TeLWRMXaOHKpVjabcR3f5oubGpgfGx9/6dhIzRZ39Ruw5lU/fuxB4k957jjPvmbnOxuNuM3ovd6RkrM8+7FdVn7xMyJu+Lt4SMWecwdV9ffQ7zsdU4j+eb5TuOe/ye3o1m70XsPhn7+frx9IydO9/rPe8pAAAgLSEDAEjlvfbImK9E/eJ2xCiK0R4ZB8vX/5/cI+Ng+eq5t/fIuO0mZEw/Nh+V+sXUYHR5pxmDxtbNz95xj4xJ7xIyrl/reibL7fNYPeqMXmMyZJzG3vVA8QNnZCzuxWm/HQczl/H5fc7ImDR2vpMD4+WdaA6GAWwyZIxv5P6wGRmLsXfaj/bBrPjwJPZOB9HYKt167dl7nsy+b+41K4YVd513I7ZKw0Bxuvfk+rnvFjLG74v7QsYd57B+HN32QSzfuh9aUd2oRmtwEwJvzNofZPp9Z/4t3PVez77OPQUAAGQkZAAAuZQ346TTicbeaizOFVEUpSgvVaJ21onG9uL08+fX4qh1MWPT6SJKGyfR7ZzE5kIpirmVOGj14sXukyiKUmycdG/vBXD9DfBy7DT70dxdjLlicp+JcfOxdtSKi6lNn4soFvfjrH8a+8+G+zVs1bvT+xvMCBmrR53o1NajXCqitLAZJ53ppYme7L6IfrsWG4uj/THmFmO73o3uyUaURgPAV+d1e3mq8ZCxFNV2NxrbC1Eq5mJxux7dh4SMooj5rUZ0O0exOjU74d1Cxu09MkbLAt27R8Z61LrdaO4ujfbHKEV5dWzZr0o9BlfXvJiLlYNW9M/2Y3HiWpcq9ei3D2Nlbrj800Gr/4CQUUQxvxWNbieOVqcjzuLeafRaB7FaLkWpvB61GZ/fvffNmPJ2I/rtw1gtl27OZ9b1mdwjY+y8l6rt6Da2h/f44nbUu++2R0b7cGV479+5R8Y953C1Cfz2YsyNZpL0Zy33NB5gru6F1fLYcm7jQWUYE8cj0YPeCwAA+IMnZAAA+cytxG79LLq9QQwG/eidN6O6vjDz2+tL1faMb3kPRoPT87FWbc7ePHt+LapXmwT3WlHbuAkhpadbcdLqRX9wz2bfS9Vo3/kN81I83brZ9LnT3IvlWZtTT87IGDumOzf7LuZjbb8eZ93e8P36vWjVd2NlroirwfcXJ7VoT53z7aWP5jdqw+Pr9+L0YDdq7YeFjOE38rvRfb45MaviHUPG+DEM+tFrnVzvdzG5JNL451I7PR9uwj4YRK9zGoebo/uiUo9BuxHHzYvoDwbR64xt/Dx+rUvLsTe6xr1OPXb2Gw8LGcXVXizPY3NqdtB8bNRaw+O7de3Hrsl9981SNdpX17e0EJu1sb+BseszdR81DmN/1nnPb0St1Yv+oB+904PYrbXfEjKKKBa3o97pxWDQj4vmYZyczfgs7r33iygt70Wz0xt9RndswH3rXirFwmbt+p7u91pxsvV07G9uGN6O12fcE+/yXgAAwB88IQMA4IPxDpszf6ju2XMBAACAP2xCBgDAB0PIEDIAAAA+PEIGAAAAAACQlpABAAAAAACkJWQAAAAAAABpCRkAAAAAAEBaQgYAAAAAAJCWkAEAAAAAAKQlZAAAAAAAAGkJGQAAAAAAQFpCBgAAAAAAkNb/BdmDfCqy2RriAAAAAElFTkSuQmCC'
    from = from_to_hsh[:from]
    to   = from_to_hsh[:to]
    require 'net/smtp'

    html_text = <<EOF
<html>
<body>
Just to see!
<h1>How</h1>
<b>This comes out?</h1>
<img id="img_1" src="data:image/png;base64,#{@encoded_img}">
</body>
</html>
EOF
# <span class="embed"><a href="" onclick="img=document.getElementById('img_2'); img.style.display = (img.style.display == 'none' ? 'block' : 'none');return false">Splunk</a><br>&nbsp;
#   <img id="img_2" style="display: none;" src="data:image/png;base64,#{@encoded_img}">
# </span>

    message = <<EOM
From: Naren Siva Subramani/XTL/NWIE <#{from}>
To: #{to}
MIME-Version: 1.0
Content-type: text/html
Subject: Grh hmm

#{html_text}
EOM

    Net::SMTP.start("mail-gw.ent.nwie.net", 25) do |smtp|
      p message
      smtp.send_message message, from, to
    end
  end
end