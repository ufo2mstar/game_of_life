module Checker

  def check_link link_hash
    link_element, validation_hash = link_hash.keys.first.elementify, link_hash.values.first
    p "  - #{link_element.upcase} link", :bl
    windows =-> { @browser.windows.size }
    last    = windows.call
    old_url = @browser.url
    # element_validate link_element
    send(link_element).click rescue (@errored_fields_list << "#{link_element} not #{send(link_element).visible? ? 'present' : 'clickable'}!!"; return)
    wait_for_it 'link'
    @browser.windows.last.use do
      new_url = @browser.url
      (@errored_fields_list << "#{link_element} not opening a new page!!\nam still in #{old_url}"; return) if new_url == old_url
      @errored_fields_list         = []
      # proper_txt                   =-> text_content { (text_content[(/^\/(.*)\/$/), 1] ? $1 : Regexp.escape(text_content)) unless text_content }
      proper_txt                   =-> text_content { text_content }
      val_url, val_title, val_text = proper_txt[validation_hash['URL']], proper_txt[validation_hash['TITLE']], proper_txt[validation_hash['TEXT']]
      # URL
      if val_url
        @page_text = @browser.url
        text_validate({'Page_URL' => val_url}, true) #if val_url
      end
      if val_title
        # TITLES
        @page_text = @browser.title.squash
        text_validate({'Page_Title' => val_title}, true) #if val_title
      end
      if val_text
        # TEXTS
        p @page_text = @browser.text.squash
        text_validate({'Page_Text' => val_text}, true) #if val_text
      end
    end # last browser block
    windows[] == last ? @browser.back : @browser.windows.last.close
  end

  def capture_current_coverages
    tic 'cov_capture'
    if true
      $hsh['CoveragesPage']["lastdata"]['ALL_PERILS_COVERAGE_LIST'] = all_perils_coverage_list
    else
      # todo: lets not capture all possible values just yet.. seems too computationally intensive for not enough ROI
      cvgs_hsh_list = @exp_coverages || (init_exp_stuff; @exp_coverages)
      # raise BadInputDataError, "cvgs_hsh_list is empty!\ndoes #{@state_exp} contain \nCOVERAGES:\n  #{cvgs_hsh_list}?\n" if cvgs_hsh_list.empty?
      # cvgs_hsh_list = [cvgs_hsh_list['ALL_PERILS']]
      cvgs_hsh_list.each { |itm|
        begin
          raise BadInputDataError, "#{itm} is not a hsh!" if itm.class != Hash
          coverage, val_itms = itm.keys.first.downcase, itm.values.first
          next if coverage =~ /ALL_PERILS/i
          # p "  - #{coverage.upcase}", :bl
          raise BadInputDataError, "#{val_itms} is not a hsh!" if val_itms.class != Hash
          cvrg_val, cvrg_list = "#{coverage}_coverage_value", "#{coverage}_coverage_list"

          txt         = val_itms["TEXT"]
          select_list = val_itms["LIST"]
          element_itm = val_itms["ELEMENT"]

          coverage_name, coverage_value                     = if txt
            [coverage, send(cvrg_val)]
          elsif select_list
            [cvrg_list, send(cvrg_list.elementify).value]
          elsif element_itm
            [element_itm, send(element_itm.elementify).value]
          else
            [coverage, "#{coverage}: Not found!?"]
          end
          $hsh[@page_name]["lastdata"][coverage_name.keyize]=coverage_value
        rescue Exception => e
          p "Coverages Capture Error :\n#{e}", :r
          next
        end
      }
    end
    p "#{toc 'cov_capture'}s : Cov_Capture time" if verbose_mode
  end

  def check_coverages cvgs_hsh_list = [], also_check_help_items = false, just_capture = nil
    close_discount_modal
    raise BadInputDataError, "cvgs_hsh_list is empty!\ndoes #{@state_exp} contain \nCOVERAGES:\n  #{cvgs_hsh_list}?\n" if cvgs_hsh_list.empty?
    @cvrgs_errors                       = []
    @force_override_for_bulk_validation = true
    @bulk_validating                    = nil
    cvgs_hsh_list.each { |itm|
      # page_validation_control do
      @errored_fields_list = []
      begin
        raise BadInputDataError, "#{itm} is not a hsh!" if itm.class != Hash
        coverage, val_itms = itm.keys.first.downcase, itm.values.first
        p "  - #{coverage.upcase}", :bl
        raise BadInputDataError, "#{val_itms} is not a hsh!" if val_itms.class != Hash
        (p "coverage not found.. Moving along..",:y;next) if val_itms.empty?
        cvrg, cvrg_name, cvrg_val, cvrg_list = "#{coverage}", "#{coverage}_coverage_name", "#{coverage}_coverage_value", "#{coverage}_coverage_list"
        txt                                  = val_itms["TEXT"]
        select_list                          = val_itms["LIST"]
        label                                = val_itms["LABEL"]
        default_value                        = val_itms["DEFAULT"]
        help_itm                             = val_itms["HELP"]
        element_itm                          = val_itms["ELEMENT"]

        # todo: proc this sometime!
        # default_value = default_value.is_a?(Hash) ? default_value.values[0] : get_validation_data("TEXTS", default_value) if default_value
        default_value                        = {'TEXT' => default_value.values[0]} if default_value.is_a?(Hash) #and default_value["TEXT"]
        txt                                  = {'TEXT' => txt.values[0]} if txt.is_a?(Hash) #and txt["TEXT"]

        # Check for Coverage Label
        validate_specific_text(label||cvrg, cvrg_name, 'persence', 'silent') #rescue nil
        # Check for Coverage Static label value
        if txt
          validate_specific_text txt, cvrg_val
        end
        # Check for Coverage SelectList value
        if select_list
          cvrg_list, list_val = select_list.is_a?(Hash) ? [select_list.keys[0], select_list.values[0]] : [cvrg_list, select_list]
          validate_list cvrg_list, list_val, 'silent' #rescue nil
          if default_value
            # todo: do below when you want to send "DEFAULT: {TEXT: 20,000}" and directly validate the list
            # cvrg_list, default_value = default_value.is_a?(Hash) ? [default_value.keys[0], default_value.values[0]] : [cvrg_list, default_value]
            validate_list_default cvrg_list, default_value
          end
        end
        # Check for Coverage Element if not a list/static text
        if element_itm
          element_validate element_itm #rescue nil
          if default_value and !select_list
            #todo -> validate_textbox_default element_itm, default_value
          end
        end
        # Optionally check Help Texts
        validate_help_text help_itm if help_itm and also_check_help_items
      rescue Exception => e
        # todo: need to catch file read and text missing kinda errors!..
        p "Coverages Error :\n#{e}", :r #if verbose_mode
        # @errored_fields_list << "#{e}\n"
        @cvrgs_errors << "#{e}\n"
        next
      end
    }
    @force_override_for_bulk_validation = false
    @bulk_validating                    = true
  end

  def check_help_texts help_text_hsh_list, presence_check = true
    raise BadInputDataError, "help_text_hsh_list is empty" if help_text_hsh_list.empty?
    help_text_hsh_list.each { |txt_hsh|
      elem = elementify(txt_hsh.keys.first)
      div  = elem.gsub('_element', '_div_element')
      # element_validate elem
      unless send(div) .visible?
        begin
          (send(elem).focus; send(elem).click)
        rescue
          p "overriding #{elem} with #{elem2 = elem.gsub("_ele", "_link_ele")}", :y
          (send(elem2).focus; send(elem2).click) rescue raise "unable to find \n#{elem}  or even\n#{elem2}\nplease check definitions\n"
        end
      end
      get_page_text true
      text_validate txt_hsh, presence_check
      element_validate div
    }
  end

  def check_texts text_hsh_list, presence_check = true
    raise BadInputDataError, "text_hsh_list is empty" if text_hsh_list.empty?
    get_page_text "take fresh"
    text_hsh_list.each { |txt_hsh| text_validate txt_hsh, presence_check }
    p "#Unchecked Text:\n#{@page_text.gsub('Error Required field', '')}", :c #if verbose_mode
  end

  def check_elements element_list
    raise BadInputDataError, "element_list is empty" if element_list.empty?
    element_list.each { |field| element_validate field }
  end

  def check_info_center list_list
    raise BadInputDataError, "info_center_list is empty" if list_list.empty?
    list_list.each { |list_hsh| select_list_validate list_hsh }
  end

  def check_lists list_list
    raise BadInputDataError, "list_list is empty" if list_list.empty?
    list_list.each { |list_hsh| select_list_validate list_hsh }
  end

  def check_links link_list
    raise BadInputDataError, "link_list is empty" if link_list.empty?
    link_list.each { |link_hsh| check_link link_hsh }
  end

end