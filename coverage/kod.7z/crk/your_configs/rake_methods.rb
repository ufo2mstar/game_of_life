module RakeFileMate
# example:
# flagify_with(" --flag_str ",["a","b"])
# => " --flag_str a --flag_str b"
#
# # flagify_with(" --flag_str ",[])
# => ""

  def flagify_for(tag_str="", items_array)
    return "" if items_array.empty?
    tag_str + items_array.join(tag_str)
  end

# tagify(str) -> ary
#
# example:
# tagify("a,~b")
# => ["@a","~@b"]

  def tagify(tag_str="")
    tag_str.split(',').map { |tag| "@#{tag.strip}".gsub("@~", "~@") }
  end

# example:
# and_tags(["a","~b"])
# => " --tag @a --tag ~@b"

  def and_tags_flag
    return "" unless ENV_and_tags
    and_tags_array = tagify ENV_and_tags
    flagify_for " --tags ", and_tags_array
  end

# example:
# or_tags(["a","~b"])
# => " --tag @a,~@b"

  def or_tags_flag
    return "" unless ENV_or_tags
    or_tags_string = tagify(ENV_or_tags).join(',')
    " --tags "+or_tags_string
  end

  def parse_and_verify(what_to_validate, *list_as_str)
    err             =[]
    potential_array = parse_to_a list_as_str[0], list_as_str[1]
    # filter_for_lob STATE_EXPN # todo why do i care??
    case what_to_validate
      # todo hmmm.. try proc-ing below
      when :states then
        potential_array.map!(&:upcase)
        potential_array.each { |state_abbr|
          err << state_abbr unless state_abbr.length.eql?(2) and STATE_EXPN[state_abbr]
        }
      when :browsers then
        potential_array.map!(&:downcase)
        potential_array.each { |browsers|
          err << browsers unless BROWSERS.include?(browsers.downcase)
        }
      when :views then
        potential_array.map!(&:downcase)
        potential_array.each { |views|
          err << views unless VIEWS.include?(views.downcase)
        }
      else
        raise 'Expected [ :states || :browsers || :views ]'
    end
    raise " Hmm, not matching '#{what_to_validate}' = #{err} \n  btw, got the list => #{potential_array}" unless err.empty?
    potential_array
  end

  def get_in_the_game
    @@housewords ||= ['Winter is Coming', 'Ours is the Fury', 'We Do Not Sow', 'Unbowed, Unbent, Unbroken', 'Family, Duty, Honor', 'Here We Stand', 'Fire and Blood', 'Hear Me Roar!', 'Growing Strong', 'Honed and Ready', 'We Remember', 'Proud to be Faithful', 'Above the Rest', 'The Sun of Winter', 'Iron from Ice']
    @@housewords.sample
  end

end

include RakeFileMate

module CukeProfileSetup
  extend self

  def setup(task, state_abbr, browser_type, view_type)
    color =verbose=f_usage=f_progr=f_json=includes=excludes=f_html=f_prety="" #initializing optional flags

    browser   = " browser=#{browser_type}"
    state     = " state=#{state_abbr}"
    view      = " view=#{view_type}"
$timestamp  = Time.now.strftime "%Y-%m-%d_%H-%M-%S_"

    # yp Dir[File.dirname(__FILE__)+"/../../*"]
    # a=(Dir[File.dirname(__FILE__)+"/../../*"].select{|x| x =~ /#{Regexp.escape ENV_lob}/i})[0]
    # app_dir   =(Dir[File.dirname(__FILE__)+"/../../*"].select { |x| x =~ /#{Regexp.escape ENV_lob}/i })[0] # todo.. better use of crank
    app_dir   =(Dir[File.dirname(__FILE__)+"/../../*"].select { |x| x =~ /renters/i })[0] # todo.. better use of crank
    # app_dir_cov =(Dir[File.dirname(__FILE__)+"/../../**/05_CoveragesPage/*.feature"].select { |x| x =~ /#{Regexp.escape ENV_lob}/i })[0] # todo.. better use of crank
    # raise "Name your app after ENV['lob'] please (ie: #{ENV['lob']})\n and have your env.rb file require stuff properly!\n" unless app_dir
    # basic     = " -g -r features #{(a=(Dir[File.dirname(__FILE__)+"/../../*"].select{|x| x !~ /crank$/})[0])}"
    basic     = " -g -r features #{app_dir}"
    state_tag = " -t @#{state_abbr}"
    color     = " --#{"no-" unless ENV['color'] or ENV['color']=~/Y/i}color" #if ENV_color
    verbose   = " -v" if ENV['verbose']
    f_prety   = " -f pretty"

    file_name = "#{$timestamp}#{state_abbr}_#{browser_type[0]}_#{view_type[0]}#{"_#{$app_env}" if $app_env}#{$html_txt}"
    f_html    = " -f html --out #{$output_folder+'_'+file_name}.html" # underscore for unverified htmls.. will be removed on the clean step.. see rakefile at_exit
    # todo: think about $make_other_reports
    if $make_other_reports
      f_usage = " -f usage --out #{$output_folder_usage+file_name}_usage.txt" if $output_folder_usage
      f_progr = " -f progress --out #{$output_folder_progress+file_name}_prog.txt" if $output_folder_progress
      f_json  = " -f json --out #{$output_folder_jason+file_name}.json" if $output_folder_jason
    end
    ignore_exts      = flagify_for " -e \\.", %w{html yml jpg png docx xls xml pdf txt sql bat json uml xml png}
    # includes    = flagify_for " -r ", %w{../*/env.rb}
    includes         = flagify_for " -r ", [app_dir+"/env.rb"]
    # excludes    = flagify_for " -e ", %w{scenarios auto}
    special_and_tags = ENV['run_special_tags']=~/Y/i ? '' : ' --tags ~@special'

    task.profile       = "pointless"
    task.cucumber_opts = and_tags_flag+special_and_tags+or_tags_flag+state_tag+browser+state+view+includes+excludes+basic+color+verbose+ignore_exts+f_prety+f_usage+f_progr+f_json+f_html
  end
end

module TaskSetup
  extend self
# todo # build app specific possi tasks
# todo # build bare required tasks
# builds all possible state browser combinations
#   def build_all_tasks(states=nil, browsers=nil, views=nil)
  def build_all_tasks(state_array=$state_array, browser_array=$browser_array, views=$views)
    state_array   = Array state_array || STATE_EXPN.keys
    browser_array = Array browser_array || BROWSERS
    views_array   = Array views || VIEWS
    power_pair state_array, browser_array, views_array do |state, browser, view|
      Cucumber::Rake::Task.new((browser + ':' + state+ ':'+ view).to_sym, "Runs #{browser + ':' + state + ':'+ view} task") { |t| CukeProfileSetup.setup(t, state, browser, view) }
    end
  end
end

#   Rakefile Methods! -------------------------------------------------------------------------------
module Cuke
  extend self

  def task_run(state, browser, view)
    print "Runing : #{"%-10s" % state} on #{"%-11s" % browser.upcase} with #{"%-11s" % view.upcase} for #{"%-15s" % ENV['lob'].upcase} in #{"%-10s" % ENV['app_env'].upcase}\n"
    # print a="\n.\n..\n...\n"
    begin
      # Rake::Task["run:#{browser}:#{state}"].execute
      # Rake::Task["run:#{browser}:#{state}"].invoke
      # Rake::Task["#{browser}:#{state}:#{view}"].invoke ; Rake::Task["#{browser}:#{state}:#{view}"].reenable
      Rake::Task["#{browser}:#{state}:#{view}"].execute
    rescue Exception => e
      p "\nInspect this Task ERROR in Task[#{browser}:#{state}:#{view}] :- \n#{e.inspect}\n"
    ensure
      # print a.reverse
    end
  end

  def list_run(state_array=$state_array, browser_array=$browser_array, views=$views)
    power_pair state_array, browser_array, views do |state, browser, view|
      task_run(state, browser, view)
    end
  end

  def thread_run(state_array=$state_array, browser_array=$browser_array, views=$views)
    all_combos = power_pair state_array, browser_array, views
    threads    =[]
    raise "\nENV['max_threads'] not defined brah!\n\n" unless ENV['max_threads']
    max_threads = ENV['max_threads'].to_i
    while all_combos.length != 0
      if threads.length < max_threads
        comboo = all_combos.shift
        begin
          threads << Thread.new(comboo) do |combo|
            begin
              puts "\nRunning test for #{combo}\n"
              state, browser, view = combo
              # if you wanna run multiple process itself use next line and comment between <!-- -->
              # %x"start cmd /k rake \"run:env[browser_types:#{browser}|states:#{state}|browser_size:#{view}|force_close_fails:Y]\""
              # <!--
              task_run(state, browser, view)
              # -->
            rescue Exception => e
              puts "\nError Executing run in - #{'%-25s' % Thread.current} i mean for :#{'%-25s' % combo} = #{e.inspect}\n#{"="*180}\n\n"
            end
          end
        rescue Exception => e
          puts "^"*80+"\n"
          puts "threading error?? - #{e.inspect}\n\n"
        end
      else
        threads.delete_if { |t| !t.alive? }
      end
    end
    threads.each { |t| t.join }
  end
end

#   Cosmetics -------------------------------------------------------------------------------

# todo split to diff file
# check for impt ENV variables and raise to point out the errors!
def undefined_important_ENVs_handler
  # Impt Env Variables check >>>>>>>>>
  # todo make proper
  # raise "\nENV['state'](<-- deprecated)\nENV['states'](<-- commended)\n\n" if ENV['state']
  # raise "\nENV['browser_type'](<-- deprecated)\nENV['browser_types'](<-- commended)\n\n" if ENV['browser_type']
  raise "\nENV['states'] or ENV['state'](<-- deprecated) not declared!.. \n say something like 'dc' or 'Oh' or 'Indiana' or 'New york' or something for ENV['state']\nor better yet, like 'DC,oH' or 'IL,Indiana' or 'Vermont,New york' or something for ENV['states']\n\n" unless ENV['states']
  raise "\nENV['browser_types'] or ENV['browser_type'](<-- deprecated) not declared!.. \nsay something like 'chrome' or 'ie,firefox' or something\n\n" unless ENV['browser_types']
  raise "\nENV['app_env'] not declared!.. \nsay something like 'dev' or 'it' or something\n\n" unless ENV['app_env']
  raise "\nENV['and_tags'] not declared!.. \nsay something like 'OH,kyu' or 'cit,KY' or something\n\n" unless ENV['and_tags']
  # <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
  # puts "IntrodUsing \"FlashFill\" !!\nBe Amazed.. Be Very Amazed...\n(at how fast the pages fly by!) \n               *conditions apply\n\n" if ENV["flash_fill"]
  puts "\nAlso, you are Profiling the navigation!         >>>------>\n\n" if ENV["navigation_profiling"]
  # print "Env --> #{ENV['app_env'].upcase}\n"
end

def end_timer
  # print "\n#{'-'*50} Ending : #{$ttoc=Time.now} #{'-'*50}\n"
  # warn "\n      *conditions that not all your scenarios may pass! :P\n   do contact 'sivasn1' if you wanna fix stuff..\nThank you!" if ENV["flash_fill"]
  print "\nRunTime - #{Time.at($ttoc-$ttic).gmtime.strftime('%Mm %Ss %Nns')}  \n" unless ENV['max_local_threads']
end

def draw_start_line
  print draw_padded_line("Start : #{$ttic=Time.now; $ttic.strftime("%Y-%m-%d %H:%M:%S")}", ['-', 80, :r])
end

def draw_ended_line
  print draw_padded_line("Ended : #{$ttoc=Time.now; $ttoc.strftime("%Y-%m-%d  %H:%M:%S")}", ['-', 80, :r])
  end_timer
end


def parse_to_env(str)
  # sample_args  =>  states:oh.al|verbose:y|user:sivasn1|and_tags:kk.jj|browser_types:chrome|app_env:it
  itms = parse_to_a str, "|"
  env  = {}
  itms.each { |a|
    unless a.empty?
      kk         = a.split(':').map(&:strip)
      env[kk[0]] = kk[0] =~ /states|browser_types|browser_sizes/ ? kk[1].gsub('.', ',') : kk[1]
    end
  }
  env
end