require 'page-object/elements'
module PageObject
  module Elements
    class Input < Element

      protected

      def self.watir_finders
        [:class, :id, :index, :text, :xpath, :title]
      end

      def self.selenium_finders
        [:class, :id, :name, :text, :xpath, :index, :title]
      end
    end

    ::PageObject::Elements.tag_to_class[:input] = ::PageObject::Elements::Input

  end
end