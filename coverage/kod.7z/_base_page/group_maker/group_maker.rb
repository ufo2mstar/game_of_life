module GroupMaker
  # from help_group(:thing, "UI1001")
  # makes
  # #link(:thing_help_link, :id => "help_UI1000")
  # #span(:thing_help, :id => "help_button_UI1000")
  # #div(:thing_help_div, :id => "help_TextDiv_UI1000")
  def help_group (name,uid)
    # name,uid = name.to_s,uid.to_s
    link("#{name}_help_link".to_sym, :id => "help_#{uid}")
    span("#{name}_help".to_sym, :id => "help_button_#{uid}")
    div("#{name}_help_div".to_sym, :id => "help_TextDiv_#{uid}")
  end
end