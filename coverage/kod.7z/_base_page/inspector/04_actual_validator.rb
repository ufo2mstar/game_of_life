module TSA
  def discounts_validate disc_list, presence_check = true
    @errored_fields_list       = []
    cols                       = %w[green red]
    found_color, unfound_color = presence_check ? cols : cols.reverse
    # todo: look into extra matches... and warn
    raise BadInputDataError, "disc_list is empty\n" if disc_list.empty?
    if discounts_list_element.visible?
      discounts_text = discounts_list_element.text.gsub(/\s+/, " ").gsub(/Close/, ""); found_count=not_found_count=0
      error_text     ="\n"
      disc_list.each do |discount|
        # discount= d.values.first
        if discounts_text.include?(discount)
          error_text = error_text+("    Found: #{discount}\n").send(found_color)
          found_count+=1
        else
          error_text     = error_text+("Not Found: #{discount}\n").send(unfound_color)
          not_found_count+=1
        end
      end
      # raise DiscountError, "#{not_found_count}-not_found \n#{found_count}-found \n\n#{error_text}\nGot:\n#{discounts_text}\n\n#{not_found_count} not found \n#{found_count} found\n" if ((presence_check ? 1:-1) * not_found_count) > 0
      raise DiscountError, "#{not_found_count}-not_found \n#{found_count}-found \n\n#{error_text}\nGot:\n#{discounts_text}\n\n#{not_found_count} not found \n#{found_count} found\n" if (presence_check ? not_found_count : found_count) > 0
    else
      (p("Discount Modal Window not displayed!.. Ergo \n#{disc_list.join(" - not found \n")} = not found\n", :g); return) unless presence_check
      raise DiscountError, "\nDiscount Modal Window not displayed!\n"
    end
    p "#{error_text}\nGot:\n#{discounts_text}", :g #if verbose_mode # this is actually valid text now! :)
  end

  def scrape_select_list_values list_name
    # todo: see why this is so? did you just debug this or is this not working for flashfill!
    if you_want_flash_fill # and browser_type =~ /fire|chrome/i # todo: try this for other browsers to see
      # a="";$('#UI12026 option').each(function(){a=a+';'+$(this).text()});a
      attrib = (self.send(list_name).instance_variable_get(:@element).instance_variable_get(:@selector) || self.send(list_name).instance_variable_get(:@selector))
      id     = attrib[:id]
      js_str = browser_type =~ /fire/i ? "var a=[]; $('##{id} option').map(function(){a.push($(this).text())}); return a" : "return $('##{id} option').map(function(){return $(this).text()})"
      @browser.execute_script(js_str)
    else
      self.send(list_name).options.map { |item| item.text }
    end
  end

  def scrape_select_list_current_value list_name
    # todo: see why this is so? did you just debug this or is this not working for flashfill!
    if you_want_flash_fill # and browser_type =~ /fire|chrome/i # todo: try this for other browsers to see
      # a="";$('#UI12026 option').each(function(){a=a+';'+$(this).text()});a
      attrib = (self.send(list_name).instance_variable_get(:@element).instance_variable_get(:@selector) || self.send(list_name).instance_variable_get(:@selector))
      id     = attrib[:id]
      js_str = "return $('##{id}').siblings().first().text()"
      @browser.execute_script(js_str)
    else
      self.send(list_name)
    end
  end

  private
  def select_list_default_validate list_def_hsh
    list_name, def_expected = elementify(list_def_hsh.keys[0]), list_def_hsh.values[0]
    p " List Def : #{list_name}", :gy
    def_on_the_page = self.send(list_name).value
    if def_on_the_page == def_expected
      p "  Default : '#{def_on_the_page}'", :g
    else
      p "Default Val Exp : '#{def_expected}'", :m
      p "Default Val Got : '#{def_on_the_page}'", :r
      @errored_fields_list << "\nPage has: '#{def_on_the_page}'\nExpected: '#{def_expected}'\n"
    end
  end

  def select_list_validate list_hsh, silent = nil
    list_name, text_content = elementify(list_hsh.keys.first), list_hsh.values.first
    list_content            = parse_to_a text_content, ';'
    p "List Name : #{list_name}", :gy
    list_on_the_page = scrape_select_list_values list_name
    if list_content.eql?(list_on_the_page)
      p "List Vals : #{list_on_the_page}", :g
      element_validate list_name, 'lightgreen', 'presence', silent
    else
      p "Expecting : #{list_content}", :bl
      p "Foundlist : #{list_on_the_page}", :m
      element_validate list_name, 'red', 'presence', silent
      @errored_fields_list << "\nPage has: #{list_on_the_page}\nExpected: #{list_content}\n"
    end
  end

  def text_validate text_hsh, presence_check = true
    label_name, text_content = text_hsh.keys.first, text_hsh.values.first
    display_format           = "#{"%32s" % ("'#{label_name}'")} -> '#{text_content}'"
    if text_content.nil?
      p "Blank : #{display_format}", :m
    else
      # warn: Careful with your regexed matches!.. might erase your @page_text with bad regexes
      text_content = text_content[(/^\/(.*)\/$/), 1] ? $1 : Regexp.escape(text_content)
      get_page_text unless @page_text
      # if @page_text.include?(text_content)
      # if @page_text =~ /#{Regexp.escape text_content}/
      if @page_text =~ /#{text_content}/
        # todo : highlighting if deemed necessary!
        @page_text = @page_text.sub(/#{text_content}/, "") # removes old text to remove redundant positive match
        p "Found Text : #{display_format}", presence_check ? :g : :r
        @errored_fields_list << display_format unless presence_check
      else
        p "Missing Text : #{display_format}", presence_check ? :r : :g
        @errored_fields_list << display_format if presence_check
      end
    end
  end

  def element_validate field, color = 'lightgreen', presence_check = true, silent=nil
    begin
      @old_silent    = ENV['silent']
      ENV['silent']  = silent
      @fill_commands = ""
      field_type     = attrib =nil

      field_name                  = elementify field
      field_type                  = self.send(field_name).class.to_s

      # if (attrib=self.send(field_name).instance_variable_get(:@element).instance_variable_get(:@selector) || attrib=self.send(field_name).instance_variable_get(:@selector))
      #   if attrib[:xpath]
      #     # xid=(attrib[:xpath] ? attrib[:xpath][/\/\/label\[@for='(.*)'\]/, 1] : nil)
      #     # xid=(attrib[:xpath][/\/\/(.*)\[@(\w+='.*')\]$/]; $1 ? [$1, $2] : nil)
      #     xp = attrib[:xpath].match(/\/\/(.*)\[@(\w+='.*')\](.*)/)
      #     xid=(xp[3].empty? ? [xp[1], xp[2]] : nil)
      #     # p "XID = '#{xid}' - [#{[xp[1], xp[2], xp[3]]}]"
      #     # xid=(attrib[:xpath] ? (attrib[:xpath][/\/\/(.*)\[@(\w+='.*')\](?:$|\/(.*)$)/]; [$1, $2, $3]) : nil)
      #   elsif attrib[:id]
      #     if attrib[:id].respond_to? :source
      #       attrib[:id].source.gsub(/[()]/, '').split("|").each { |trial_id| id=trial_id if @browser.execute_script("return $('##{trial_id}').is(':visible')") }
      #     else
      #       id =attrib[:id]
      #     end
      #     #elsif attrib[:tag_name]=='label'
      #     #  text=value
      #   elsif attrib[:text]
      #     text=attrib[:text]
      #   end
      #   #  #todo:(alt,class,index) if neccessary
      # end

      id, xid, text, name, attrib = flash_find(field_name)
      if xid
        xp  = attrib[:xpath].match(/\/\/(.*)\[@(\w+='.*')\](.*)/)
        xid =(xp[3].empty? ? [xp[1], xp[2]] : nil)
      end
      begin
        case field_type
          when /select|heading|paragraph|Elements::Element/i
            (@fill_commands+="$('##{id}')") if id
          when /text|div|span|label|list/i
            (@fill_commands+="$('##{id}')") if id
            (@fill_commands+="$(\"#{xid[0]}[#{xid[1]}]#{xid[2]}\")") if xid
          when /checkbox/i, (/label/i if field =~ /checkbox/i)
            # (@fill_commands+="$('##{xid}')") if xid
            (@fill_commands+="$('##{id}')") if id
            #(@fill_commands+="$(\"label:contains('#{text}')\")[0].click();") if text
            (@fill_commands+="$(\"label\").filter(function(){return $(this).text()==='#{text}';}).first()") if text
          when /radio/i, (/label/i if field !~ /checkbox/i)
            (@fill_commands+="$('##{id}')") if id
            # (@fill_commands+="$('##{xid}')") if xid
            #(@fill_commands+="$(\"label:contains('#{text}')\").first()") if text
            (@fill_commands+="$(\"label\").filter(function(){return $(this).text()=='#{text}';}).first()") if text
          when /link|span|div/i
            (@fill_commands+="$('##{id}')") if id
            (@fill_commands+="$('a:contains(" "#{text}" ")')") if text
          when /button/i
            (@fill_commands+="$('##{id}')") if id
          when /image/i
            (@fill_commands="$('##{id}')") if id
            (@fill_commands="$(\"[id='#{id}']\")") if id and id.include? " "
          else
            fail("Unknown field type:" + field_type)
        end
      ensure
        if @fill_commands!=""
          if @browser.execute_script("return #{@fill_commands}.is(':visible')")
            p "Found : #{'%15s' % field_type.split(':')[-1]} : #{"%32s" % ("'#{field}'")} - #{"%30s" % attrib} ", presence_check ? :g : :r #if verbose_messages
            @browser.execute_script(@fill_commands+".attr('tabindex','-1')") if field_type =~ /image|div|label|span/i
            @browser.execute_script(@fill_commands+".focus()")
            @fill_commands+= case field_type
              when /Div/ then
                field=~/coverage/ ? ".children('label')" : ''
              when /donno/ then
                ".closest('li')"
              when /Select/ then
                ".siblings()"
              else
                ''
            end
            @browser.execute_script(@fill_commands+".css('background', '#{color}')")
            p @fill_commands+".css('background', '#{color}')" if ENV['fill_debug']
            @errored_fields_list << field unless presence_check
            return
          end
        end

        if self.send(field_name).visible? #or self.send(field_name).exists?
          p "Found using Watir: #{'%15s' % field_type.split(':')[-1]} : #{"%32s" % ("'#{field}'")} - #{"%30s" % attrib} ", presence_check ? :g : :r
          self.send(field_name).focus
          self.send(field_name).color_my_world (color =~ /green/i ? 'Lime' : color)
          #self.send(field_name).border_my_world
          @errored_fields_list << field unless presence_check
        elsif self.send(field_name).exists? and presence_check
          p "Exists but not Visible using Watir: #{'%13s' % field_type.split(':')[-1]} : #{"%32s" % ("'#{field}'")} - #{"%30s" % attrib} ", presence_check ? :r : :g
          @errored_fields_list << field
        else
          # todo.. exists but not visible thing?
          p "Missing using Watir: #{'%13s' % field_type.split(':')[-1]} : #{"%32s" % ("'#{field}'")} - #{"%30s" % attrib} ", presence_check ? :r : :g
          @errored_fields_list << field if presence_check
        end
        # end
      end
    rescue Exception => e
      p "Errored : #{'%13s' % field_type||"UnknownType" rescue "Errored for field_type"} : #{"%32s" % ("'#{field}'")} - #{"%30s" % attrib||"seems undefined in page class" rescue "Errored for attrib"} ", :r #if verbose_messages
      @errored_fields_list << e
    ensure
      ENV['silent']=@old_silent
      $sum         +=toc
    end
  end

end

if __FILE__ == $0
  require '../../useful_support/formatting_files/cosmetics'
  ENV["color"] = "kod"
  include TSA

  @errored_fields_list = []
  @page_text           = "STEP 2 OF 4: PROPERTY INFORMATION SAVED QUOTE ID: BGLMV9T3
50%
50%
* Required fields  secure
 The information below is based on building valuation reports. Please review.

* What year was the home originally built?
1700 - Present".gsub(/\s+/, ' ')

  p @page_text
  text_validate :aa => "/SAVED QUOTE ID: .{8,8}/"
  text_validate :aa => "/SAVED QUOTE ID: [A-Z0-9]{8}/"
  p @page_text
  p @errored_fields_list
end