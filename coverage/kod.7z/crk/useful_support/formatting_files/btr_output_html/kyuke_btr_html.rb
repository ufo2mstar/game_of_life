require 'cucumber/formatter/html'
#require_relative '_yemel'
module Cucumber
  module Formatter
    class Html

      def inline_css
        @builder.style(:type => 'text/css') do
          @builder << File.read(File.dirname(__FILE__) + '/bootstrap.min.css')
        end
        @builder.style(:type => 'text/css') do
          @builder << File.read(File.dirname(__FILE__) + '/kyuke.css')
        end
      end

      def print_messages
        print_details
        return if @delayed_messages.empty?

        #@builder.ol do
        @delayed_messages.each do |ann|
          @builder.li(:class => 'step message') do
            @builder << ann
          end
        end
        #end
        empty_messages
      end

      def print_details
        unless $txt.empty?
          @builder << "<div class='kyute'>"
          $txt.each { |line| @builder << "#{line}" }
          $txt = [] # flush $txt
          @builder << "</div>"
        end
      end

      # def before_step(step)
      #   print_messages
      #   @step_id     = step.dom_id
      #   @step_number += 1
      #   @step        = step
      # end

      def backtrace_line(line)
        line.gsub(/\A([^:]*\.(?:rb|feature|haml)):(\d*).*\z/) do
          if ENV['TM_PROJECT_DIRECTORY']
            "<a href=\"txmt://open?url=file://#{File.expand_path($1)}&line=#{$2}\">#{$1}:#{$2}</a> "
          else
            line
          end
        end
        # line # or just this
      end


      def inline_js
        @builder.script(:type => 'text/javascript') do
          @builder << inline_jquery
          @builder << inline_js_content
        end
      end

      def inline_jquery
        File.read(File.dirname(__FILE__) + '/jquery-1.11.3.min.js')+
            File.read(File.dirname(__FILE__) + '/bootstrap.min.js')
      end

      def inline_js_content
        File.read(File.dirname(__FILE__) + '/kyuke.js')
      end

      def puts(message)
        @delayed_messages << message
        # @builder.pre(message, :class => 'message')
      end

      def before_features(features)
        @step_count = features && features.step_count || 0 #TODO: Make this work with core!

        # <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        @builder.declare!(
            :DOCTYPE,
            :html,
            :PUBLIC,
            '-//W3C//DTD XHTML 1.0 Strict//EN',
            'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'
        )

        @builder << '<html xmlns ="http://www.w3.org/1999/xhtml">'
        @builder.head do
          @builder.meta('http-equiv' => 'Content-Type', :content => 'text/html;charset=utf-8')
          @builder.title 'Kyucumber!'
          inline_css
          inline_js
        end
        @builder << '<body>'
        @builder << "<!-- Step count #{@step_count}-->"
        @builder << '<div class="cucumber">'
        # @builder.div(:id => 'cucumber-header') do
        #   @builder.div(:id => 'label') do
        #     # @builder.h1('Kyucumber!')
        #   end
        @builder.div(:id => 'summary') do
          @builder.div('', :id => 'totals')
          @builder.div(:id => 'pass_fail_all', :class => 'btn-group') do
            @builder.button('Show All', :id => 'showall', :class => 'btn btn-primary')
            @builder.button('Show Fails', :id => 'fails', :class => 'btn btn-danger')
            @builder.button('Show Passes', :id => 'passes', :class => 'btn btn-success')
          end
          @builder.div('', :id => 'duration')
          @builder.div(:id => 'expand-collapse', :class => 'btn-group') do
            @builder.button('', :id => 'toggler', :class => 'btn btn-warning')
            @builder.button('Toggle_Details', :id => 'details', :class => 'btn btn-info')
          end
        end
        # end
      end


      def print_stats(features)
        @builder << "<script type=\"text/javascript\">document.getElementById('duration').innerHTML = \"<p>Run Time : <strong>#{format_run_time(features.duration)}</strong></p>\";</script>"
        # p print_stat_string(features)
        @builder << "<script type=\"text/javascript\">document.getElementById('totals').innerHTML = \"#{print_stat_string(features)}\";</script>"
      end

      def format_run_time time_s
        h, m, s, ms = Time.at(time_s).utc.strftime('%H,%M,%S,%L').split(',')
        str         = ""
        %w{h m s ms}.each { |t| x=eval("#{t}.to_i"); str+="#{x} #{t} " if x != 0 }
        str
      end

      def print_stat_string(features)
        string           = ""
        total_count, str = dump_count(@runtime.scenarios.length, "scenario")
        string << "<p>#{str}</p>"
        string << "<div class='progress'>"
        scenario_progress = print_status_counts total_count do |status|
          @runtime.scenarios(status)
        end
        string << scenario_progress if scenario_progress
        total_count, str = dump_count(@runtime.steps.length, "step")
        string << "</div><p>#{str}</p><div class='progress'>"
        step_progress = print_status_counts total_count do |status|
          @runtime.steps(status)
        end
        string << step_progress + "</div>" if step_progress
      end

      def print_status_counts total_count
        progress_type = {:passed => 'success', :pending => 'striped', :skipped => 'info', :failed => 'danger', :undefined => 'warning'}
        counts        = progress_type.keys.map do |status|
          elements = yield status
          elements.any? ? "<div class='progress-bar progress-bar-#{progress_type[status]}' style='width: #{((elements.length)*(100.0)/total_count)}%'><span class='sr'>#{elements.length} #{status.to_s}</span></div>" : nil
        end.compact
        counts.join if counts.any?
      end

      def dump_count(count, what, state=nil)
        [count, [count, state, "#{what}#{'s' if count > 1}"].compact.join(" ")]
      end
    end
  end
end