#!/bin/env ruby
# encoding: utf-8

require 'fileutils'
require 'logger'
require_relative '../utils/string_extension'

# log_helper.rb
#   This file includes :
#     A custom logger class to support custom logger methods
#     Log formatters to define handling for different output formats
#       (html, raw text, console output)
#     A log aggregator to allow for simultanios logging to multiple
#       loggers/formats
#     Definitions for creation, configuration, and closing of FEAST's
#       world logger : @world.log


# Custom Logger
#   Extends logger to allow for custom logging methods in addition to
#     the standard:  INFO, DEBUG, WARN, ....
#   ex : logger.success("this is a success message")
# ** ALL LOGGERS USED IN FEAST INHERIT FROM THIS CLASS
# @api private-core
class CustomLogger < Logger
  METHODS = SEV_LABEL

  # Turns a string into a class method in addition to creating the corresponding severity level
  #   Is used to create custom logger functions
  #   ex. custom_type("biz_test"); logger.biz_test("biz_test log message") severity == "BIZ_TEST"
  def self.custom_type(type)
    SEV_LABEL << type.upcase
    index = SEV_LABEL.size - 1
    define_method(type.downcase.gsub(/\W+/, '_').to_sym) do |message, &block|
      add(index, message, nil, &block)
    end
  end

  # Turns a hash into logger functions and corresponding
  #   severity types
  # @param types [Hash] a hash of log function names and the colors that go with them
  def self.define_types(types)
    @output_types = types
    types.keys.each do |key|
      custom_type(key)
    end
  end

  # returns the output types with their {options} to be used by formatters
  def self.output_types()
    return @output_types
  end
end

# Console Formatter
#   Outputs log messages to the console after wrapping them
#     in color codes for pretty output
#   Can be configured to only print specific log tags and
#     to print in color or not
# @api private-core
class ConsoleFormatter < CustomLogger

  def initialize()
    super(STDOUT)
  end

  def configure(type_array, use_color = true)
    @active_tags = type_array
    @use_color = use_color
    self.level = 0
  end

  def add(idx, message, progname)
    # don't output message unless tag is active
    super(idx, message, progname) if @active_tags.include? METHODS[idx]
  end

  def format_message(severity, datetime, progname, message)
    if @use_color
      colors = CustomLogger.output_types[severity]

      # find the pieces to color with effect ([this_is_special])
      special_regex = /\[.*?\]/
      special_pieces = message.scan(special_regex).each do |special_piece|
        special_colors = []
        special_colors << colors['EFFECT'] if colors['EFFECT']
        special_colors << colors['BACKGROUND'] if colors['BACKGROUND']
        special_piece.color!(special_colors)
      end

      # color the rest of the pieces
      normal_pieces = message.split(special_regex).each do |normal_piece|
        # make sure we dont color it with special color
        default_colors = []
        default_colors << colors['FOREGROUND'] if colors['FOREGROUND']
        default_colors << colors['BACKGROUND'] if colors['BACKGROUND']
        normal_piece.color!(default_colors)
      end

      # piece the message together
      message = ""
      normal_pieces.each_with_index do |normal_piece, index|
        special_piece = (special_pieces.size > index ? special_pieces[index] : "")
        message += "#{normal_piece}#{special_piece}"
      end
    end

    return message
  end

  def close()
    # do nothing, we don't want to close STDOUT
  end
end

# HTML Formatter
#   Outputs log messages to an html file in specified outputPath
#     Formats log messages in html to increase readability
# @api private-core
class HTMLFormatter < CustomLogger
  def initialize(outputPath)
    file = File.open("#{outputPath}/#{Time.now.strftime("%m-%d-%Y__%I-%M%p")}.html", 'w')
    super(file)
    self.level = 0

    preHTML = %Q()
    self << preHTML
  end

  def format_message(severity, datetime, progname, message)
    %Q(Html formatted message)
    return message
  end

  def close()
    postHTML = %Q()
    self << postHTML
    super()
  end
end

# Raw Formatter
#   Outputs log messages to a plain text file
# @api private-core
class RawFormatter < CustomLogger

  def initialize(outputPath)
    file = File.open("#{outputPath}/#{Time.now.strftime("%m-%d-%Y__%I-%M%p")}.txt", 'w')
    super(file)
    self.level = 0
  end

  def format_message(severity, datetime, progname, message)
    return message
  end
end

# Log Aggregator
# A class that acts as a centralized logger
#   Will simultaneously log to all loggers passed in during setup
# @api private-core
class LogAggregator

  def initialize(loggers)
    @targets ||= loggers
    @message_cache = []

    # Adds handling to this class for all log methods definied in CustomLogger
    CustomLogger::METHODS.each do |methodName|
      name = methodName.downcase.to_sym
      define_singleton_method(name) do |message|
        # makes sure we output to each logger
        message = "#{message.inspect}\n" unless message.is_a? String
        @message_cache << "<#{Time.now().strftime("%Y:%m:%d-%H:%M:%S:%L")}>" + message
        @targets.each {|t| t.send(name, message)}
      end
    end
  end

  def last_n_messages(number_of_messages = @message_cache.length())
    return @message_cache.last(number_of_messages)
  end

  # Make sure we close each logger individually
  def close
    @targets.each {|logger| logger.close()}
  end
end

# Log Helper
#   Defines methods for creation, configuration, and closing of the world log object
# @api private-core
module LogHelper
  attr_reader :log

  # Read in users configuration for active log flags to output to console
  def get_active_output_types(possible_types)
    if not environment_variable_defined?(:log_types)
      output_types = ['VALIDATION_POINT', 'VALIDATION_PASS', 'VALIDATION_FAIL']
    else
      output_types = get_environment_variable(:log_types).split(",").each{|word| word.upcase!; word.strip!}
    end

    if output_types.include? 'VALIDATION'
      output_types.push('VALIDATION_POINT') unless output_types.include? 'VALIDATION_POINT'
      output_types.push('VALIDATION_PASS') unless output_types.include? 'VALIDATION_PASS'
      output_types.push('VALIDATION_FAIL') unless output_types.include? 'VALIDATION_FAIL'
      output_types.delete('VALIDATION')
    elsif output_types.include? 'NONE'
      output_types = ['NO_OUTPUT']
    elsif output_types.include? 'ALL'
      output_types = possible_types
    end
    return output_types
  end

  # Creates and configures loggers to be used based on environment variables
  def create_log
    loggers = []
    default_config = get_data_from_yml_file("CORE/config/defaults/default_log_types.yml")
    user_config = get_data_from_yml_file("CORE/config/user_log_config.yml")
    merged_config = merge_nested_hashes(default_config, user_config)

    raise "Incorrect format for user log config. See CORE/config/user_log_config.yml" unless (merged_config.has_key?("LOG_TYPES") and merged_config.has_key?("STYLE_DEFINITIONS"))

    types = merged_config["LOG_TYPES"]
    CustomLogger.define_types(types)

    color_definitions = merged_config["STYLE_DEFINITIONS"]
    String.define_colors_for(color_definitions)

    console_logger = ConsoleFormatter.new()
    color_output_enabled = (environment_variable_defined?(:color_output) == false or get_environment_variable(:color_output) == true)
    active_output_types = get_active_output_types(types.keys)
    console_logger.configure(active_output_types, color_output_enabled)
    loggers << console_logger

    if environment_variable_defined?(:log_directory) == true
      outputPath = get_environment_variable(:log_directory)
      FileUtils.mkdir_p(outputPath) unless Dir.exist?(outputPath)

      loggers << HTMLFormatter.new(outputPath)
      loggers << RawFormatter.new(outputPath)
    end

    @log = LogAggregator.new(loggers)
  end

  # Wraps everything up making sure all logs are closed properly
  def close_log
    @log.close
  end

  $results = [] unless $results
  def log_progress(scenario)
    $results << scenario.status

    @log.info("--------------------------------------------------------------------------------------------\n")
    @log.info("Progress:   ")
    faces_per_line = 6
    $results.each_with_index do |result, index|
      if (index + 1) % faces_per_line == 0 and index != 0
        @log.info("\n")
      elsif index != 0
        @log.info(' | ')
      end
      @log.validation_pass('ᕦ༼ຈل͜ຈ༽ᕤ (PASSED)') if result == :passed
      @log.validation_fail('(ノಠ_ಠ)ノ︵┻┻ (FAILED)') if result == :failed
      @log.validation_pending('¯\_(⊙_ʖ⊙)_/¯ (PENDING)') if result == :pending
    end
    @log.info("\n--------------------------------------------------------------------------------------------\n")
  end

  private

  def merge_nested_hashes(h1, h2)
    if h2.is_a?(Hash)
      h2.each do |key, value|
        if h1.is_a?(Hash) and h1.has_key?(key)
          h1[key] = merge_nested_hashes(h1[key], value)
        else
          return h2
        end
      end
    else
      return h2
    end
    return h1
  end
end
