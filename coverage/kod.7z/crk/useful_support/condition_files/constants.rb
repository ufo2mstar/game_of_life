module Constants
  OS ||=
      case RbConfig::CONFIG['host_os']
        when /mingw|mswin|msys|cygwin|bccwin|wince|emc/ then
          "windows"
        when /darwin|mac os/ then
          "macosx"
        when /linux/ then
          "linux"
        when /solaris|bsd/ then
          "unix"
        else
          raise Error::WebDriverError, "Unknown OS : #{RbConfig::CONFIG['host_os'].inspect}"
      end

  def require_all_in (path)
    Dir[File.dirname(__FILE__)+path[1..-1]].each { |f| require f }
  end

  # States Stuff---------------------------
  state_abbr_keys = YAML.load_file(File.dirname(__FILE__)+'/../../your_configs/state_abbrs.yml')
  STATE_EXPN      = state_abbr_keys
  STATE_ABBR      = state_abbr_keys.invert

end

include Constants
World(Constants)