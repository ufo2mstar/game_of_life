module PageFiller

  $sum=0

  def quick_wait
    wait_until { @browser.execute_script("return document.readyState") == "complete" }
    wait_until { @browser.execute_script("return jQuery.active == 0") } rescue load_jquery
  end

  def flash_find_reset
    @id, @xid, @text, @name, @field_type, @id_fier = nil, nil, nil, nil, nil, nil
  end

  def flash_find element
    flash_find_reset
    element     = elementify element
    @field_type = self.send(element).class.to_s
    if (attrib=self.send(element).instance_variable_get(:@element).instance_variable_get(:@selector) || attrib=self.send(element).instance_variable_get(:@selector))
      if attrib[:xpath]
        # xid=(attrib[:xpath] ? attrib[:xpath][/\/\/label\[@for='(.*)'\]/, 1] : nil)
        # xid=(attrib[:xpath] ? (attrib[:xpath][/\/\/(.*)\[@(\w+='.*')\]$/]; [$1, $2]) : nil)
        xid =(attrib[:xpath] ? (attrib[:xpath][/\/\/(.*)\[@(\w+='.*')\](?:$|\/(.*)$)/]; [$1, $2, $3]) : nil)
      elsif attrib[:id]
        if attrib[:id].respond_to? :source
          attrib[:id].source.gsub(/[()]/, '').split("|").each { |trial_id| id=trial_id if @browser.execute_script("return $('##{trial_id}').is(':visible')") }
        else
          id =attrib[:id]
        end
        #elsif attrib[:tag_name]=='label'
        #  text=value
      elsif attrib[:text]
        text=attrib[:text]
      elsif attrib[:name]
        name=attrib[:name]
      end
      #  #todo:(alt,class,index) if neccessary
    end
    @id   = id
    @xid  = xid
    @text = text
    @name = name
    [id, xid, text, name, attrib]
  end

  def exorbitant_logical_checker yup
    @id_fier   = case
      when @id
        "$('##{@id}')"
      when @xid
        "$(#{xselect})"
      when @text
        "$('label').filter(function(){return $(this).text()==='#{@text}';})[0]" # css selector does not support dom elements!
      else
        p "..No '@id_fier' obtained.. contact naren..", :r; return false
    end
    is_checked = @browser.execute_script("return #{@id_fier}.is(':checked')")
    !!yup ^ is_checked
  end

  def xidid xid = @xid
    xid[1][/='(.*)'/, 1].gsub(/([:.\\\/\[\], ])/, '\\\\\\\\\1') if xid
  end

  def xselect xid = @xid
    @field_type =~ /Label/ ? "\"#{xid[0]}[#{xid[1]}]#{xid[2]}\").siblings(" : "\"#{xid[0]}[#{xid[1]}]#{xid[2]}\"" if xid
  end

  def enter_element_value_gordon(field, value)
    tic
    @fill_commands  =""
    # todo oh dear god.. clean this up!
    non_flash_field = field
    if is_carousel_element(field)
      field = (field.gsub(/(_| )element/, '') + " " + value+"_element").gsub(" ", "_").downcase
    end
    yup                 = value =~ /yup|ya|yes/ # ? true : nil
    nope                = value =~ /unclick/ # ? true : nil
    element             = elementify field
    field_type          = self.send(element).class.to_s
    id, xid, text, name = flash_find(element)
    # todo: look into..
    #Selenium::WebDriver::Error::StaleElementReferenceError
    # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> visib handle
    # todo: think about xid array handle!
    if store_all_fill_info
      begin
        if id or xid #and not field_type.to_s =~ /text/i
          (p("skippin -> #{id ? "id" : "xid"}: #{id||xid} => #{field}", :y) if verbose_mode; return false) unless (@browser.execute_script("return $('##{id||xidid}').is(':visible')\;") or field_type.to_s =~ /image/i)
        # elsif text
        #   (p("skippin -> text: #{text}=> #{field}", :y) if verbose_mode; return false) unless @browser.execute_script("return $(\"label:contains('#{text}')\").is(':visible')\;")
        end
      rescue Exception => e
        p "#{e}\n Look into this soon.. not skipping this for now", :r
      end
    end

    # <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    p "#{'%15s' % field_type.split(':')[-1]} : #{"%32s" % ("'"+field+"'")} => #{"%-40s" % value.inspect} - #{"%30s" % attrib} ", :m if verbose_mode
    begin
      case field_type
        when /div|button/i
          (@fill_commands+="$('##{id}').focus();$('##{id}').click();";) if id
          (@fill_commands+="$('[name=##{name}]').focus();$('[name=##{name}]').click();";) if name
        when /select/i
          ebi_store field, value
          (@fill_commands+="$('##{id}').focus();$('##{id} option').filter(function(){return this.text=='#{value}';}).attr('selected',true);
                            $('##{id} ~>').html('#{value}');$('##{id}').change();";) if id
        when /text/i
          value = email_override value if field =~ /email/i
          for_retrieval field, value
          (@fill_commands+="$('##{id}').focus();$('##{id}').val('#{value}');$('##{id}').blur();$('##{id}').trigger('blur');$('##{id}').change();$('##{id}').keyup();";) if id
        when /checkbox|input/i, (/label/i if field =~ /checkbox/i)
          @fill_commands+= exorbitant_logical_checker(yup) ? "#{@id_fier}.focus();#{@id_fier}.click();" : " "
        when /radio/i, (/label/i if field !~ /checkbox/i)
          unless nope
            (@fill_commands+="$('##{id}').focus();$('##{id}').click();"*2;) if id
            (@fill_commands+="$(#{xselect}).focus();$(#{xselect}).click();"*2;) if xid
            (@fill_commands+="$(\"label:contains('#{text}')\")[0].click();";) if text
          end
        #(@fill_commands+="$(\"label\").filter(function(){return $(this).text()==""#{text}"";})[0].click()"; ) if text
        when /span|ListItem/i
          (@fill_commands+="$('##{id}').focus();$('##{id}').click();";) if id
          (@fill_commands+="$(\"span:contains('#{text}')\")[0].click();";) if text
        when /link/i
          (@fill_commands+="$('##{id}').focus();$('##{id}').click();";) if id
          (@fill_commands+="$(\"a:contains('#{text}')\").focus();$(\"a:contains('#{text}')\").click();";) if text

        when /image/i
          # (@fill_commands+="$(\"img[id='#{id}']\").focus();$(\"img[id='#{id}']\").click();";) if id
          # (@fill_commands+="$(\"img.getElementById(#{id}).focus();$(\"img[id='#{id}']\").click();";) if id
          # (@fill_commands+="$(\"img.getElementById(#{id}).focus();") if id
        # (@fill_commands+="$(\"#{xid[0]}[#{xid[1]}]#{xid[2]}\")") if xid
        else
          raise("Unknown field type:" + field_type)
      end
      p "#{@fill_commands=="" ? "using watir fill :( for ('#{non_flash_field}','#{value}')" : @fill_commands}" if ENV["fill_debug"]
      return enter_element_value(non_flash_field, value) if @fill_commands==""
      (@browser.execute_script(@fill_commands); @fill_commands=""; return true) unless @fill_commands==""
      # true
      false
    rescue Exception => e
      p " rescuing error #{e}\nusing watir fill :( for ('#{non_flash_field}','#{value}')"
      return enter_element_value(non_flash_field, value)
    ensure
      quick_wait
      flash_find_reset
      $sum+=toc
    end
  end

  def is_carousel_element(field)
    field =~ /structural.material|roof.type|roof.style|exterior.walls|garage.structure/i
  end

  def enter_element_value(field, value)
    tic
    if is_carousel_element(field)
      field = (field.gsub(/(_| )element/, '') + " " + value+"_element").gsub(" ", "_").downcase
    end
    element    = elementify field
    field_type = self.send(element).class.to_s
    yup        = value =~ /yup|ya|yes/ # ? true : nil
    nope       = value =~ /unclick/ # ? true : nil

    begin
      case field_type.to_s
        when /select/i
          ebi_store field, value
          self.send(element).select value.to_s
          self.send(element).fire_event("onblur")
          self.send(element).fire_event("change")
        when /text/i
          value = email_override value if field =~ /email/i
          for_retrieval field, value
          return if self.send(element) == value
          # self.send(element+ "=", value)
          self.send(element).value = value
          self.send(element).send_keys :tab
          self.send(element).fire_event("onblur")
          self.send(element).fire_event("change")
        when /checkbox|input/i
          is_checked = send(element).checked?
          self.send(element).click if yup ^ is_checked
        when /radio/i
          # Watir::Wait.until { self.send(element).exists? }
          self.send(element).click unless nope
        when /link|span|div|button|ListItem/i
          self.send(element).click
        when /image/i
          carousel_len = field.split("_").length
          if carousel_len ==5
            carousel_type = field.split("_")[0, 3].join("_")
          else
            carousel_type = field.split("_")[0, 2].join("_")
          end
          # If we fill the page and then the user uses
          # And the user selects "Slate" for roof_type
          # step, the carousel will can potentially not
          # find it because we have passed it. Make it
          # go back to the beginning so it can find it easily.
          while self.send("#{carousel_type}_prev_element").visible?
            self.send("#{carousel_type}_prev_element").click
            sleep 1
          end
          while (self.send("#{carousel_type}_next_element").visible? and !self.send(element).visible?)
            self.send("#{carousel_type}_next_element").click
            sleep 1
          end
          # raise "Error: Could not find #{field + '_element'}" unless self.send(field+"_element").visible?
          self.send(element).click
        when /label/i
          if field =~ /checkbox/i
            is_checked = send(element).checked?
            self.send(element).click if yup ^ is_checked
          else
            self.send(element).click unless nope
          end
        else
          raise(FillTryError, "Unknown field type (in 'enter_element_value'): #{field_type}")
      end
      true
    ensure
      quick_wait
      $sum+=toc
    end
  end

  def for_retrieval field, value
    # for retreival scenarios without using databases!!
    $first_name            = value if field =~ /^first_name$/i
    $spouse_first_name     = value if field =~ /^spouse_first_name$/i
    $last_name             = value if field =~ /^last_name$/i
    $zipcode               = value if field =~ /^zip$/i
    $emailid               = value if field =~ /^email/i
    $bmonth, $bday, $byear = value.split('/') if field =~ /^birthday$/i
    ebi_store field, value
  end

  def ebi_store field, value
    case field
      when /^FIRST_NAME$/i
        $hsh['ebi_log_keys']["FIRST_NAME"] = value
      when /^LAST_NAME$/i
        $hsh['ebi_log_keys']["LAST_NAME"] = value
      when /^ZIP$/i
        $hsh['ebi_log_keys']["ZIP"] = value
      when /^BIRTHDAY$/i
        $hsh['ebi_log_keys']["CLIENT_BIRTH_DATE"] = value
      when /^MARITAL_STATUS/i
        $hsh['ebi_log_keys']["MARITALSTATUS"] = value
      when /^EMAIL_ADDRESS$/i
        $hsh['ebi_log_keys']["EMAIL"] = value
      when /^PHONE_NUMBER$/i
        $hsh['ebi_log_keys']["PHONE"] = value
      else

    end
  end

  def email_override value
    # For Email override
    override_email = you_wanna_fill_your_email_id.to_s.strip
    unless override_email.empty?
      p "OverRiding Email from   '#{value}' -> '#{override_email}'", :br
      override_email
    else
      value
    end
  end
end


# World PageHelper