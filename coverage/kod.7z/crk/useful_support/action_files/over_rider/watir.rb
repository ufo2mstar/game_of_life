module Watir
  class Element
    def color_my_world color = 'blue'
      background_color = style("backgroundColor")
      driver.execute_script("arguments[0].style.backgroundColor = '#{color}'", @element)
      self
    end

    def border_my_world
      background_color = style("border")
      driver.execute_script("arguments[0].style.border = 'solid,green'", @element)
      self
    end
  end
end

# warn: the most frustrating problem recently
# warn: update: solved by just creating the browser obj outside the cucumber thread..
#
# require 'selenium/webdriver/common/platform'
#
# module Selenium
#   module WebDriver
#     # @api private
#     module Platform
#       def exit_hook(&blk)
#         pid = Process.pid
#         p " pid = #{pid}"
#         at_exit do
#           p "yield if Process.pid == pid = #{pid}"
#         end
#       end
#     end
#   end
# end