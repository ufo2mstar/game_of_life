# require 'yaml'
if __FILE__ == $0
  require_relative '../../../useful_support/formatting_files/cosmetics'

  require_relative 'non_lin_algo'
  require_relative '../../../useful_support/condition_files/err_raiser'


  class NonLinSearch
    def run_unit
      kk = @nav_doc.keys+@nav_doc.values
      # p kk1=kk.flatten
      kk2=kk.flatten.compact.uniq
      # p all_comb = kk2.combination(2).to_a
      # warn all_comb = kk2.combination(2).to_a
      warn all_comb = kk2.permutation(2).to_a
      print "\n#{all_comb.size} paths detected - lets run them -\n\n"
      print "Directory - \n"
      f          = File.open('ut_result.txt', 'w')
      error_list = []
      good_list  = []
      all_comb.each_with_index do |path, i|
        from       = path.first
        to         = path.last
        # paths_list = show_possible_paths(from, to)
        paths_list = all_paths(from, to)
        if paths_list.first.empty?
          error_list << "#{i}: #{from} -> #{to}"
        else
          res = "#{i}: #{from} -> #{to}  :\n     #{paths_list}\n"
          print res
          f.write res
          # good_list << "#{i}: #{from} ->> #{to}"
          # draw_path(from, to)
        end

      end
      print "\none sec..\n"
      f.close
      print "\n#{'-'*80}\n#{error_list.size} No Paths in theses directions :"
      yp error_list
    end

    def take_me(from_to_via, obj=nil)

      via_list = case from_to_via[:via].class.to_s
        when /Array/ then
          from_to_via[:via]
        when /String/ then
          from_to_via[:via].split(',').map(&:strip)
        else
          []
      end
      via_list.insert(0, from_to_via[:from])
      via_list.insert(-1, from_to_via[:to])
      paths = {}
      n     =via_list.size-1
      # n.times { |i| paths[i] = show_possible_paths(via_list[i], via_list[i+1]) }
      n.times { |i| paths[i] = all_paths(via_list[i], via_list[i+1]).first }
      yp paths
    end
  end

  $loud = true
  tic


  # a=NonLinSearch.new('test.yml')
  # a=NonLinSearch.new('nav_paths.yml')
  a=NonLinSearch.new('nav_paths.yml')
  # a=NonLinSearch.new('auto_bak.yml')
  a.run_unit
  # a.take_me({from: "PolicySummaryPage", to: "PniPage"})
  # a.take_me({from: "PniPage", to: "CoveragesPage"})

  # a=NonLinSearch.new(File.dirname(__FILE__))
  # # a.all_paths("a","f")
  # # p a.show_possible_paths
  # # p a.show_possible_paths("a", "f")
  #
  # yp a.all_paths("a", "c")
  # yp a.show_possible_paths("a", "e")
  # yp a.draw_path("a", "e")
  #
  # a.draw_path("a", "g")
  # a.draw_path("g", "e")
  # a.draw_path("e", "f")
  # a.draw_path("a", "f")
  # a.draw_path("m", "o")
  # # a.draw_path("PniPage", "o")
  #
  # # a.draw_path("a", "a") #known issue.. but i'm not looking for this!
  # # a.draw_path("o", "o") #i mean no issue.. coz i'm handling this on step level!!! also, this is stupid!
  #
  # # yp a.all_paths("o", "m")
  # # yp a.show_possible_paths("m", "o")
  # # yp a.show_possible_paths("a", "e")
  #
  # a=NonLinSearch.new('serv.yml')
  # a.draw_path("IAM", "ReviewAndSubmit")
  # a.draw_path("IAM", "Drivers")
  # a.draw_path("IAM", "RemoveDriver")
  #
  # a.draw_path("QuoteStartPage", "QuotePage")
  # # a.draw_path("QuotePage", "QuoteStartPage") # interesting!
  # a.draw_path("QuotePage", "PniPage")
  # a.draw_path("PniPage", "SoftfallPage")

  # ho_east_test
  # $deep = true
  # a=NonLinSearch.new('nav_paths.yml')
  # a.take_me({from: "PniPage", to: "QuotePage"})
  # a.take_me({from: "QuotePage", to: "QuoteStartPage"})
  # a.take_me({from: "QuotePage", to: "PniPage", via: "SoftfallPage"})
  # a.take_me({from: "PniPage", to: "QuotePage", via: "GeneralInformationPage"})
  # a.take_me({from: "PniPage", to: "QuotePage", via: "VerifyInformationPage,PropertyInformationPage"})
  # a.take_me({from: "PniPage", to: "QuotePage", via: %w"VerifyInformationPage PropertyInformationPage"})

  #note to
  # ahmad... THERE IS NO PAGE GOING TO ITSELF HERE PLEASE!!
  # $deep = true
  # auto_test
  # a=NonLinSearch.new('auto.yml')
  #works
  # a.take_me({from: "PNIPage", to: "VerifyInformationPage"})
  # a.take_me({from: "PNIPage", to: "QuoteCoveragesPage"})
  # a.take_me({from: "PNIPage", to: "AdditionalVehicleInformationPage"})
  # a.draw_path("PNIPage", "PaymentPlansPage") #cool!
  # a.draw_path("PNIPage", "PaymentPlansPage") #cool!
  # a.take_me({from: "PNIPage", to: "PaymentPlansPage"}) #cool!
  # needs work :( deep cycles only working!!
  # a.take_me({from: "QuoteCoveragesPage", to: "PaymentConfirmationPage"})
  # a.take_me({from: "PNIPage", to: "PaymentConfirmationPage"})
  # a.take_me({from: "PNIPage", to: "ESignPage"})
  # a.take_me({from: "PNIPage", to: "PolicySummaryPage"})
  # a.draw_path("PNIPage", "PolicySummaryPage") #cool!

  # auto_bak_test
  # a     =NonLinSearch.new('auto_bak.yml')
  # a.take_me({from: "PNIPage", to: "QuoteCoveragesPage"})
  # a.take_me({from: "AddDriverPage", to: "PNIPage"})
  # a.take_me({from: "QuoteCoveragesPage", to: "PNIPage"}) # todo see proper search lines
  # a.take_me({from: "PolicySummaryPage", to: "PNIPage"})

  toc
end
