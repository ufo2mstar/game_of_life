if simulation_mode

  module FakeBrowser
    class Browser
      def initialize *args
        method_missing *args
        @driver = Chrome.new
        # @error_checkers = []
        # @current_frame  = nil
        # @closed         = false
      end

      def method_missing *args
        p "Faking #{args} :P", :br
      end

    end
  end
  # module Watir
  # include FakeBrowser
  # end
  class Chrome
    def method_missing *args
      p "Kod Faking #{args} :D", :gy
    end
  end


  class NilClass
    def method_missing *args
      # pr "Nil Faking #{args} :D" , :gy
    end
  end

end

class BrowserRider
  include Watir
  include PageObject

  include FakeBrowser if simulation_mode
  # attr_accessor :browser

  def initialize(wanna_start = nil)
    p "Bon Voyage Good sir/madam..", :gy if verbose_mode
    @browser = nil
    start if wanna_start
    # @prev_failed = !!0 # instead of start # grrrrr....
  end

  def self.kick_start
    start
    self
  end

  def start type=browser_type
    args          ={}
    @browser_type = browser_type.capitalize
    case type.to_sym
      when /phantomjs/
        args[:args] = %w{--proxy=http://localhost:3128 --ignore-ssl-errors=yes --ssl-protocol=any nwie.js} unless OS == 'windows'
      when /ie/
        system(File.expand_path(File.dirname(__FILE__)) + '/ProtectedFixLinks.bat')
      when /firefox/
        # The Sebas Stuff..
        # profile.proxy = Selenium::WebDriver::Proxy.new :http => 'localhost:3128', :ssl => 'localhost:3128'

        # profile                                           = Selenium::WebDriver::Firefox::Profile.new
        # profile['browser.download.folderList']            = 2 # custom location
        # profile['browser.download.dir']                   = browser_download_directory
        # profile['browser.helperApps.neverAsk.saveToDisk'] = "application/pdf"

        # args[:profile] = profile
        # args[:profile] = profile
      when /chrome/
        #disables the Developer question..
        args[:switches] = %w[--disable-extensions --ignore-certificate-errors --disable-popup-blocking --test-type]
      when /remote/i
        args = {url: 'http://10.5.136.184:4444/wd/hub', desired_capabilities: :firefox}
      else
    end
    p "Creating a '#{@browser_type}' instance ->", :gy #if verbose_mode
    @browser = Browser.new(type.to_sym, args)
    sleep 1 # to deal with some communication issue
    set_feel unless simulation_mode
    #   todo : ad you can pass an actual Driver object into Watir.. think about using it
  end

  def set_feel
     p "  Setting '#{@browser_feel = browser_size.to_sym || 'desktop'}' feel ->", :gy #if verbose_mode
    screen_width    = @browser.execute_script('return screen.width;')
    screen_height   = @browser.execute_script('return screen.height;') - 30
    available_sizes = {
        desktop: [screen_width, screen_height],
        tablet:  [800, screen_height],
        mobile:  [400, screen_height]
    }
    width, height   = available_sizes[@browser_feel]
    @browser.window.resize_to(width, height)
    @browser.window.move_to(0, 0)
    @browser.window.move_to(1000, 0) if ENV['doing'] == 'build'
  end

  def clean
    @browser.cookies.clear if @browser
  end

  def last_failed
    p "Flagging last as failed! ->", :gy #if verbose_mode
    @prev_failed = true
  end

  def nothing
    if @browser
      close =(@browser.windows.size == 1 and !@browser.url.include? 'http')
      p "As Browser had nothing! -> closing instance", :gy if close
      close
    end
  end

  def reuse
    clean
    if @prev_failed or (!use_same_browser and @browser.url.include?('http'))
      start
      @prev_failed = false
    else
      @browser.cookies.clear
      if @browser.url.include? 'http'
        @browser.execute_script 'window.open()'
        @browser.windows.first.close
        @browser.windows.last.use
      end
      p "Using the same '#{@browser_type}' instance ->", :gy if verbose_mode
    end
  end

  def destroy
    p "Closing the '#{@browser_type}' instance ->", :gy #if verbose_mode
    @browser.quit
    @browser.close
    # delete_cache
  end

  # todo.. am moving this to Rakefile..
  def delete_cache
    p "Removing cache from '#{@browser_type}' ->", :gy if verbose_mode
    temp       = ENV['TEMP'].gsub('\\', '/')
    crap_files = Dir.glob(temp+'/*scoped*')+Dir.glob(temp+'/*etil*')
    crap_files.each do |tmp_crap|
      FileUtils.rm_rf(tmp_crap) rescue (p "\n  !!  unable to rm TEMP folder: #{tmp_crap}"; next)
      p " **  removed TEMP folder: #{tmp_crap}" if verbose_mode
    end
  end

  # def exit_hook(&blk)
  #   pid = Process.pid
  #   at_exit do
  #     p pid
  #     p "ooo"
  #     # yield if Process.pid == pid
  #   end
  # end

end
