$LOAD_PATH.unshift '.'
Dir[File.dirname(__FILE__)+"/*/*inspect*.rb"].each { |f| require f }
Dir[File.dirname(__FILE__)+"/*/inp*.rb"].each { |f| require f }
Dir[File.dirname(__FILE__)+"/*/page*.rb"].each { |f| require f }
# Dir[File.dirname(__FILE__)+"/*/group*.rb"].each { |f| p f;require f }
Dir[File.dirname(__FILE__)+"/*/init*.rb"].each { |f| require f }

module Ruler

end

class EvePage
  include PageObject
  include YamlRider # handles my yaml structure
  include Inspector # does all the cool page validations
  include PageFiller # flash fill..
  # include GroupMaker # group maker
  include Initializer # group maker
  include Ruler # todo: implement this thing called RulesEngine that they speak of..

  # include DBRider # todo: use for DB validations


  attr_accessor :page_filled, :error_fields, :error
  cattr_accessor :hsh

  # == Eve Initialize..
  #   - takes the current grand child class path using the {#init_files} method
  #   - calls the {PageObject} initialize method, and returns the @current_page object to +cucumber+
  # @param params [String] takes two arguments
  #   1) PageClass (Class)
  #   2) BrowserDriver (Object)
  # @return [String] the contents reversed lexically
  def initialize *params
    init_files
    p "Loading -> #{@page_name}", :m
    @formatter = ActionView::Base.new # for number formatting and such
    begin
      super params[0], params[1]
    rescue RuntimeError => e
      raise AppLoadingError, "\nHmm.. \nLooks like no page loaded! (on time!)..\n#{e.message}\n"
    rescue Selenium::WebDriver::Error::WebDriverError => e
      raise "\nWow, bro, did you close the Browser! \n\ncoz #{e}\n"
    end
  end

  def eve_store *params
    inps  = params.size
    @@hsh ={} unless defined? @@hsh
    @@hsh ={} unless @@hsh
    if inps == 1
      data_hsh          = params.first
      @@hsh[@page_name] = {} unless @@hsh[@page_name]
      @@hsh[@page_name] = @@hsh[@page_name].merge(data_hsh) if @@hsh[@page_name].is_a? Hash
      # @page_filled      = data_hsh.keys[0] #warn am doin it in inputter
    elsif inps == 2
      element, value    = params
      @@hsh[@page_name] = {} unless @@hsh[@page_name]
      kod               = {"#{element.upcase.gsub(/_ELEMENT/, '')}" => value}
      @@hsh[@page_name] = @@hsh[@page_name].merge(kod)
    end
    $hsh[@page_name]["filldata"] = @@hsh[@page_name]
  end

  # Filling it in ---------------------------------------------------------------------------------------
  def fill_just(element, value, mute=false, i_cant_continue = nil)
    element, value = prod_pni_data(element, value) if in_prod and self.class.to_s =~/PniPage/
    @page_filled   = [] if i_cant_continue # This will Refill the page when you hit go_to.. # todo.. really!?
    begin
      dp({element => value}, "Filled just -", :bl) unless mute
      (eve_store(element, value); $entered_info << ','+"#{element}: #{value}".gsub(',', ' '); return true) if you_want_flash_fill ? enter_element_value_gordon(element, value) : enter_element_value(element, value)
    rescue Exception => e
      @error = [] unless @error
      @error << "fill_just( #{element} , #{value} )\n#{e}\n"
    end
    false # for the fill_with to identify this as unfilled!
  end

  def fill_with(key)
    data_hsh, fill_order = bake_input_hsh key
    filled_hsh           ={}; not_found_hsh={}
    fill_order.each { |itm|
      value = data_hsh[itm]
      if value
        # if you_want_flash_fill ? enter_element_value_gordon(itm, value) : enter_element_value(itm, value)
        if fill_just(itm, value, "mute")
          itm, value      = prod_pni_data(itm, value) if in_prod and self.class.to_s =~/PniPage/
          filled_hsh[itm] = value
        else
          not_found_hsh[itm] = value
        end
        data_hsh.delete(itm)
      end
    }
    warn "\n#{'-' * 80}" if ENV["fill_debug"]
    eve_store(filled_hsh) # todo.. just use fill
    dp filled_hsh, "Filled -", :bl #if verbose_mode
    dp not_found_hsh, "Missin!-", :br unless not_found_hsh.empty? #if verbose_mode
    dp data_hsh, "Not in Fill Order!! -", :m unless data_hsh.empty?
    # for Splunk!
    raise FillTryError, "Fill Errors : Unable to fill -\n#{@error.join "\n"}\n" if @error
    $hsh[@page_name]["fillkeys"] << @page_filled
    # $hsh[@page_name]["fillkeys"] = $hsh[@page_name]["fillkeys"].flatten.uniq
    # $hsh[@page_name]["fillkeys"] = [$hsh[@page_name]["fillkeys"].compact.inject(:merge)] #todo: figure out what the hell is happening here!
  end

  def parse key, data
    raise TypeMismatchError, "#{key} : #{data}\n is not an hash" unless data.is_a? Hash
    data
  end

  # Validation ---------------------------------------------------------------------------------------

  def page_validation_control &blk
    begin
      blk.call
    rescue Exception => e
      @failed = true
      # $hsh["errors"][@page_name]
      p e, :m
      puts e.backtrace
      p "\n was the error!", :r
    end
  end

  def validate_just what = 'all', element = nil, value_key = nil
    # element, value_key = elementify(element), keyize(value_key)
    page_specific_things = @page_specific_things + ['LINK']
    if page_specific_things.include? what
      page_validation_control { check_this(what) }
    else
      raise MissingKeyError, "\n#{what} is not a valid validation item..\n Try #{@page_specific_things}\n"
    end
  end

  def validate_all what = 'all'
    tic 'validation'
    init_exp_stuff
    what = keyize(what)
    case what when /ALL$/i
      @page_specific_things.each { |itm| page_validation_control { check_this(itm) } }
      when /ALL.COVERAGES/i
        check_this("ALL_COVERAGES")
      when /COVERAGES/i
        check_this("COVERAGES")
      else
        validate_just what
    end
    p "validate_all_time #{toc('validation')}", :m
    # raise ValidationError, "\n Validation Errored" unless $hsh['errors'][@page_name].empty? and force_override_validations
    raise ValidationError, "\n Validation Errored\n failed for #{what}\n" if (@failed and !force_override_validations)
  end


  # Navigation ---------------------------------------------------------------------------------------
  # == GoTo page.....
  #   This is the default superclass go_to method..
  #   This is expected to be over-ridden in the child classes
  # @note if jquery is not found on the page it will {#load_jquery} for you! (coz, again.. flash_fill!)
  # @see NavRider
  # @see NavRider#take_me
  # @see NavRider#what_page_am_i_on
  # @param to_page [String] the next page your @current_page should try and go_to
  # @raise [BadInputDataError] that says that the page passed in is not a page the @current_page can go_to..
  def go_to to_page
    fail BadInputDataError, "\n'#{to_page}' is Not a page i ,'#{@page_name}', can go to good sir!\n\n"
  end
  # == Check to see if page is already filled
  #   and either say that it is filled based on whether you have the @page_filled variable has any contents that was filled in..
  # @see #init
  def fill_check
    @page_filled.empty? ? yield : p("page Already filled with #{@page_filled.map { |hsh| hsh.keys[0] } rescue @page_filled}", :br)
  end

  # == Wait for it.....
  #   This is just to make sure that some page, be it the right or wrong page, has loaded up on the browser
  # == Actions
  #   - waits for document.readyState to be "complete"
  #   - once done checks for jQuery.active to be '0' to make sure all the JS had also finished loading (coz, flash_fill)
  # @note if jquery is not found on the page it will {#load_jquery} for you! (coz, again.. flash_fill!)
  # @see #load_jquery
  # @param page [String] just a page name for better output logging.. defaults to "this_page"
  # @raise [AppLoadingError] if no page loaded in 30 seconds or so
  # @return [Nil] Succeeds only once the page has loaded successfully!
  def wait_for_it page="this_page"
    begin
      tic 'wait_for_it'
      pr "AWE..*   wait for it - #{page}..", :gy if verbose_mode
      wait_until { @browser.execute_script("return document.readyState") == "complete" }
      pr hehes, :m if verbose_mode
      wait_until { @browser.execute_script("return jQuery.active == 0") } rescue load_jquery
      pr "so" if verbose_mode
      a = @browser.execute_script('return jQuery.active == 0') ? "yes" : "no!"
      # todo: rescue for load_jquery one day! $().jquery
      p ".. did you load properly? #{a}   *..SOME", :gy if verbose_mode
    rescue Exception => e
      p "CRAP! .. waited #{toc 'wait_for_it'} seconds", :r
      raise AppLoadingError, "#{e}"
    end
  end

  # == try and try, till you.. giveup
  #   just an n-times repeated try-er
  # @param times_to_retry [Integer] number of times you want to retry some action!
  # @param sleep_interval [Integer] waits for so long between successive tries (in seconds)
  # @raise [Nothing] captures any error and just #sleeps on it..!
  # @return just exits the loop after 'times_to_retry' tries
  # == Function Details
  #    Keeps looping until specified amount of time or until the condition is satisfied
  # @note Both the parameters have default value so if nothing is passed to this function then it takes 10 as the no of times to retry and 0.5 as sleep time
  # @param focus_click [Int,Float] No of times to retry, time to sleep

  def keep_trying (times_to_retry = 10, sleep_interval = 0.5)
    count=0
    times_to_retry.to_i.times {
      begin
        count+=1
        yield
        return
      rescue Exception => e
        p "#{count}'th retry  -  sleeping for #{sleep_interval} s =  coz #{squash e}"
        sleep sleep_interval
      end
    }
  end

end
