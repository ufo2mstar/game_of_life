/**
 * Created by sivasn1 on 7/27/2015.
 */

SCENARIOS = "h3[id^='scenario_'],h3[id^=background_]";

$(document).ready(function () {
  $(SCENARIOS).css('cursor', 'pointer');
  $(SCENARIOS).click(function () {
    $(this).siblings().toggle(150);
  });

  $("#toggler").text('Collapse All');
  $("#toggler").css('cursor', 'pointer');
  $("#toggler").click(function () {
    $(SCENARIOS).siblings().toggle();
    $(this).text(function (i, text) {
      return text == 'Expand All' ? 'Collapse All' : 'Expand All'
    });
  });

  $("#fails,#passes").css('cursor', 'pointer');
  $("#fails").click(function () {
    $('div:not(:contains(makeRed))[class="scenario"]').hide()
  });
  $("#passes").click(function () {
    $('div:contains(makeRed)[class="scenario"]').hide()
  });
  $("#showall").click(function () {
    $('div:not(:contains(makeRed))[class="scenario"]').show();
    $('div:contains(makeRed)[class="scenario"]').show()
  });
  // $("#fails").click(function() { $('h3').filter(function() { if($(this).css('background').match(/rgb\(196, 13, 13\)/) == null){$(this).hide()} ;})   });
  // $("#passes").click(function() { $('h3').filter(function() { if($(this).css('background').match(/rgb\(196, 13, 13\)/)){return $(this).hide()} ;})   });
  // $("#showall").click(function() { $('div:not(:contains(makeRed))[class="scenario"]').show() ;$('div:contains(makeRed)[class="scenario"]').show() });

  $("#details").css('cursor', 'pointer');
  $('#details').click(function () {
    $('div[class=kyute]').toggle()
  });
});



function moveProgressBar(percentDone) {
  // $("cucumber-header").css('width', percentDone +"%");
  $("#summary").css('width', percentDone + "%");
}
function makeRed(element_id) {
  $('#' + element_id).css('background', '#C40D0D');
  $('#' + element_id).css('color', '#FFFFFF');
}
function makeYellow(element_id) {
  $('#' + element_id).css('background', '#FAF834');
  $('#' + element_id).css('color', '#000000');
}
