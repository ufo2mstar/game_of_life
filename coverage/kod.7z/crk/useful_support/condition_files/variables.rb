require 'yaml'

module Variables

  def app_loc
    # @@itm ||= Dir[File.dirname(__FILE__)+"/../../pages/**/#{product_line}/app_stuff"].first || raise(" no app loc #{@@itm}")
    @@itm = APP_LOC || raise(" no app loc #{@@itm}")
  end

  def env_state
    @@env_state ||= ENV['state'].upcase
  end
  
  def r_west_state?
    @@env_state =~ r_west_states_rexp
  end

  def r_east_state?
    @@env_state =~ r_east_states_rexp
  end

  def ho_west_state?
    @@env_state =~ ho_west_states_rexp
  end

  def ho_east_state?
    @@env_state =~ ho_east_states_rexp
  end

  def cond_east_state?
    !cond_west_state? #todo: this is good enogh now.. later we might need to change this
  end

  def cond_west_state?
    @@env_state =~ r_east_states_rexp
  end

  def r_east_states_rexp
    /AR|GA|MS|OH|CT|TN|ME|IL|AL|DC|NH|RI|PA|NY|WV|DE|VT|SC|TX|NC|KY|MD|MI|VA/
  end
  def r_west_states_rexp
    /CA|AZ|CO|MN|MO|WA|OR|KS|UT|WI|NE|NV|IA|ID/
  end

  def ho_east_states_rexp
    /TX|TN|PA|NY|VA|AL|CT|GA|IL|MD|OH|KY|MS|NC|SC|WV|DE|AR|DC|ME|NH|RI|VT/
  end
  def ho_west_states_rexp
    /AZ|CA|CO|ID|IA|KS|MN|MO|NE|NV|OR|UT|WA|WI/
  end

  def cond_west_states_rexp
    /AZ|CA|CO|MN|MO|UT|WA|WI|IA|ID|IA|KS|NE|NV|OR/
  end
  def cond_east_states_rexp
    //
  end

  def default_effective_date
    @@eff_date ||= ENV['default_date']
    # todo: use below if using this method in many places and need preformatted date
    # @@eff_date ||= if ENV['default_date']
    #   m, d, y = ENV['default_date'].split('-')
    #   "#{y}-#{m}-#{d}"
    # else
    #   nil
    # end
  end

  # alias_method :env_state, :state
  alias_method :state_abbr, :env_state

  def state_expn
    # @@env_state_expn = STATE_EXPN[state]
    @@env_state_expn = STATE_EXPN[state_abbr]
  end

  def splunk_url
    @@splunk_url ||= YAML.load_file(app_loc + "/urls.yml")['SPLUNK']
  end

  def env_url
    @@env_url ||= YAML.load_file(app_loc + "/urls.yml")[app_env]
  end

  def prod_url
    @@prod_url ||= "https://propertysales.nationwide.com/propertyquote/quoteStart"
  end

  def app_env
    @@app_env ||= ENV['app_env'].upcase # dev,it,st,pt,prod
  end

  def dna_env_url
    if app_env =~ /pt/i
      "https://nwinsurancept.nationwide.com/rentersquote/secure/OnlineQuoteWINDNA.asp?state=#{env_state}&type=renters"
    elsif app_env =~ /st/i
      # "https://nwinternetst-temp.nwideweb.net/RentersQuote/secure/OnlineQuoteWINDNA.asp?state=#{env_state}&type=renters"
      "https://nwinternetst.nwie.net/RentersQuote/secure/OnlineQuoteWINDNA.asp?state=#{env_state}&type=renters"
      # "https://nisecure.nationwide.com/rentersquote/secure/OnlineQuoteWINDNA.asp?state=#{env_state}&type=renters"#PROD URL
    elsif app_env =~ /dev/i
      "https://ntac1wwbk3614.nwielab.net:444/RentersQuote/Secure/OnlineQuoteWINDNA.asp?state=#{env_state}&type=renters"
    else
      #"https://nwinternet#{app_env}.nwideweb.net/rentersquote/secure/OnlineQuoteWINDNA.asp?state=#{env_state}&type=renters"
      # below is for iNet refresh!
      "https://nwinternet#{app_env}.nwie.net/rentersquote/secure/OnlineQuoteWINDNA.asp?state=#{env_state}&type=renters"
    end
  end

  def browser_type
    @@browser_type ||= ENV['browser'].downcase || "firefox"
  end

  def browser_size
    @@browser_size ||= case (ENV['browser_size'] || ENV['view'])
      when /mobile/i then
        "mobile"
      when /tablet/i then
        "tablet"
      else
        "desktop"
    end
  end

  def force_close_fails
    @@force_brow ||= ENV['force_close_fails'] =~ /Y/i
  end

  def use_same_browser
    @@same_brow ||= ENV['same_browser'] =~ /Y/i
  end

  def force_override_validations
    @@press_on ||= ENV['force'] =~ /Y/i
  end

  def profiling_mode
    @@prof ||= ENV['profiling'] =~ /Y/i
  end

  def simulation_mode
    @@sim ||= ENV['simulation'] =~ /Y/i
  end

  def mute_mode
    @@mute ||= ENV['silent'] =~ /Y/i
  end

  def verbose_mode
    @@verbose ||= ENV['verbose'] =~ /Y/i
    @@prof    = true if @@verbose
    @@verbose
  end

  def wanna_connect_to_db
    @@db_conn ||= ENV['wanna_check_db'] =~ /Y/i
  end

  def wanna_run_bucket_list
    @@bucket ||= ENV['run_bucket_list'] =~ /Y/i
  end

  def store_all_fill_info
    @@qds ||= ENV['store_quote_details'] =~ /Y/i
  end

  def screenshots_on
    @@screenshot ||= ENV['screenshots'] =~ /Y/i
  end

  def close_browser_when_finished
    @@close_browser ||= ENV['close_browser'] =~ /Y/i
  end

  # def dont_close_browser_when_failed
  def dont_close_fails
    @@dont_close_fails ||= ENV['dont_close_fails'] =~ /Y/i
  end

  def prod_check
    # todo: rename this stupid thing better
    raise ProdRunError, "\nWoaH Brah!..\n   not in prod!!\n   ... Woahh!!!
3 keys to unlock the 'Run in Prod' ability:

1 - app_env: prod
2 - run_in_prod: Y
3 - use the Step: \"Given the tester runs prod night validation\" in your Background!\n"
  end

  def in_prod
    prod_check if !!(app_env =~ /prod/i) ^ run_in_production
    @@in_prod ||= (app_env =~ /prod/i and run_in_production)
  end

  def not_in_prod
    !in_prod
  end

  def run_in_production
    @@run_in_prod ||= ENV["run_in_prod"] =~ /Y/i
  end

  def lob
    @@lob ||= ENV["lob"].downcase
  end

  alias_method :product_line, :lob

  def you_want_flash_fill
    @@flash_ah_oh ||= ENV["flash_fill"] =~ /true|on|y/i
  end

  # todo: really need all these variables?
  def you_wanna_stub_rating
    @@stub_rating ||=ENV["stub_rating"] =~ /true|on|y/i
  end

  def you_wanna_reset_cache
    @@reset_cache ||=ENV["reset_cache"] =~ /true|on|y/i
  end

  def you_wanna_log_to_splunk
    @@splunk_it ||=ENV["splunk_it"] =~ /true|on|y/i
  end

  def you_wanna_fill_your_email_id
    @@your_email ||= (ENV["fill_your_email"][/(.*@.*\..*)$/, 1] unless run_in_production) if ENV["fill_your_email"] || nil
  end

  def payment_option_override
    @@payment_option ||= ENV["payment_option"]
  end


  def load_jquery
    #tic
    p "\nloading jquery 1.11.1!\n", :br
    @browser.execute_script("jscript = document.createElement('script');jscript.src = \"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\";document.getElementsByTagName(\"body\")[0].appendChild(jscript);")
    # Watir.wait_until(10) { (@browser.execute_script("return $().jquery;");break;) rescue (pr '.';sleep 1) }
    10.times { (@browser.execute_script("return $().jquery;");break;) rescue (pr '.';sleep 1) }
    # p toc
  end

  # def nav_profilin
  #   @@nav_prof ||= ENV["navigation_profiling"] == "Y"
  # end

  def hehes
    @@hehe||=['hmmm', 'interesting', 'blimey', 'I see', 'whaat!', 'wait a minute', 'dont say!', 'how \'bout dat!', 'hang on', 'hold on', 'wow', 'cool', 'er', 'umm', 'oh shi', 'OhMyGawd', 'Holy!', 'well then']
    @@hehe.sample+".."
  end

  def get_in_the_game
    @@housewords ||= ['Winter is Coming', 'Ours is the Fury', 'We Do Not Sow', 'Unbowed, Unbent, Unbroken', 'Family, Duty, Honor', 'Here We Stand', 'Fire and Blood', 'Hear Me Roar!', 'Growing Strong', 'Honed and Ready', 'We Remember', 'Proud to be Faithful', 'Above the Rest', 'The Sun of Winter', 'Iron from Ice']
    @@housewords.sample
  end

  def try_and_try timeout = 3 # till you succeed!
    tic('timeout')
    end_time = toc('timeout')+timeout
    while toc('timeout')<end_time do
      begin
        yield
        return
      rescue Exception => e
        p "try_and_try - #{e}"
      end
    end
    p "\nOk.. somethin's up with #{caller}..\nTiming out Safely!", :r
  end
end

include Variables
World Variables