if __FILE__ == $0
# sassIT!
  print "running `sass kyuke.sass kyuke.css`"
  `sass kyuke.sass kyuke.css`

end