module StepMethods
  # alias_method :match_data, :find_txt
  def get_validation_data type, raw_data
    find_txt(type, [keyize(raw_data)]).first.values.first
  end

  def get_discounts_data validation_key,raw = nil
    key       = parse_to_a(erb_eval(@state_exp_file, binding)["DISCOUNTS"][keyize validation_key], ";")
    # if specific key is not there in state_exp.. the below supports inputs like 'cf' and such..
    key       = [keyize(validation_key)] if key.empty?
    disc_list = []
    find_txt("TEXTS", key).each { |a| disc_list << a.values unless a.values.first.strip.empty?}
    disc_list.flatten.compact
  end

  def get_link_data validation_key
    links_list = erb_eval(@state_exp_file, binding)["LINKS"]
    key        = keyize validation_key
    links_list.each { |each_link|
      link_key = each_link.is_a?(Hash) ? each_link.keys.first.keyize : each_link.keyize
      return [link_key, each_link.values.first] if key == link_key # should we return a hash carefully?
      raise BadInputDataError, "key doesnt match link key. Key: #{key} ; link_key: #{link_key}"
    }
  end

  def validate_discounts validation_key,presence_check
    validation_list = get_discounts_data(validation_key)
    (p "No discounts applicable..\n skipping discount validations",:y;return) if validation_list.empty?
    discounts_validate validation_list,presence_check
  end

  def validate_specific_text validation_key, specific_element, validation_type = true, silent = nil
    tic
    validation_value = validation_key.is_a?(Hash) ? validation_key.values[0] : get_validation_data("TEXTS", validation_key)
    @page_text       = send(specific_element)
    text_validate({keyize(validation_key) => validation_value}, validation_type)
    p "took to validate_specific_text = #{toc}s" if profiling_mode
    element_validate specific_element, @errored_fields_list.empty? ? 'lightgreen' : 'red', validation_type unless silent
    @error_sum << {"Text_Errors".to_sym => "#{validation_value} supposed to be #{validation_type ? 'DISPLAYED but WASN\'t' : 'NOT DISPLAYED but WAS'}: \n #{@errored_fields_list.join("\n")}\n"} unless @errored_fields_list.empty?
    verdict 'Texts', true
  end

  def validate_link validation_key, specific_element = nil, validation_type=true
    tic
    specific_element, validation_items = get_link_data validation_key
    validation_items = get_validation_data("LINKS", validation_items)
    check_link({specific_element.elementify => validation_items})
    p "took to validate_link = #{toc}s" if profiling_mode
    @error_sum << {"Link_Errors".to_sym => "supposed to be #{validation_type ? 'Proper but WASN\'t' : 'NOT DISPLAYED but WAS'}: \n #{@errored_fields_list.join("\n")}\n"} unless @errored_fields_list.empty?
    verdict 'Links', true
  end

  def validate_text validation_key, validation_type=true
    tic
    validation_value = validation_key.is_a?(Hash) ? validation_key.values[0] : get_validation_data("TEXTS", validation_key)
    # check_texts([{keyize(validation_key) => validation_value}], validation_type)
    get_page_text true
    text_validate({keyize(validation_key) => validation_value}, validation_type)
    p "took to validate_text = #{toc}s" if profiling_mode
    @error_sum << {"Text_Errors".to_sym => "#{validation_value} supposed to be #{validation_type ? 'DISPLAYED but WASN\'t' : 'NOT DISPLAYED but WAS'}: \n #{@errored_fields_list.join("\n")}\n"} unless @errored_fields_list.empty?
    verdict 'Texts', true
  end

  def validate_help_text validation_key, validation_type=true
    tic
    key              = validation_key.is_a?(Hash) ? keyize(validation_key.keys[0]) : keyize(validation_key)
    validation_value = validation_key.is_a?(Hash) ? get_validation_data("HELPS",validation_key.values[0]) :
                                                    get_validation_data("HELPS", keyize(validation_key))
    get_page_text true
    check_help_texts([{key => validation_value}], true)
    p "took to validate_help_text = #{toc}s" if profiling_mode
    @error_sum << {"Text_Errors".to_sym => "#{validation_key} supposed to be #{validation_type ? 'DISPLAYED but WASN\'t' : 'NOT DISPLAYED but WAS'}: \n #{@errored_fields_list.join("\n")}\n"} unless @errored_fields_list.empty?
    verdict 'HelpTexts', true
  end

  # validate_list_default 'key' means 'KEY_20K' or 'text' means "20,000"
  def validate_list_default element, default_value
    tic
    validation_value = default_value.is_a?(Hash) ? default_value : get_validation_data("TEXTS", default_value)
    select_list_default_validate({element => validation_value})
    p "took to validate_default = #{toc}s" if profiling_mode
    @error_sum << {"LIST_DEF_Errors".to_sym => "These Lists that are missing or incorrectly displayed: \n #{@errored_fields_list.join("\n")}\n"} unless @errored_fields_list.empty?
    verdict 'LISTS', true
  end

  def validate_list element, validation_key, silent = nil
    tic
    validation_value = get_validation_data("LISTS", validation_key)
    select_list_validate({element => validation_value},silent)
    p "took to validate_list = #{toc}s" if profiling_mode
    @error_sum << {"LIST_Errors".to_sym => "These Lists that are missing or incorrectly displayed: \n #{@errored_fields_list.join("\n")}\n"} unless @errored_fields_list.empty?
    verdict 'LISTS', true
  end

  # def validate_coverage element, validation_key
  def validate_coverage cvgs_itm
    tic
    close_discount_modal
    init_exp_stuff
    cvgs_itm = keyize cvgs_itm
    cvg      = []
    @exp_coverages.each { |itm| cvg<<itm if itm.keys.first == cvgs_itm }
    raise BadInputDataError, "\ncvgs_hsh_list is empty!\ndoes #{@state_exp_file} contain \nCOVERAGES:\n  #{cvgs_itm}\n?\n" if cvg.empty?
    check_coverages cvg
    p "took to validate_coverages = #{toc}s" if profiling_mode
    @error_sum << {"COVERAGES_Errors".to_sym => "These Lists that are missing or incorrectly displayed: \n #{@errored_fields_list.join("\n")}\n"} unless @errored_fields_list.empty?
    verdict 'COVERAGES', true
  end

  def validate_element element_name, validation_type=true
    tic
    element = elementify(element_name)
    # if defined? send(element)
    if self.methods.include? element.to_sym
      element_validate(element, validation_type ? 'LawnGreen' : 'OrangeRed', validation_type)
      p "took to validate_element = #{toc}s" if profiling_mode
      @error_sum << {"Element_Errors".to_sym => "supposed to be #{validation_type ? 'DISPLAYED but WASN\'t' : 'NOT DISPLAYED but WAS'}: \n #{@errored_fields_list.join("\n")}\n"} unless @errored_fields_list.empty?
    else
      @error_sum << {"Element_Errors".to_sym => "'#{element}' not even Defined for this page!!\nif you wanna negative validate it.. just define the actual element\n"}
    end
    verdict 'Element', true
  end
end