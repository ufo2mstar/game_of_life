# require 'yaml'
if __FILE__ == $0
require_relative '../../../useful_support/formatting_files/cosmetics'
  require_relative 'non_lin_algo'


  class NonLinSearch
    def run_unit
      # Get list of all Pages!
      kk = @nav_doc.keys+@nav_doc.values
      kk2=kk.flatten.uniq
      # warn all_comb = kk2.combination(2).to_a
      warn all_comb = kk2.permutation(2).to_a
      print "\n#{all_comb.size} paths detected - lets run them -\n\n"
      print "Directory - \n"
      error_list = []
      good_list  = []
      all_comb.each_with_index do |path, i|
        from       = path.first
        to         = path.last
        # paths_list = show_possible_paths(from, to)
        paths_list = shortest(from, to) || []
        if paths_list.empty?
          error_list << "#{i}: #{from} -> #{to}"
        else
          # print "#{i}: #{from} -> #{to}\n"
          # good_list << "#{i}: #{from} ->> #{to}\t#{paths_list.join '-'}"
          good_list << {"#{i}: #{from}-#{to}" => "#{paths_list.join ' - '}"}
          # draw_path(from, to)
        end

      end
      puts good_list
      # yp good_list
      print "\none sec..\n"
      print "\n#{'-'*80}\n#{error_list.size} No Paths in theses directions :"
      yp error_list
    end

    def dot_notation
      key = @nav_doc.keys
      print "digraph kod {\n"
      @nav_doc.each{|k,v|
      v.each{|kk| print "  #{k} -> #{kk};\n"} if v
      }
      print "}\n"
    end

  end

  # $loud = true
  # $deep = true
  tic


  # a=NonLinSearch.new('test.yml')
  a=NonLinSearch.new('nav_paths.yml')
  # a.run_unit
  a.dot_notation
  # a.shortest 'QuotePage', 'QuoteStartPage'
  # a.shortest 'QuoteStartPage', 'QuotePage'

  # a=NonLinSearch.new('auto_bak.yml')
  # a=NonLinSearch.new('auto.yml')
  # a=NonLinSearch.new('routes.yml')
  # a=NonLinSearch.new('nav_paths.yml')
  # a.dot_notation
  # a.shortest "PNIPage", "PolicySummaryPage"
  # a.shortest "PaymentPlansPage", "PNIPage"
  #
  # # issue
  # a.shortest "PolicySummaryPage", "PNIPage"
  p toc
end


=begin
# digraph kod {
#   QuoteStartPage -> PniPage;
#   QuoteStartPage -> HardFallPage;
#   PniPage -> PropertyInformationPage;
#   PropertyInformationPage -> GeneralInformationPage;
#   PropertyInformationPage -> SoftfallPage;
#   GeneralInformationPage -> VerifyInformationPage;
#   GeneralInformationPage -> CoveragesPage;
#   VerifyInformationPage -> CoveragesPage;
#   CoveragesPage -> YourPolicyDetailsPage;
#   YourPolicyDetailsPage -> PropertyDetailsPage;
#   PropertyDetailsPage -> EVTPage;
#   PropertyDetailsPage -> PaymentPlansPage;
#   EVTPage -> PaymentPlansPage;
#   PaymentPlansPage -> PaymentInformationPage;
#   PaymentInformationPage -> PaymentConfirmationPage;
#   PaymentConfirmationPage -> EsignPage;
#   EsignPage -> DocusignPage;
#   EsignPage -> PolicySummaryPage;
#   DocusignPage -> PolicySummaryPage;
# }

digraph kod {
  QuoteStartPage -> PniPage;
  PniPage -> PropertyInformationPage;
  PropertyInformationPage -> GeneralInformationPage;
  PropertyInformationPage -> PniPage;
  GeneralInformationPage -> VerifyInformationPage;
  GeneralInformationPage -> CoveragesPage;
  GeneralInformationPage -> PropertyInformationPage;
  VerifyInformationPage -> CoveragesPage;
  VerifyInformationPage -> GeneralInformationPage;
  CoveragesPage -> YourPolicyDetailsPage;
  CoveragesPage -> GeneralInformationPage;
  YourPolicyDetailsPage -> PropertyDetailsPage;
  YourPolicyDetailsPage -> CoveragesPage;
  PropertyDetailsPage -> EVTPage;
  PropertyDetailsPage -> PaymentPlansPage;
  PropertyDetailsPage -> YourPolicyDetailsPage;
  EVTPage -> PaymentPlansPage;
  EVTPage -> PropertyDetailsPage;
  PaymentPlansPage -> PaymentInformationPage;
  PaymentPlansPage -> PropertyDetailsPage;
  PaymentInformationPage -> PaymentConfirmationPage;
  PaymentInformationPage -> PaymentPlansPage;
  PaymentConfirmationPage -> EsignPage;
  EsignPage -> DocusignPage;
  EsignPage -> PolicySummaryPage;
  DocusignPage -> PolicySummaryPage;
}
=end