# require 'yaml'
# require 'awesome_print'
#
# class Hash
#   def method_missing(m)
#     return self[m] || self[m.to_sym]
#     super
#   end
# end
#
# #
# # list  ={"a" => ["b", "c", 'z'], 'b' => ['d', 'e'], 'c' => ['f'], 'z' => [], 'e' => ['g']}
# # # list['d'] = ['c'] # level 2
# # $list = list
# # # ap list
# #
# # def go_one_level_deep(next_list)
# #   lis  =[]
# #   list = $list
# #   next_list.each { |item|
# #     list[item] && !list[item].empty? ? lis << list[item] : puts("hmm, #{item} is an end!\n") }
# #   lis
# # end
# #
# # def more_left?
# #   @i=0
# #   @i+=1
# #   return false if @i > 1
# # end
# #
# # # ans={}
# # # go_deep = 1; i=0;
# # # from= ['a']
# # # current_list = done_list = [from]
# # # next_list[0] = {from => list[from]} # array input skips this step
# # # loop do
# # #   puts "loop #{i}:\n"
# # #   print "next_list = #{next_list}\n"
# # #   aa={}
# # #   # aa = current_list.map{|c| next_list.map{|n| [c,n]}}
# # #   current_list.each{|c| next_list.each{|n| aa[n]=[c,n]}}
# # #   ans["#{i}"] = aa
# # #   done_list = (done_list+aa.keys.map(&:to_s)).flatten
# # #   next_list = go_one_level_deep(next_list)
# # #   more_left? ? i+=1 : break
# # #   # dest_reached?
# # # end #while go_deep
# # # # p graph
# # # # ap a
# # # p ans
# # # p done_list
# # # ----------------------------------------------------------------------------
# # def get_next_level_list(item)
# #   nxt_list  =[]
# #   list = $list
# #   if list[item] && !list[item].empty?
# #     puts("#{item} is good")
# #     nxt_list= list[item]
# #   else
# #     puts("hmm, #{item} is an end!\n")
# #   end
# #   nxt_list
# # end
# #
# # def build_path_from(hsh, prev_list)
# #   paths = []
# #   prev_list.each { |path|
# #     if hsh[path.last]
# #       hsh[path.last].each { |nxt| paths << [path, nxt].flatten }
# #     else
# #       paths << path
# #     end
# #
# #   }
# #   paths
# # end
# #
# # def val_debug(str,val)
# #   puts " #{str} -> #{val}"
# # end
# #
# # i              = 0
# # from           = ['a']
# # master_hash    = {}
# # master_hash[0] = [from]
# # loop do
# #   i+=1; interim={}
# #   from.each { |itm| interim[itm]= get_next_level_list itm }
# #   interim.delete_if { |k, v| v.empty? }
# #   # val_debug "interim",interim
# #   master_hash[i] = build_path_from(interim, master_hash[i-1])
# #   # val_debug "master_hash",master_hash
# #   from = interim.values.uniq[0]
# #   # val_debug "from",from
# #   break if i==3
# # end
# # p master_hash
# # ap master_hash[i]
# # ----------------------------------------------------------------------------
#
#
# class SearchAlgo
#   def initialize(file='serv.yml')
#     @file = file
#     @doc  =YAML.load_file(@file)
#     raise "empty hash in #{@file.inspect}" if @doc.empty?
#     @doc.update(@doc) { |k, v| parse_to_a v if v }
#   end
#
#   def show(doc=@doc)
#     doc.each { |k, v| print "#{k} => #{v}\n" }; print "\n"
#   end
#
#   def parse_to_a(ary)
#     ary.split(',').map(&:strip)
#   end
#
#   def val_debug(str, val)
#     puts " #{str} -> #{val}"
#   end
#
#   def get_next_level_list(item)
#     nxt_list =[]
#     list     = @doc
#     if list[item] && !list[item].empty?
#       # puts("#{item} is good")
#       nxt_list= list[item]
#     else
#       # puts("hmm, #{item} is an end!\n")
#     end
#     nxt_list
#   end
#
#   def build_path_from(hsh, prev_list)
#     paths = []
#     prev_list.each { |path|
#       if hsh[path.last]
#         hsh[path.last].each { |nxt|
#           if @done_list.include?(nxt)
#             # puts("repeating #{path.last}")
#           else
#             paths << [path, nxt].flatten
#           end }
#       else
#         paths << path
#       end
#     }
#     paths
#   end
#
#   def all_paths(from="IAM", to="sdf")
#     (warn "No #{from} found in #{@file.inspect}'s Hash'"; return) unless @doc[from]
#     i              = 0
#     @done_list     = []
#     master_hash    = {}
#     from           = [from]
#     master_hash[0] = [from]
#     loop do
#       i+=1; interim={}
#       @done_list = @done_list.flatten.uniq
#       from.each { |itm| interim[itm]= get_next_level_list itm }
#       interim.delete_if { |_, v| v.empty? }
#       # val_debug "interim",interim
#       master_hash[i] = build_path_from(interim, master_hash[i-1])
#       # val_debug "master_hash",master_hash
#       from           = interim.values.uniq[0]
#       @done_list << from
#       # val_debug "from",from
#       break if i==4
#     end
#     master_hash[i]
#   end
#
#   def show_possible_paths(from="IAM", to="sdf")
#     all_path_list = all_paths(from,to)
#     potential_route = []
#     all_path_list.each { |path|
#       potential_route << path if path.include?(from) and path.include?(to)
#     }
#     warn("Man! no possible routes found!\n #{from} to #{to}\n") if potential_route.empty?
#     potential_route
#   end
#   # def path(from="IAM", to="sdf")
#   #   graph = []
#   #   (warn "No #{from} found in #{@file.inspect}'s Hash'"; return) unless @doc[from]
#   #   go_deep = 1; i=0;
#   #   next_list = parse_to_a @doc[from] # array input skips this step
#   #   begin
#   #     puts "loop #{i}:\n"
#   #     print "next_list = #{next_list}\n"
#   #     graph = go_one_level_deep(next_list)
#   #     more_left? ? i+=1 : go_deep=!1
#   #     # dest_reached?
#   #   end while go_deep
#   #   p graph
#   # end
# end
#
# a=SearchAlgo.new
# # a.show
# # a.path
# # ap a.all_paths
# p a.all_paths
# p a.show_possible_paths
# ap a.show_possible_paths("IAM", "Drivers")
#
