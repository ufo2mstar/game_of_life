module Assembler
  private

  # Finds and Matched the values for the given Keys!
  def find_txt type, raw_data_ary
    return [] if raw_data_ary.nil? or raw_data_ary.empty?
    raw_txt_list  = raw_data_ary
    specific_file = @base_exp_files.select { |a| a =~ /#{type}/i }
    raise MissingFileError, "\nUnable to match /#{type}/ in\n#{@base_exp_files.join("\n")}\nfor #{@page_name}\n" if specific_file.empty?
    assemble_data =-> files { res={}; files.reverse.each { |file| res=res.merge(erb_eval(file)) }; res } # todo worry about file precedence.. when you get to it
    file_data     = @base_cache[type] || (@base_cache[type] = assemble_data[specific_file]) # cool.. caching!
    txt_hsh_list  =[]; unfound = []
    # if raw_data_ary!=nil
      raw_txt_list.each { |itm|
        key, val = itm.class == Hash ? [itm.keys[0], itm.values[0]] : [itm, itm]
        next if val.strip.empty?
        data = file_data[val]
        data.nil? ? unfound << val : txt_hsh_list << {key => data}
      }
    # end
    raise MissingDataError, "\nNo #{type} data detected for -\n #{unfound}\n in #{specific_file} \n #{"found :\n #{txt_hsh_list.to_yaml}\n" unless txt_hsh_list.empty?}" unless unfound.empty?
    txt_hsh_list
  end

  # flush_out - for each array in the list %w{a b !c !a !x x} gives ['b']
  def flush_out hsh
    clean_hsh = {}
    hsh.each { |k, list|
      if list.class == Array
        list.flatten!
        keys_to_delete = []; other_keys = []
        list.each { |x| x =~/^!(.*)/ ? keys_to_delete << $1 : other_keys << x }
        clean_hsh[k] = (other_keys - keys_to_delete).compact
      end
    }
    clean_hsh
  end

  def init_exp_stuff
    tic 'init_exp_stuff'
    fail "define @state_exp_file please" unless @state_exp_file
    state_data            = flush_out(erb_eval(@state_exp_file, binding))
    keys                  = state_data.keys
    @page_specific_things = keys-['LINKS'] # coz we don't wanna validate links when trying to validate all in the page!

    @exp_elements  = state_data['ELEMENTS']
    @exp_coverages = state_data['COVERAGES']
    @exp_discounts = state_data["DISCOUNTS"]["APPLICABLE_DISCOUNTS"] if state_data["DISCOUNTS"]

    # types                 = %W{LABELS TEXTS LISTS DISCOUNTS COVERAGES INFOCENTER}
    # types = keys
    types          = %W{LABELS TEXTS LISTS HELP LINKS}
    types.each { |itm|
      (p("@exp_#{itm.downcase} = find_txt(#{itm.inspect}, state_data['#{itm}'])") if keys.include? itm) if verbose_mode
      eval("@exp_#{itm.downcase} = find_txt(#{itm.inspect}, state_data['#{itm}'])") if keys.include? itm }
    p "init_exp_stuff = #{toc 'init_exp_stuff'}" if profiling_mode

    nil
  end

  def init_exp_coverages

  end

  #todo : can make both check_elements,check_text into one method if nothing else is gonna change

  def get_page_text newly=nil
    tic 'page_text'
    if @page_text.nil? or newly
      @page_text = @browser.text
      if @page_name =~ /property/i and nil # hmm.. do we need this?
        # for carosel
        @page_text += @browser.execute_script("return $('#UI12043_carousel').text()") # struct material
        @page_text += @browser.execute_script("return $('#UI12046_carousel').text()") # roof type
      end
      @page_text = @page_text.squash # with reluctance i had to cave in to this.. coz ease of some validations
      if @page_name =~ /general/i
        # to_remove  = @browser.execute_script("return $('#groupsList').text()") # all of rtmi
        to_remove  = @browser.execute_script("return $('#groupsList ul li').map(function(){return ($(this).text())})").join ' ' # all of rtmi
        # ids
        # staticHeader
        # affinityRTMIContainer
        # affinityUserSearchGroup
        # affinityOrganization
        @page_text = @page_text.gsub(to_remove.squash, '|RTMI-LIST|') unless to_remove.to_s == ""
      end
      to_remove = @browser.execute_script("return $('select').map(function(){return $(this).text()+' '+$(this).next().text()})") # removing select list texts to make neglected text output clear!
      to_remove.each { |rem_txt| rem_txt = rem_txt.join unless rem_txt.is_a?(String); @page_text=@page_text.gsub(rem_txt.squish, '|') } #yup squish.. thats a thing! :)
      @page_text = @page_text.squash # with reluctance i had to cave in to this.. coz ease of some validations
      toc 'page_text', 'for gettin page_text'
    end
  end

end