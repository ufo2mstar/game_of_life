module Initializer

  def self.init_hsh
    @page_name = "Scenario"
    hsh_init
  end

  def hsh_init
    # todo.. should we pretend singleton or just go with this?
    $hsh                        = {} unless $hsh
    $hsh[@page_name]            = {} unless $hsh[@page_name]
    $hsh["errors"]              = {} unless $hsh["errors"]
    $hsh["errors"][@page_name]  = [] unless $hsh["errors"][@page_name]
    $hsh[@page_name]["filldata"]= {} unless $hsh[@page_name]["filldata"]
    $hsh[@page_name]["fillkeys"]= [] unless $hsh[@page_name]["fillkeys"]
    $hsh['ebi_log_keys']        = {} unless $hsh['ebi_log_keys']
  end


  def init_files
    child_file_location  = @child_file_location
    parent_file_location = @parent_file_location
    @page_filled         = []
    @bucket_list         = [] # for e2e bucket
    @error_sum           = []
    @errored_fields_list = []
    @base_cache          = {}
    @page_name           = self.class.to_s
    state_case_filter =-> file_ary {file_ary.map{|x| x if x.include?(env_state)}.compact}

    if child_file_location
      @base_inp_files       = Dir[child_file_location+"/_inp/base_inp*/*.yml"]
      # this optionally can be used to add keys implicitely to the fill keys list
      @base_state_inp_files = state_case_filter.call Dir[child_file_location+"/_inp/base_inp*/*/*#{env_state}*.yml"]

      @base_exp_files       = Dir[child_file_location+"/_exp/base_exp*/*.yml"]+Dir[parent_file_location+"/_exp/base_exp*/*.yml"] # for common base stuff
      @base_state_exp_files = state_case_filter.call Dir[child_file_location+"/_exp/base_exp*/*/*#{env_state}*.yml"]

      @state_inp_file       = Dir[child_file_location+"/_inp/*#{env_state}*.yml"].first #|| Dir[child_file_location+"/_inp/*_common.yml"].first
      @common_inp_file      = Dir[child_file_location+"/_inp/*#{lob}*.yml"].first || Dir[child_file_location+"/_inp/*_common*.yml"].first
      @state_exp_file       = Dir[child_file_location+"/_exp/exp_*#{env_state}*.yml"].first ||
          Dir[child_file_location+"/_exp/*#{lob}.yml"].first ||
          Dir[child_file_location+"/_exp/*_common_#{r_west_state?? 'west':'east'}.yml"].first ||
          Dir[child_file_location+"/_exp/*_common*.yml"].first #need to make exp_common a thing!

      @inp_happy_path_bucket= Dir[child_file_location+"/_inp/bucket/*happy*.yml"].first
      @inp_hardfall_bucket  = Dir[child_file_location+"/_inp/bucket/*hard*.yml"].first
      @inp_softfall_bucket  = Dir[child_file_location+"/_inp/bucket/*soft*.yml"].first

      @bulk_validating = nil # enable this for printing one stupid 'no errors' line in the inspector
      @fillorder_file  = Dir[child_file_location+"/*.yml"].first
      raise MissingFileError, "Please Create your state_inp_file\n'#{child_file_location}/_inp/*#{env_state}*.yml' or \n'#{child_file_location}/_inp/_common*.yml'\n" if Dir[child_file_location+"/_inp"].first and !@common_inp_file and !@state_inp_file
      # raise MissingFileError, "Please Create your common_inp_file\n'#{child_file_location}/_inp/_common.yml'\n" if  Dir[child_file_location+"/_inp"].first and !@common_inp_file and !@state_inp_file
      raise MissingFileError, "Please Create your state_exp_file\n'#{child_file_location}/_exp/*#{env_state}*.yml' or \n'#{child_file_location}/_exp/exp_common*.yml'\n" if Dir[child_file_location+"/_exp"].first and !@state_exp_file
    else
      raise MissingDataError, "\nPlease Define :

  def init_files
    @child_file_location = File.dirname(__FILE__)
    super
  end

 in your #{@page_name}\n"
    end
    hsh_init
  end
end