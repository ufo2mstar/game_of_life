module PageObject
  module Platforms
    module WatirWebDriver
      #
      # Watir implementation of the page object platform driver.  You should not use the
      # class directly.  Instead you should include the PageObject module in your page object
      # and use the methods dynamically added from the PageObject::Accessors module.
      #
      class PageObject

        #
        # platform method to return the text for a label
        # See PageObject::Accessors#label
        #
        def legend_text_for(identifier)
          process_watir_call("legend(identifier).text", Elements::Legend, identifier, nil, 'legend')
        end

        #
        # platform method to return a PageObject::Elements::Label element
        # See PageObject::Accessors#label
        #
        def legend_for(identifier)
          find_watir_element("legend(identifier)", Elements::Legend, identifier, 'legend')
          end

        #
        # platform method to return the text for a input
        # See PageObject::Accessors#input
        #
        def input_text_for(identifier)
          process_watir_call("input(identifier).text", Elements::Input, identifier, nil, 'input')
        end

        #
        # platform method to return a PageObject::Elements::Input element
        # See PageObject::Accessors#Input
        #
        def input_for(identifier)
          find_watir_element("input(identifier)", Elements::Input, identifier, 'input')
        end

      end
    end
  end
end
