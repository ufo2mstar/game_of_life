# IPEX element Groups
module PageObject
  module Accessors
    # Help Group -------------------------------------=
    def ipex_help_group name, uid
      name = name.downcase
      link("#{name}_help_link".to_sym, :id => "help_#{uid}")
      span("#{name}_help".to_sym, :id => "help_button_#{uid}")
      div("#{name}_help_div".to_sym, :id => "helpTextDiv_#{uid}")
    end

     def ipex_link_group name, *args
      name = name.downcase
      link("#{name}_help_link".to_sym, :id => "#{args[0]}")
      # span("#{name}_help".to_sym, :id => "#{args}")
      div("#{name}_help_div".to_sym, :id => "#{args[1]}")
    end


    # Coverages Groups -------------------------------------=
    def ipex_coverages_static_group name, uid
      name = name.downcase
      ipex_help_group name, uid
      # label("#{name}_coverage_label".to_sym, :for => "#{uid}")
      label("#{name}_coverage_value".to_sym, :xpath => "//label[@for='#{uid}']")
      div("#{name}_coverage_name".to_sym, :xpath => "//div[@for='#{uid}']")
    end

    def ipex_renters_cvrg_static_grp name, uid
      name = name.downcase
      ipex_help_group name, uid
      # label("#{name}_coverage_label".to_sym, :for => "#{uid}")
      span("#{name}_coverage_value".to_sym, :xpath => "//div[@id='coverage#{uid}']/div//span")
      div("#{name}_coverage_name".to_sym, :id => "coverage#{uid}")
    end

    def ipex_renters_cvrg_txtbox_grp name, uid
      name = name.downcase
      ipex_help_group name, uid
      text_field("#{name}_coverage_textbox".to_sym, :id => "#{uid}")
      div("#{name}_coverage_name".to_sym, :xpath => "//div[@id='coverage#{uid}']")
    end

    def ipex_renters_cvrg_select_grp name, uid
      name = name.downcase
      ipex_help_group name, uid
      ipex_renters_cvrg_static_grp name, uid
      select_list("#{name}_coverage_list".to_sym, :id => "#{uid}")
      div("#{name}_coverage_name".to_sym, :xpath => "//div[@id='coverage#{uid}']")
    end

    # todo : Groups! .. lemme know when you reach here ani
    # Coverages Groups -------------------------------------=
    def ipex_radio_group name, uid
      name = name.downcase
      ipex_help_group name, uid
      label("#{name}_question_label", :xpath => "//label[@for='#{uid}']")
      # label("#{name}", :xpath => "//label[@for='#{uid}']")
      label("#{name}_yes", :xpath => "//label[@for='#{uid}_Y']")
      label("#{name}_no", :xpath => "//label[@for='#{uid}_N']")
      radio_button("#{name}_yes_radio", :id => "#{uid}_Y")
      radio_button("#{name}_no_radio", :id => "#{uid}_N")
      strong("#{name}_error", :id => "#{uid}_error")
    end

    def ipex_checkbox_group name, uid

    end

    def ipex_textbox_group name, uid
      name = name.downcase
      label("#{name}_label", :xpath => "//label[@for='#{uid}']")
      text_field("#{name}".to_sym, :id => "#{uid}")
      strong("#{name}_error", :id => "#{uid}_error")
    end

    def ipex_selectlist_group name, uid
      name = name.downcase
      # ipex_help_group name, uid
      label("#{name}_question_label", :xpath => "//label[@for='#{uid}']")
      label("#{name}", :xpath => "//label[@for='#{uid}']")
      # label("#{name}_yes", :xpath => "//label[@for='#{uid}_Y']")
      # label("#{name}_no", :xpath => "//label[@for='#{uid}_N']")
      select_list("#{name}".to_sym, :id => "#{uid}")
      strong("#{name}_question_error", :id => "#{uid}_error")
    end

    # todo : SelectListGroups! .. Guys we need to look at this!!!
    def _ipex_selectlist_group name, uid # i_like_this_better
      name = name.downcase
      # ipex_help_group name, uid
      select_list("#{name}_list".to_sym, :id => "#{uid}")
    end

    def ipex_carousel_group name, uid
    # todo: treat each owl element separately?
    end
  end
end

# Neva Mind Tries - Kyu

module PageObject
  module Platforms
    module WatirWebDriver
      module Element
        def method_missing(*args, &block)
          m = args.shift
          begin
            element.send(m, *args, &block)
          rescue Exception => e
            raise "lets see here.. : #{e} ...\n"
          end
        end
      end
      class PageObject
        # todo.. rethink flashfill
        # Execute javascript on the browser
        #
        # @example Get inner HTML of element
        #   span = @page.span_element
        #   @page.execute_script "return arguments[0].innerHTML", span
        #   #=> "Span innerHTML"
        #
        def execute_script(script, *args)
          p script, :bg_bl if verbose_mode
          args.map! { |e| e.kind_of?(PageObject::Elements::Element) ? e.element : e }
          platform.execute_script(script, *args)
        end
      end
    end
  end
end

# Careful .. we are using the aliasing of 'on' and 'on_page' .. make sure you always use 'on_page'!
# module POoverride
module PageObject
  module PageFactory
    def on_page(page_class, params={:using_params => {}}, visit=false, &block)
      on page_class, params, visit, &block
      $pages_visited = [] unless $pages_visited
      # $numba = 0 unless $numba
      # $pages_visited << "#{"%02d" % $numba+=1} - #{page_class}"
      $pages_visited << "#{page_class}"
      @navigator.app_specific_handle self if defined? @navigator.app_specific_handle
    end
  end
end

# World POoverride
