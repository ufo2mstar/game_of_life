class Hash
  def deep_stringify_keys
    new_hash = {}
    self.each do |key, value|
      new_hash.merge!(key.to_s => (value.is_a?(Hash) ? value.deep_stringify_keys : value))
    end
  end
end

module RegressionFormatter

  class YMLFormat
    attr_accessor :current_scenario_details, :failed_scenarios

    def initialize(step_mother, io, options)
      output_folder             = (ENV["output_folder"] || "features/output") + "/"
      @io                       = File.new(output_folder + "#{ENV["state"]}#{$timestamp}.yml", "w")
      @current_scenario_details = {}
      @failed_scenarios         = {}
    end

    def scenario_name(keyword, name, file_colon_line, source_indent)
      p keyword
      p name
      @current_scenario_details[:FeatureFileName] = "#{file_colon_line}"
      @current_scenario_details[:ScenarioName]    = name
    end

    def after_table_row(table_row)
      p "table_row: #{table_row}"

      example_name = "#{@current_scenario_details[:ScenarioName]} - #{table_row.to_hash.values.join(";")}"
      if table_row.exception
        p "exception: #{table_row.exception.message}"
        @failed_scenarios[example_name]                   = {}
        @failed_scenarios[example_name][:FeatureFileName] = @current_scenario_details[:FeatureFileName]
        @failed_scenarios[example_name][:FailureReason]   = table_row.exception.message
        #@failed_scenarios[@current_scenario_details[:ScenarioName]][:FailedAtStep] = step_match.instance_variable_get("@name_to_match")
        write_to_yml
      end
    end

    def after_step_result(keyword, step_match, multiline_arg, status, exception, source_indent, background)
      if status == :failed
        p "exception: #{exception}"
        @failed_scenarios[@current_scenario_details[:ScenarioName]]                   = {}
        @failed_scenarios[@current_scenario_details[:ScenarioName]][:FeatureFileName] = @current_scenario_details[:FeatureFileName]
        @failed_scenarios[@current_scenario_details[:ScenarioName]][:FailureReason]   = exception.message
        @failed_scenarios[@current_scenario_details[:ScenarioName]][:FailedAtStep]    = step_match.instance_variable_get("@name_to_match")
        write_to_yml
      end
    end

    def after_features(features)
      @io.close
    end

    def yaml(hash)
      method = hash.respond_to?(:ya2yaml) ? :ya2yaml : :to_yaml
      string = hash.deep_stringify_keys.send(method)
      string.gsub("!ruby/symbol ", ":").sub("---", "").split("\n").map(&:rstrip).join("\n").strip
    end

    def write_to_yml
      @io.write yaml(@failed_scenarios)
      @io.puts
      @failed_scenarios = {}
    end
  end

  class ExcelFormat
    attr_accessor :current_row, :current_scenario_details

    SCENARIO_COLUMN    = 0
    FEATUREFILE_COLUMN = 1
    EXCEPTION_COLUMN   = 2
    FAILEDSTEP_COLUMN  = 3
    STATUS_COLUMN      = 4

    def initialize(step_mother, io, options)
      require 'writeexcel'
      output_folder = (ENV["output_folder"] || "features/output") + "/"

      @workbook = WriteExcel.new(output_folder + "#{ENV["state"]}#{$timestamp}.xls")
      @io       = @workbook.add_worksheet("Results")
      @io.set_column(SCENARIO_COLUMN, STATUS_COLUMN, 30)
      @current_row              = 0
      @current_scenario_details = {}
      setup_headers
    end

    def setup_headers
      header_format = @workbook.add_format(:bold => 1, :size => 14)
      @io.write(@current_row, SCENARIO_COLUMN, "Scenario Name", header_format)
      @io.write(@current_row, FEATUREFILE_COLUMN, "Feature file Name", header_format)
      @io.write(@current_row, EXCEPTION_COLUMN, "Exception", header_format)
      @io.write(@current_row, FAILEDSTEP_COLUMN, "Failed Step", header_format)
      @io.write(@current_row, STATUS_COLUMN, "Status", header_format)
      @current_row += 1
    end

    def scenario_name(keyword, name, file_colon_line, source_indent)
      @current_scenario_details[:FeatureFileName] = "#{file_colon_line}"
      @current_scenario_details[:ScenarioName]    = name
    end

    def after_step_result(keyword, step_match, multiline_arg, status, exception, source_indent, background)
      if status == :failed
        @io.write(@current_row, SCENARIO_COLUMN, @current_scenario_details[:ScenarioName])
        @io.write(@current_row, FEATUREFILE_COLUMN, @current_scenario_details[:FeatureFileName])
        @io.write(@current_row, EXCEPTION_COLUMN, exception ? exception.message : "")
        @io.write(@current_row, FAILEDSTEP_COLUMN, step_match.instance_variable_get("@name_to_match"))
        @io.write(@current_row, STATUS_COLUMN, status)
        @current_row              += 1
        @current_scenario_details = {}
      end
    end

    def after_table_row(table_row)
      p "table_row: #{table_row}"

      example_name = "#{@current_scenario_details[:ScenarioName]} - #{table_row.to_hash.values.join(";")}"
      if table_row.exception
        p "exception: #{table_row.exception.message}"

        @io.write(@current_row, SCENARIO_COLUMN, example_name)
        @io.write(@current_row, FEATUREFILE_COLUMN, @current_scenario_details[:FeatureFileName])
        @io.write(@current_row, EXCEPTION_COLUMN, table_row.exception.message)
        @io.write(@current_row, STATUS_COLUMN, "Failed")
        @current_row += 1
      end
    end

    def after_features(features)
      @workbook.close
    end
  end
end