class NilClass
  def empty?
    print "\n\n watch out.. calling Empty for a Nil class!\nat '#{__callee__}' \nin #{caller[0]}\n\n"
    true # coz in my philosophy.. Nil is empty!
  end
end