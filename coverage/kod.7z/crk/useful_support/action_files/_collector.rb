# require 'page-object'
#
# module App
#   extend self
#   def loc
#     p @@itm ||= Dir[File.dirname(__FILE__)+"/../../pages/**/#{product_line}/app_stuff"].first
#     raise " no app loc #{@@itm}" unless @@itm
#     @@itm
#   end
# end
# include App


class BabbageCollector
  # BabbageCollector
  def initialize
  #   big a$$ hash thats gonna contain EVERYTHING!!
  # and can potentially be a binder class!
  #   todo: my hash js object thing
  #   $collector
  end
end